# MOBILE APP MASTER PROMPT — Premium School ERP (Web App)

**Developer credit:** Sanjaydat Kumar
**Banaya gaya:** aapke existing desktop software (Tauri + React + SQLite) ke **saare features** ko mobile web app me convert karne ke liye.

---

## Kaise use karein (2 minute)

1. Neeche **"PROMPT START"** se **"PROMPT END"** tak ka poora text copy karein.
2. Jis AI tool se banwana hai usme paste karein — Cursor / Claude Code / Lovable / Bolt / v0 / Replit Agent / Windsurf.
3. Ek chhoti si line apne hisaab se badal dein: **"Sync mode: A (offline only) ya B (server sync)"** — dono ka detail prompt me diya hai.
4. Build hone ke baad mobile me Chrome kholein → **Add to Home screen** → app ki tarah chalega. Play Store chahiye to Part 3 dekhein (TWA).

---

# ⬇️ PROMPT START ⬇️

## 1. ROLE

You are a senior full-stack engineer AND a mobile product designer. Build a complete, production-ready, **mobile-first web app (PWA)** — a full School Management ERP for Indian schools. This is a **1:1 mobile replacement** of an existing Windows desktop app, with **all modules**, but designed fresh for phone screens: light, fast, modern, offline-first. Credit the developer as **Sanjaydat Kumar** everywhere (settings + about page). Write clean, typed, maintainable code. No placeholders, no "TODO", no fake demo data anywhere in the production build.

## 2. TECH STACK (lightweight — hard constraints)

- **React 18 + TypeScript + Vite** (fast dev, small bundle)
- **Tailwind CSS** for styling. Do NOT add MUI / AntD / Chakra / Bootstrap. Build ~15 small own components (Button, Input, Select, Card, Sheet, Modal, Chip, Badge, Tabs, Toast, EmptyState, Skeleton, DataList, FAB, StatCard).
- **Zustand** for state (tiny, ~1KB). Avoid Redux.
- **React Router v6** with lazy-loaded routes (`React.lazy`) for every module.
- **Dexie.js (IndexedDB)** as the local database — the app must work 100% offline after first load.
- **xlsx (SheetJS)** — only for Excel/CSV import-export, loaded lazily (dynamic `import()`).
- **Charts:** do NOT use heavy chart libs by default. Build 4–5 tiny SVG/CSS charts (bar, line, donut) yourself. If a lib is unavoidable, use `recharts` only in a lazy chunk.
- **Icons:** `lucide-react` (tree-shaken imports only).
- **Dates:** native `Intl.DateTimeFormat` / small helpers. No moment.js, no date-fns full import.
- **PWA:** `vite-plugin-pwa` — manifest, maskable icons, offline caching, installable, splash theme color.
- **Printing:** `window.print()` with dedicated print-only CSS (`@media print`) templates. No PDF library (saves ~500KB).
- **No API keys in the frontend. No analytics. No trackers.**
- Heavy anything (xlsx, charts, print templates) must be **lazy-loaded chunks**.

**Bundle budget (must respect):** initial JS < 200KB gzip, any lazy chunk < 300KB, total app < 1.2MB. First interactive < 2s on 4G, smooth 60fps on a ₹8,000 Android phone (2–3GB RAM).

## 3. ARCHITECTURE — choose ONE

**MODE A — Offline-first, single device (default, recommended for start)**
- All data in IndexedDB (Dexie). No server, no login server.
- Local login: users table in IndexedDB, password stored as SHA-256 hash + salt (Web Crypto API).
- Backup = one-tap export of a **single `.schoolerp` file** (JSON/gzip of all tables + photos) that can be shared via WhatsApp/Drive, and restored from file.

**MODE B — Offline-first + cloud sync (multi-user: principal/teacher/accountant/reception)**
- Same local-first app, plus a sync layer: Supabase (Postgres + Auth + Storage) or a small Node/Fastify + SQLite server.
- Sync rules: every table gets `updated_at`, `deleted_at` (soft delete) and a `sync_state` (`pending|synced`). Writes go to IndexedDB first, then pushed in a **sync queue** with retry + exponential backoff. Pull = incremental by `updated_at`. Conflict = last-write-wins by server timestamp, but **fee/attendance/payment records are append-only** (never overwrite, creates adjustment entry).
- Show a small online/offline pill + "X records pending sync" banner.
- Row-level security: Teacher sees only assigned classes/sections; Accountant sees fees+payroll; Reception sees admissions only; Principal sees reports + approvals; Admin sees all.

Implement MODE A first, and keep the data layer behind a `repository/` interface so MODE B can be switched by config later without rewriting screens.

## 4. DESIGN SYSTEM — "modern, premium, phone-first"

- **Layout:** content width capped at 480px, centered on tablets/desktop with soft shadow so it looks like an app. Bottom safe-area padding everywhere.
- **Navigation:** bottom tab bar (5 items) = **Home · Students · Fees · Exams · More**. "More" opens a grid of all remaining modules. Sticky top app bar with: screen title, search icon, notification bell with unread badge, sync pill.
- **Quick actions:** a FAB (bottom-right, above tab bar) that changes per screen — Students → "New Admission", Attendance → "Mark All Present", Fees → "Collect Fee", Students list row → swipe for "Call / WhatsApp / Profile".
- **Surfaces:** rounded-2xl cards, subtle borders, soft shadows, 8px spacing scale. Light + dark theme (dark is a first-class citizen, toggle + "system" option).
- **Colors:** brand indigo→violet gradient for primary actions; semantic colors: success emerald, warning amber, danger rose, info sky. Fee pending = amber, paid = emerald, absent = rose.
- **Touch:** minimum 44×44px targets, generous row height (56–64px), bottom sheets instead of desktop modals, native select/date inputs for speed.
- **Feedback:** toasts (top), skeleton loaders (never blank screens), pull-to-refresh, empty states with a friendly Hinglish line + action button, inline form validation with error text under the field.
- **Micro-interactions:** 150–250ms transitions, press states, subtle haptic feel via visual feedback (no jarring animations), page transition slide for detail screens.
- **Typography:** system font stack / Inter. Screen titles bold 20–24px, body 14–15px, helper text 12px slate-500.
- **Indian formatting everywhere:** `₹1,25,000.00` (en-IN), dates `DD-MM-YYYY`, academic session `2026-27`, phone `+91`, currency Indian digit grouping, Aadhaar masked as `XXXX XXXX 1234`.
- **Language:** labels English, but helper text and empty states in simple **Hinglish** (e.g. "Abhi koi student add nahi hua — 'New Admission' dabayein"). Keep a `t()` dictionary so Hindi can be added later.
- **Accessibility:** WCAG AA contrast, visible focus rings, screen-reader labels on icon buttons, "big text" mode in settings (scales root font 100%/115%/130%).
- **Performance UX:** list virtualization for >100 rows, image thumbnails (max 800px, JPEG/WebP quality 0.75, stored as base64 in IndexedDB), no layout shift.

## 5. USERS, ROLES & AUTH

Roles: **Admin** (all), **Principal** (reports, promotions, approvals, payroll view), **Teacher** (own classes: attendance, exam marks, student view), **Accountant** (fees, demand bills, payroll, backup), **Reception** (admissions, students, ID cards, reports view).

- Login screen: username + password, "Remember me", show last username, "Forgot password → ask admin" note.
- Default first-run user: `admin / admin123` → force change on first login.
- Session auto-lock after inactivity (configurable, default 15 min) with re-enter password; data stays local.
- Every create/update/delete writes to an **audit log** (who, when, what, before/after).
- Role-based UI: hide/disable modules not allowed; server mode additionally enforces rules server-side.

## 6. MODULES & FEATURES (complete — build all of these)

### 6.1 First-run Setup Wizard (3 steps)
School name, address, phone, email, website, logo upload (camera/gallery), principal name, academic session (e.g. 2026-27), default fee month, result template (premium/classic/compact), theme. Skippable and editable later in Settings. **No demo data is ever seeded.**

### 6.2 Dashboard (Home)
- Stat tiles (tap to jump): Total Admissions, Active Students, Left Students, TC Issued, Teachers, Classes, Today's Attendance %, Fee Collection (this month), Pending Fees, Upcoming Exams, Salary Pending, Transport Students, Recent Admissions, Today's Birthdays.
- Small charts: Attendance trend (last 7 days), Fee collection (last 6 months), Pending fees by class, Class strength, Admission trend by year, Exam performance.
- Quick actions row: New Admission · Collect Fee · Mark Attendance · Add Expense/Payroll.
- Alerts strip: fee defaulter count, low-attendance students, backup reminder, expiring licenses/gaps.
- Notification bell → Notifications screen.

### 6.3 Students
- List: search by name / admission no / father / mother / mobile / Aadhaar / roll — instant local search; filters: class, section, session, status; sort: name, roll, admission date; **class-wise list** guaranteed (load only selected class+section, no cross-class leakage). Row shows photo thumb, name, class-section-roll, adm no, status chip; swipe actions: Call, WhatsApp, ID card.
- **New Admission form:** admission number (auto-suggest next, editable, normalized), student name, father, mother, class, section, roll number (auto next available, duplicate prevented), DOB, gender, religion, Aadhaar (12-digit validation + mask), mobile (10-digit, 6–9 start), address, transport route (optional), admission date, session, photo (camera/gallery with crop & compress), status. Duplicate check on admission number + name+DOB+mobile with warning.
- On save: admission receipt print, timeline entry, ID card offer.
- **Student Profile** (tabs): Overview · Fees · Attendance · Exams · Documents · Timeline.
- Actions: Edit, Print ID Card (front+back), Print TC (transfer certificate), Mark Left (date + reason), TC Issued (TC no + date + reason), Restore/Re-admit (with new session/class/roll), Print Admission Receipt, Bulk ID Cards for a class, Share student summary as text on WhatsApp.
- Soft delete only (never hard delete), everything recoverable.

### 6.4 Classes & Sections
CRUD (name, section, session, room number, class teacher, status), active student count, unique class+section+session, list grouped by class for mobile.

### 6.5 Teachers
CRUD: auto teacher ID, name, gender, subject, qualification, mobile, address, joining date, salary (for payroll suggestion), status. Assign as class teacher. Teacher list report.

### 6.6 Attendance
- **Mark Attendance (daily):** pick session → class → section → date (default today, future dates blocked). Students load for the **selected class+section only** — show a small count line like "42 students loaded (Class 6-A)". Each row: photo, name, roll, three big buttons P / A / L (Present / Absent / Late) + remarks. "Mark all Present" bulk action, "Reset day". Shows already-saved state if attendance exists for that date (editable).
- Save offline instantly; background sync (Mode B).
- **Monthly Summary:** per student → present/absent/late days, %, working days; class average; absentees list; low-attendance (<75%) highlight + WhatsApp alert link.
- **Calendar view** per student (month grid with colored days).
- Attendance register print + CSV export.
- Unique rule: one record per student per date.

### 6.7 Fees
- **Fee Structure:** per class + section + session → tuition, transport, exam, admission, library, other → auto total. Copy structure to another class/session in one tap.
- **Generate Monthly Dues:** pick month + class (or all) → creates due entries (no duplicates for same student+session+month).
- **Collect Fee:** search student → auto prefill from fee structure + pending previous dues → edit heads, add discount, fine, partial payment, payment mode (Cash/UPI/Card/Cheque/Online), remarks, auto receipt number (`RCPT-YYYYMM-0001`), auto-clear previous dues option → save → **receipt print (80mm thermal + A4)** and optional WhatsApp receipt text to parent.
- Pending fee report (class-wise, month-wise, aging buckets 0–30/31–60/61–90/90+ days), defaulter list with one-tap call/WhatsApp reminder template in Hinglish.
- Fee ledger per student, receipt reprint, receipt cancel/reversal with reason (audit-logged, never silently delete).
- Dashboard numbers feed from here.

### 6.8 Demand Bills (bulk)
- Generate demand bills: session, month(s), class or all, include heads (tuition/transport/exam/library/other/admission), include back dues toggle, save current dues toggle, batch number + remarks.
- Preview table (student, class, heads, previous dues, current, grand total, existing-skipped flag).
- Print **demand bill slips** — 2–4 slips per A4 page, cut-friendly, header with school logo, "Pay by <date>" note, QR-less but a payment-detail block.
- WhatsApp send link, batch list history, CSV export.

### 6.9 Family / Sibling Billing
- Auto group families by father name + mobile → "family key".
- Family view: children list, per-child dues, combined total, sibling discount field, fine field.
- Generate one **family bill** for multiple months + multiple children, pay full/partial, print family bill with all line items, WhatsApp share.

### 6.10 Exams & Results
- **Exams CRUD:** exam name, class, section, session, max marks, date, subjects (add multiple subjects with individual max marks), status.
- **Marks Entry:** fast phone grid — pick exam → class → subject → enter marks for each student with number pad, next-field auto-jump, save row-by-row, "Save & Next Subject". Shows entered/pending count.
- Auto: total obtained, total max, percentage, grade, pass/fail (pass = all subjects ≥ 33%).
- **Grade scale:** A1 91–100, A2 81–90, B1 71–80, B2 61–70, C1 51–60, C2 41–50, D 33–40, E below 33 (Fail).
- **Ranks:** rank list per exam/class, with **search by name / admission number / rank / grade**; tie handling by percentage; topper highlight; subject-wise topper list.
- **Prints:** Rank marksheet (detailed subject table + grade + rank + remarks + signature), Bulk marksheets for a class (multi-page), **Class Wall Result poster** (top 10 with ranks, gradient design), Final Progress Report (1st term / 2nd term / final per subject + overall), Result templates: premium / classic / compact.
- Exam performance charts, CSV export of results.

### 6.11 Promotion
- **Normal Promotion:** from class+section → to class+section, old session → new session; auto new roll numbers in order; preview table before applying (student, old roll → new roll, conflicts highlighted); conflict handling option (re-number duplicates).
- **Rank-based Promotion:** pick exam → compute ranks → distribute students into sections by merit (e.g. Rank 1–40 → A, 41–80 → B) and by pass/fail rule; preview + apply.
- **Single student promote** from student profile or list (class, section, session, new roll).
- Applied promotions written to **promotion log** (from→to class/section/session/roll, type, rank used, date, user). Logs screen with filters + CSV export. Clear warning: action is bulk and logged.

### 6.12 Payroll
- Monthly payroll per employee: name (pick from teachers/staff), role, month, year, basic, allowance, deduction → net auto. Bulk copy last month's payroll → edit.
- Mark Paid with payment date, status chips Paid/Unpaid, month-wise register, total payable vs paid summary.
- **Salary slip print** — school header + logo, employee details, earnings/deductions table, net in words, "Paid on" date, three signature lines (Employee / Accountant / Principal).
- Pending salary dashboard tile, CSV export.

### 6.13 Transport
- Routes CRUD: route name, vehicle number, driver name, driver phone, monthly fee, remarks, status.
- Assign students to route (from student form or route detail screen), route-wise student list, capacity warning.
- Transport fee auto-added into the student's fee/demand bill; transport report (route, vehicle, driver, students count, monthly total).

### 6.14 Reports (10 reports)
Admission Register · Active Students · Left Students · TC Register · Class-wise Student List · Fee Pending · Fee Ledger · Teacher List · Transport Report · Audit Log.
- Filters: class, section, session, status, date range (from/to) + instant search inside results.
- On screen: list view with row count and column chooser.
- Actions: **Print / PDF preview** (A4, with school logo + header + filters subtitle + page numbers) and **CSV export** (opens in Excel). Print must first require data to be loaded, showing a clear Hinglish message otherwise.

### 6.15 Notifications
Auto-generated: fee dues (monthly), low attendance, backup reminder, upcoming exams, today's birthdays, pending salary, data-integrity warnings. Unread badge, mark one/all read, tap → jump to the related module, filter by type/severity.

### 6.16 Backup / Restore / Data Safety
- One-tap **local backup** → single file (`.schoolerp`), auto-named with date, share sheet (WhatsApp/Drive/Gmail).
- Auto-backup reminder (daily/weekly/monthly setting) + last-backup date on dashboard.
- **Restore** from file with a preview (record counts + created date) and a mandatory confirmation; a safety copy of current data is taken before restore.
- **Data Integrity:** checks — duplicate admission numbers, duplicate roll numbers in same class/section, students without class, missing fee structures, fee totals mismatch, fee receipts with negative/zero amount, attendance duplicates, students with invalid mobile/Aadhaar, results with marks > max. Each check shows count + records + **one-tap fix** (with audit log).
- Audit log screen (filter by user/entity/date).

### 6.17 Excel / CSV Tools
- Export: Students, Fees, Attendance, Teachers, Transport, Payroll, Exam Results → CSV/XLSX (opens directly in Excel).
- Import Students from CSV/XLSX: file pick → column mapping → **validation preview** (rows OK / rows with errors) → import only valid rows → downloadable error report.
- Validation rules: admission number normalization, mobile 10 digits, Aadhaar 12 digits, duplicate roll prevention, required fields, DOB format, class must exist (auto-create option).
- Provide a **blank template download** for import.

### 6.18 Settings
School profile + logo, academic session + default session, default fee month, default result template, print footer note, receipt footer note, theme (light/dark/system), text size, language, auto-backup frequency + keep-count, sync settings (Mode B), app version, **About/Credits: "Developed by Sanjaydat Kumar" (locked)**.

### 6.19 Fresh Start / Factory Reset (must be built-in from day one)
- Two options with clear Hinglish explanation of what will be deleted and what will remain:
  - **Data Clear:** removes students, fees, demand bills, attendance, exams & marks, promotions, payroll, notifications. Keeps classes, teachers, fee structure, transport, settings, logo, and login users.
  - **Full Factory Reset:** everything above plus classes, teachers, transport, fee structure, settings reset to defaults, logo removed, only `admin / admin123` remains.
- Requires typing `RESET` to confirm, shows a **safety backup** offer (mandatory, one-tap) before wiping, then clears photos/uploads and shows record counts before/after.
- Also mention in the UI exactly where the data lives (so users understand backups), e.g. "App ka data is device ke browser storage (IndexedDB) me hai — backup file banakar rakhein."

### 6.20 Users & Roles, Change Password, Logout, Exit
Users CRUD (username, full name, role, status), reset password (admin), activate/deactivate, last login, change own password (strength meter), logout with confirmation, "Exit / Close app" screen with reminder to take backup.

## 7. SCREENS / ROUTES

```
/ (Login)
/setup                (first-run wizard)
/home                 (Dashboard)
/students             (list + search + filters)
/students/new         (admission form)
/students/:id         (profile: overview|fees|attendance|exams|documents|timeline)
/classes  /classes/:id
/teachers /teachers/:id
/attendance           (mark)
/attendance/summary   (monthly)
/fees                 (collect + recent)
/fees/structure
/fees/pending
/demand-bills
/family-billing
/exams   /exams/:id/marks   /exams/:id/ranks
/promotion
/payroll
/transport
/reports
/notifications
/backup  /data-integrity
/excel-tools
/settings  /users  /change-password  /fresh-start  /about  /exit
```
Bottom tabs: Home · Students · Fees · Exams · More.

## 8. DATA MODEL (IndexedDB tables — implement exactly)

- **students**: id, admission_number, normalized_admission_number (unique), student_name, father_name, mother_name, class_id, section, roll_number, dob, gender, religion, aadhaar_number, mobile_number, address, photo (blob/base64), transport_route_id, vehicle_number, academic_session, status (Active|Left|TC Issued|Passed Out|Inactive), leaving_date, leaving_reason, tc_number, tc_issue_date, last_class, admission_date, created_at, updated_at, deleted_at
- **classes**: id, name, section, academic_session, room_number, class_teacher_id, status, created_at, updated_at, deleted_at · unique(name, section, session)
- **teachers**: id, teacher_id (unique), name, gender, subject, qualification, mobile, address, joining_date, salary, status, deleted_at
- **transport_routes**: id, route_name (unique), vehicle_number, driver_name, driver_phone, monthly_fee, remarks, status, deleted_at
- **fee_structures**: id, class_id, section, academic_session, tuition_fee, transport_fee, exam_fee, admission_fee, library_fee, other_fee, total, status · unique(class_id, section, session)
- **fees**: id, receipt_number (unique), student_id, academic_session, fee_month, all heads, discount, fine, subtotal, paid_amount, balance, status (Paid|Pending|Partial), paid_date, payment_mode, remarks, created_at, deleted_at · unique(student_id, session, fee_month) where not deleted
- **attendance**: id, student_id, class_id, attendance_date, status (Present|Absent|Late), academic_session, remarks · unique(student_id, attendance_date)
- **exams**: id, exam_name, class_id, section, academic_session, max_marks, exam_date, status · unique(exam_name, class_id, section, session)
- **exam_subjects**: id, exam_id, subject_name, max_marks · unique(exam_id, subject_name)
- **exam_results**: id, exam_id, student_id, subject_name, max_marks, marks_obtained, grade, result_status · unique(exam_id, student_id, subject_name)
- **promotion_logs**: id, student_id, from_class_id, to_class_id, from_section, to_section, old_session, new_session, old_roll_number, new_roll_number, promotion_type (normal|rank), rank_used, remarks, created_at
- **family_bills / family_bill_items**: bill_number (unique), family_key, parent_name, parent_mobile, months, student_names, subtotal, discount, fine, total, paid_amount, balance, status, paid_date, payment_mode + items (student_id, fee_month, fee_head, amount, source)
- **payroll**: id, employee_name, role, month, year, basic_salary, allowance, deduction, net_salary, status, payment_date, remarks · unique(employee_name, month, year)
- **notifications**: id, type, title, message, module, severity, is_read, related_id, created_at
- **settings**: key/value (school_name, address, phone, email, website, logo, principal_name, academic_session, default_fee_month, result_template, print_footer_note, receipt_footer_note, theme, text_size, auto_backup, auto_backup_frequency, keep_backups_count, developer_name = 'Sanjaydat Kumar')
- **users / roles**: users(id, username unique, password_hash, salt, full_name, role, status, last_login_at); roles: Admin, Teacher, Accountant, Reception, Principal
- **student_timeline**: id, student_id, event_type, event_title, details, created_at
- **documents**: id, student_id, doc_type, file (blob/base64), remarks, created_at, deleted_at
- **audit_logs**: id, user_id, action, entity, entity_id, before_json, after_json, created_at
- **backup_logs**: id, file_name, size, type, verified, created_at

## 9. BUSINESS RULES (implement precisely)

1. Admission number: trim, uppercase, remove spaces/`/`/`-` → `normalized_admission_number` unique.
2. Receipt number: `RCPT-{YYYYMM}-{0001}` sequential per month, unique, never reused.
3. Roll number unique per (class, section, session) among Active students; auto "next available" = max+1 per class+section.
4. One fee due per (student, session, month). Duplicate generation is blocked and reported.
5. Attendance: one record per student per date; re-saving the day updates instead of duplicating.
6. Grade/pass rules as in 6.10. Percentage = total_obtained / total_max × 100, rounded to 2 decimals.
7. Rank: sort by percentage desc, then total marks desc, then name asc. Ties share the same rank (dense rank), next rank skips accordingly.
8. Promotion creates a log row for every student, and updates the student's class/section/session/roll atomically (all-or-nothing transaction).
9. Money: store as numbers with 2-decimal rounding; display `en-IN`. Never store currency strings.
10. Soft delete everywhere (`deleted_at`) except genuine wipes done from Fresh Start. Every update sets `updated_at`.
11. Validation: mobile 10 digits starting 6–9, Aadhaar 12 digits, DOB not in future, admission date not in future, required = admission no + name + class + section + session, resume/roll duplicates warned before save.
12. All bulk actions (promotion, demand bills, dues generation, import) must show a **preview + count** before committing.

## 10. PRINT TEMPLATES (mobile — via window.print + print CSS)

Build all of these as print previews (with on-screen "Print / Save as PDF" + "Share" buttons):
1. Fee Receipt — 80mm thermal **and** A4 versions, school logo + header, receipt no, student details, heads, discount, fine, total, paid, balance, mode, "amount in words", receipt footer note, signature.
2. Admission Receipt.
3. Student ID Card — **front + back side by side (2 per A4, cut lines)**: front = photo, name, class-section, roll, adm no, DOB, blood group (optional), father name, mobile, session, school logo, valid-till, principal signature; **back = permanent address, school logo as watermark, school name/address/phone/email/website, and note "This ID card is the property of the school. If found, please return to the school office."** Bulk ID cards for a whole class (front+back for each student, multi-page).
4. Transfer Certificate (TC) — formal format with date, last class studied, conduct, dues cleared note, TC number/date, principal signature.
5. Rank Marksheet — detailed subject-wise table, total, percentage, grade, rank, remarks, signature.
6. Final Progress Report — 1st term / 2nd term / final per subject.
7. Class Wall Result poster — top 10 students with rank, name, %, gradient design (shareable image export too).
8. Demand Bill Slips — 2–4 per A4 page with cut lines, school header, heads breakdown, due date.
9. Family Bill — multi-child, multi-month line items.
10. Salary Slip — earnings/deductions, net in words, paid date, three signatures.
11. Reports — A4 portrait/landscape with header, filters subtitle, table with zebra rows, footer with page numbers + print footer note.

Print CSS rules: `@page { size: A4; margin: 10mm }` and a `thermal` variant; `page-break-inside: avoid` for slips/cards; images embedded as base64 (photos/logo must print); colors forced where needed; black text for thermal.

## 11. NON-FUNCTIONAL REQUIREMENTS

- **Offline:** 100% functional offline after install; no white screen without network; friendly offline banner.
- **Data safety:** never lose data on app close/background; export reminder; safe restore; transaction-wrapped multi-record writes.
- **Performance:** lazy routes, memoized lists, virtualized tables, debounce search, IndexedDB indexes on admission_number / name / class_id / status / dates.
- **Reliability:** error boundary with "Restart" + "Export data" buttons; every failure shows a plain-Hinglish message, not a stack trace.
- **Storage:** show used storage size in Settings; warn at 80% of quota; compress all images.
- **Security:** hashed passwords (Web Crypto SHA-256 + salt), role checks on every route, no plaintext secrets, lock screen on inactivity.
- **Compatibility:** Android Chrome 90+, iOS Safari 15+, works on 320px wide screens; PWA installable; safe-area insets for notch; `viewport-fit=cover`.
- **Testing:** unit tests for money/grade/rank/validation/normalization helpers; manual happy-path checklist for each module.

## 12. PROJECT STRUCTURE & COMMANDS

```
src/
  app/            (router, providers, theme)
  components/ui/  (Button, Input, Select, Sheet, Modal, Chip, Tabs, Toast, Card, StatCard, EmptyState, Skeleton, DataList, FAB, BottomNav, TopBar)
  features/       (auth, setup, dashboard, students, classes, teachers, attendance, fees, demandBills, familyBilling, exams, promotion, payroll, transport, reports, notifications, backup, integrity, excelTools, settings, users, freshStart)
  db/             (dexie schema, migrations, seed admin, repository interfaces)
  lib/            (money, dates, grade, rank, validation, normalize, export, print, share, whatsapp, image, crypto)
  print/          (receipt.ts, idcard.ts, tc.ts, marksheet.ts, report.ts, slip.ts)
  locales/        (en.ts dictionary with Hinglish helper strings)
  styles/         (tailwind.css, print.css)
```
Commands: `npm i` → `npm run dev` (dev), `npm run build` (prod), `npm run preview`. Include a `README.md` with: install on phone (Chrome → Add to Home screen), how to take backup, how to restore, how to move data to a new phone.

**Seed:** only one admin user + default settings. Absolutely **no demo students, demo fees, demo teachers, or sample charts data** in the production build. Demo data may exist only behind an explicit "Load sample data (dev only)" toggle that is OFF by default and marked clearly.

## 13. DELIVERABLES

1. Complete working source code (all files, no placeholders).
2. Running app: all modules from section 6 implemented and navigable on a 360px phone screen.
3. PWA installable with icons + offline caching.
4. README (Hindi/Hinglish) covering: install, login, daily workflows (admission → attendance → fee collection → exam → result → promotion → backup), and phone-to-phone data transfer.
5. A short "Test checklist" file listing 40–60 tap-by-tap checks (one per feature).

## 14. ACCEPTANCE CRITERIA (all must pass)

- [ ] Login + role-based navigation works; teacher cannot open payroll.
- [ ] New admission saves with photo, prints admission receipt and ID card (front+back).
- [ ] Students list filters by class+section correctly and never shows other classes' students.
- [ ] Attendance loads only the selected class+section students, allows bulk "All Present", re-edit of saved day works.
- [ ] Fee collection: prefill from structure, partial payment, auto receipt no, receipt prints on 80mm and A4.
- [ ] Demand bills generate without duplicates and print 2–4 slips per page.
- [ ] Family bill combines siblings and prints correctly.
- [ ] Exams: marks entry is fast on phone, rank list searchable by name/adm no/rank/grade, marksheet + wall result print.
- [ ] Promotion (normal + rank based) shows preview, applies atomically, writes logs; single student promote works.
- [ ] Payroll slip prints with signatures; mark-paid updates dashboard.
- [ ] Transport route assign → fee reflects in demand bill.
- [ ] All 10 reports load, preview, print and export CSV.
- [ ] Excel import validates and reports errors; exports open in Excel.
- [ ] Backup file exports + restores on a fresh device; Data Integrity finds and fixes issues.
- [ ] Fresh Start clears data (with safety backup) and app returns to clean first-run state; **no demo data anywhere**.
- [ ] Works fully offline (airplane mode) for every core action.
- [ ] Bundle budget met, Lighthouse mobile Performance ≥ 90 and Accessibility ≥ 95.
- [ ] UI feels modern, smooth and native-like on a real phone; dark mode complete; credit "Developed by Sanjaydat Kumar" visible in About/Settings.

## 15. OUT OF SCOPE (Phase 2 — do not build now)

Parent/student login app, online payment gateway, SMS/WhatsApp Business API automation, biometric/QR attendance, GPS bus tracking, timetable & homework, library & hostel modules, multi-branch. Design the data layer so these can be added later without migration pain.

# ⬆️ PROMPT END ⬆️

---

## Part 2 — Feature coverage checklist (aapke desktop software ka har feature)

| Desktop module | Mobile app me kahan |
|---|---|
| Login / Users & Roles / Change Password | 6.1, 6.20, section 5 |
| Dashboard + 14 stats + 6 charts | 6.2 |
| Students (admission, profile, TC, left, restore, photo) | 6.3 |
| Classes & Sections | 6.4 |
| Teachers | 6.5 |
| Attendance (daily + monthly summary) | 6.6 |
| Fees (structure, dues, collect, receipt) | 6.7 |
| Demand Bills (bulk) | 6.8 |
| Family/Sibling billing | 6.9 |
| Exams, marks, ranks, marksheets, progress report | 6.10 |
| Promotion (normal + rank) | 6.11 |
| Payroll + salary slip | 6.12 |
| Transport | 6.13 |
| Reports (10) + CSV | 6.14 |
| Notifications | 6.15 |
| Backup / Restore / Data Integrity | 6.16 |
| Excel Tools (import/export) | 6.17 |
| Settings + logo + theme | 6.18 |
| Fresh Start / Factory Reset (naya feature) | 6.19 |
| ID card front + back, receipt, TC, slips, certificates | 6.10–6.13, section 10 |

## Part 3 — Uske baad ke prompts (zaroorat pade to mujhse maang lein)

1. **"Sync backend prompt"** — Supabase/Fastify sync + multi-user login + row level security (Mode B).
2. **"Play Store prompt"** — PWA ko TWA/Bubblewrap se Android app banane ke exact steps (Bubblewrap CLI, signing key, Play Console listing).
3. **"Parent app prompt"** — parent login, fees due, attendance, results, notification push.
4. **"Import old data prompt"** — aapke purane Python/SQLite ERP ka data naye mobile app me migrate karne ka mapping.

## Chhoti-si salaah (important)

- Pehle **Mode A (offline, single device)** banao — 1 hafte me chalu ho jayega aur koi server kharcha nahi.
- School ke 3–4 staff ek hi data par kaam karna chahein tabhi Mode B (sync) me jao — usme hosting + accounts ka kharcha aata hai.
- Mobile me **backup habit** sabse zaroori hai (browser data delete hone par data ja sakta hai) — isliye backup prompt me 6.16 pehle din se hai.
