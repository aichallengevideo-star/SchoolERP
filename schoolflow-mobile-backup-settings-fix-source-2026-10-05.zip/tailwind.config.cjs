module.exports = {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: { extend: { colors: { brand: { 500: '#5b5ce2', 600: '#4e4fcf', 700: '#4142b5' } } } },
  plugins: []
}
