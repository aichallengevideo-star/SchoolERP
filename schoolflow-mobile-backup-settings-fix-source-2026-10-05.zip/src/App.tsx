import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import {
  BrowserRouter,
  Link,
  Navigate,
  Outlet,
  Route,
  Routes,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import {
  Activity,
  ArrowRight,
  Bell,
  BookOpenCheck,
  BusFront,
  CalendarDays,
  ChevronDown,
  CircleHelp,
  ClipboardList,
  CreditCard,
  FileChartColumn,
  GraduationCap,
  Home,
  KeyRound,
  LogOut,
  Menu,
  Moon,
  MoreHorizontal,
  PanelLeftClose,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Sparkles,
  Sun,
  Users,
  WalletCards,
  Wifi,
  WifiOff,
  X,
} from "lucide-react";
import { ensureSeed, db, saveSetting, setting } from "./db";
import { useAuth, loginLocal, ToastProvider, useToast } from "./state";
import { Button, Input } from "./ui";
import {
  hashDesktopPassword,
  hashPassword,
  money,
  setupRedirectPath,
  verifyStoredPassword,
} from "./lib";
import type { Role } from "./types";

const HomePage = lazy(() =>
  import("./pages").then((m) => ({ default: m.HomePage })),
);
const StudentsPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.StudentsPage })),
);
const ClassesPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.ClassesPage })),
);
const TeachersPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.TeachersPage })),
);
const AttendancePage = lazy(() =>
  import("./pages").then((m) => ({ default: m.AttendancePage })),
);
const AttendanceSummaryPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.AttendanceSummaryPage })),
);
const FeesPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.FeesPage })),
);
const FeeStructurePage = lazy(() =>
  import("./pages").then((m) => ({ default: m.FeeStructurePage })),
);
const PendingFeesPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.PendingFeesPage })),
);
const FeeLedgerPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.FeeLedgerPage })),
);
const DemandBillsPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.DemandBillsPage })),
);
const FamilyBillingPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.FamilyBillingPage })),
);
const ExamsPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.ExamsPage })),
);
const PromotionPage = lazy(() =>
  import("./promotion").then((m) => ({ default: m.PromotionPage })),
);
const PayrollPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.PayrollPage })),
);
const TransportPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.TransportPage })),
);
const ReportsPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.ReportsPage })),
);
const NotificationsPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.NotificationsPage })),
);
const BackupPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.BackupPage })),
);
const IntegrityPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.IntegrityPage })),
);
const ExcelToolsPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.ExcelToolsPage })),
);
const SettingsPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.SettingsPage })),
);
const PersonalSettingsPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.PersonalSettingsPage })),
);
const UsersPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.UsersPage })),
);
const ChangePasswordPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.ChangePasswordPage })),
);
const SetupPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.SetupPage })),
);
const FreshStartPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.FreshStartPage })),
);
const AboutPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.AboutPage })),
);
const ExitPage = lazy(() =>
  import("./pages").then((m) => ({ default: m.ExitPage })),
);

const navLinks = [
  { to: "/home", label: "Overview", icon: Home, group: "Workspace" },
  { to: "/students", label: "Students", icon: Users, group: "School" },
  { to: "/classes", label: "Classes", icon: BookOpenCheck, group: "School" },
  { to: "/teachers", label: "Teachers", icon: GraduationCap, group: "School" },
  {
    to: "/attendance",
    label: "Attendance",
    icon: CalendarDays,
    group: "School",
  },
  { to: "/fees", label: "Fee collection", icon: CreditCard, group: "Finance" },
  {
    to: "/fees/pending",
    label: "Pending fees",
    icon: WalletCards,
    group: "Finance",
  },
  {
    to: "/fees/ledger",
    label: "Fee ledger",
    icon: FileChartColumn,
    group: "Finance",
  },
  {
    to: "/exams",
    label: "Exams & results",
    icon: ClipboardList,
    group: "Academics",
  },
  { to: "/promotion", label: "Promotion", icon: Sparkles, group: "Academics" },
  { to: "/payroll", label: "Payroll", icon: WalletCards, group: "Finance" },
  { to: "/transport", label: "Transport", icon: BusFront, group: "Operations" },
  {
    to: "/reports",
    label: "Reports",
    icon: FileChartColumn,
    group: "Operations",
  },
];
const moreLinks = [
  { to: "/attendance/summary", label: "Attendance summary", icon: Activity },
  { to: "/fees/structure", label: "Fee structures", icon: CreditCard },
  { to: "/fees/ledger", label: "Fee ledger", icon: FileChartColumn },
  { to: "/demand-bills", label: "Demand bills", icon: ClipboardList },
  { to: "/family-billing", label: "Family billing", icon: Users },
  { to: "/notifications", label: "Notifications", icon: Bell },
  { to: "/backup", label: "Backup & restore", icon: ShieldCheck },
  { to: "/data-integrity", label: "Data integrity", icon: ShieldCheck },
  { to: "/excel-tools", label: "Excel tools", icon: FileChartColumn },
  { to: "/users", label: "Users & roles", icon: Users },
  { to: "/preferences", label: "Settings", icon: Settings },
  { to: "/settings", label: "School settings", icon: Settings },
  { to: "/fresh-start", label: "Fresh start", icon: PanelLeftClose },
  { to: "/about", label: "About", icon: CircleHelp },
  { to: "/exit", label: "Exit app", icon: LogOut },
];
const rolesAllowed: Record<string, Role[]> = {
  "/payroll": ["Admin", "Principal", "Accountant"],
  "/fees/structure": ["Admin", "Accountant"],
  "/fees/pending": ["Admin", "Accountant", "Principal"],
  "/fees/ledger": ["Admin", "Accountant", "Principal"],
  "/fees": ["Admin", "Accountant", "Principal"],
  "/demand-bills": ["Admin", "Accountant"],
  "/family-billing": ["Admin", "Accountant"],
  "/users": ["Admin"],
  "/fresh-start": ["Admin"],
  "/settings": ["Admin"],
  "/setup": ["Admin"],
  "/backup": ["Admin", "Accountant"],
  "/promotion": ["Admin", "Principal"],
  "/data-integrity": ["Admin", "Accountant"],
  "/excel-tools": ["Admin", "Accountant"],
  "/teachers": ["Admin", "Principal"],
  "/transport": ["Admin", "Reception", "Accountant"],
  "/attendance": ["Admin", "Principal", "Teacher"],
  "/exams": ["Admin", "Principal", "Teacher"],
  "/classes": ["Admin", "Principal", "Teacher"],
  "/students": ["Admin", "Principal", "Teacher", "Reception", "Accountant"],
  "/reports": ["Admin", "Principal", "Accountant", "Reception"],
  "/notifications": [
    "Admin",
    "Principal",
    "Teacher",
    "Accountant",
    "Reception",
  ],
};
function allowed(path: string, role: Role) {
  const match = Object.entries(rolesAllowed)
    .filter(([key]) => path === key || path.startsWith(`${key}/`))
    .sort(([a], [b]) => b.length - a.length)[0];
  if (match) return match[1].includes(role);
  return true;
}

export default function App() {
  const [ready, setReady] = useState(false);
  const setUser = useAuth((s) => s.setUser);
  useEffect(() => {
    let active = true;
    ensureSeed()
      .then(async () => {
        const raw =
          localStorage.getItem("schoolflow-session") ||
          sessionStorage.getItem("schoolflow-session");
        if (raw) {
          try {
            const session = JSON.parse(raw);
            const actual = await db.users.get(Number(session.id));
            if (actual?.status === "Active")
              setUser({
                id: actual.id!,
                username: actual.username,
                fullName: actual.fullName,
                role: actual.role,
                teacherId: actual.teacherId,
              });
            else localStorage.removeItem("schoolflow-session");
          } catch {
            localStorage.removeItem("schoolflow-session");
          }
        }
        if (active) setReady(true);
      })
      .catch(() => setReady(true));
    return () => {
      active = false;
    };
  }, [setUser]);
  if (!ready)
    return (
      <div className="boot-screen">
        <div className="brand-mark">S</div>
        <span className="spinner" />
        <span>Getting your school ready…</span>
      </div>
    );
  return (
    <ToastProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route element={<ProtectedShell />}>
            <Route
              path="/home"
              element={
                <Page>
                  <HomePage />
                </Page>
              }
            />
            <Route
              path="/setup"
              element={
                <Page>
                  <SetupPage />
                </Page>
              }
            />
            <Route
              path="/students"
              element={
                <Page>
                  <StudentsPage />
                </Page>
              }
            />
            <Route
              path="/students/new"
              element={
                <Page>
                  <StudentsPage />
                </Page>
              }
            />
            <Route
              path="/students/:id"
              element={
                <Page>
                  <StudentsPage />
                </Page>
              }
            />
            <Route
              path="/classes"
              element={
                <Page>
                  <ClassesPage />
                </Page>
              }
            />
            <Route
              path="/teachers"
              element={
                <Page>
                  <TeachersPage />
                </Page>
              }
            />
            <Route
              path="/attendance"
              element={
                <Page>
                  <AttendancePage />
                </Page>
              }
            />
            <Route
              path="/attendance/summary"
              element={
                <Page>
                  <AttendanceSummaryPage />
                </Page>
              }
            />
            <Route
              path="/fees"
              element={
                <Page>
                  <FeesPage />
                </Page>
              }
            />
            <Route
              path="/fees/structure"
              element={
                <Page>
                  <FeeStructurePage />
                </Page>
              }
            />
            <Route
              path="/fees/pending"
              element={
                <Page>
                  <PendingFeesPage />
                </Page>
              }
            />
            <Route
              path="/fees/ledger"
              element={
                <Page>
                  <FeeLedgerPage />
                </Page>
              }
            />
            <Route
              path="/demand-bills"
              element={
                <Page>
                  <DemandBillsPage />
                </Page>
              }
            />
            <Route
              path="/family-billing"
              element={
                <Page>
                  <FamilyBillingPage />
                </Page>
              }
            />
            <Route
              path="/exams"
              element={
                <Page>
                  <ExamsPage />
                </Page>
              }
            />
            <Route
              path="/exams/:id/marks"
              element={
                <Page>
                  <ExamsPage />
                </Page>
              }
            />
            <Route
              path="/exams/:id/ranks"
              element={
                <Page>
                  <ExamsPage />
                </Page>
              }
            />
            <Route
              path="/promotion"
              element={
                <Page>
                  <PromotionPage />
                </Page>
              }
            />
            <Route
              path="/payroll"
              element={
                <Page>
                  <PayrollPage />
                </Page>
              }
            />
            <Route
              path="/transport"
              element={
                <Page>
                  <TransportPage />
                </Page>
              }
            />
            <Route
              path="/reports"
              element={
                <Page>
                  <ReportsPage />
                </Page>
              }
            />
            <Route
              path="/notifications"
              element={
                <Page>
                  <NotificationsPage />
                </Page>
              }
            />
            <Route
              path="/backup"
              element={
                <Page>
                  <BackupPage />
                </Page>
              }
            />
            <Route
              path="/data-integrity"
              element={
                <Page>
                  <IntegrityPage />
                </Page>
              }
            />
            <Route
              path="/excel-tools"
              element={
                <Page>
                  <ExcelToolsPage />
                </Page>
              }
            />
            <Route
              path="/preferences"
              element={
                <Page>
                  <PersonalSettingsPage />
                </Page>
              }
            />
            <Route
              path="/settings"
              element={
                <Page>
                  <SettingsPage />
                </Page>
              }
            />
            <Route
              path="/users"
              element={
                <Page>
                  <UsersPage />
                </Page>
              }
            />
            <Route
              path="/change-password"
              element={
                <Page>
                  <ChangePasswordPage />
                </Page>
              }
            />
            <Route
              path="/fresh-start"
              element={
                <Page>
                  <FreshStartPage />
                </Page>
              }
            />
            <Route
              path="/about"
              element={
                <Page>
                  <AboutPage />
                </Page>
              }
            />
            <Route
              path="/exit"
              element={
                <Page>
                  <ExitPage />
                </Page>
              }
            />
            <Route path="*" element={<Navigate to="/home" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ToastProvider>
  );
}
function Page({ children }: { children: React.ReactNode }) {
  return (
    <Suspense
      fallback={
        <div className="page-loading">
          <span className="spinner" />
          Loading screen…
        </div>
      }
    >
      {children}
    </Suspense>
  );
}

function ProtectedShell() {
  const user = useAuth((s) => s.user);
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const schoolName =
    useLiveQuery(() => setting<string>("schoolName", ""), []) || "";
  const theme =
    useLiveQuery(() => setting<string>("theme", "light"), []) || "light";
  const setupComplete = useLiveQuery(
    () => setting<boolean>("setupComplete", false),
    [],
  );
  const autoLockMinutes =
    useLiveQuery(() => setting<number>("autoLockMinutes", 15), [], 15) ?? 15;
  const mustChange = useLiveQuery<boolean, boolean>(
    () =>
      user
        ? db.users.get(user.id).then((row) => Boolean(row?.mustChange))
        : Promise.resolve(false),
    [user?.id],
    false,
  );
  const unread =
    useLiveQuery(
      async () => {
        if (!user) return 0;
        const rows = await db.notifications
          .filter((notice) => !notice.isRead)
          .toArray();
        if (user.role !== "Teacher")
          return rows.filter((notice) => allowed(notice.module, user.role))
            .length;
        const assignedClasses = user.teacherId
          ? await db.classes
              .filter(
                (schoolClass) =>
                  schoolClass.teacherId === user.teacherId &&
                  !schoolClass.deletedAt &&
                  schoolClass.status === "Active",
              )
              .toArray()
          : [];
        const assignedKeys = new Set(
          assignedClasses.map(
            (schoolClass) =>
              `${schoolClass.id}|${schoolClass.section}|${schoolClass.session}`,
          ),
        );
        const studentRows = await db.students
          .filter(
            (student) =>
              !student.deletedAt &&
              assignedKeys.has(
                `${student.classId}|${student.section}|${student.session}`,
              ),
          )
          .toArray();
        const examRows = await db.exams.toArray();
        const assignedStudentIds = new Set(
          studentRows.map((student) => student.id),
        );
        const assignedExamIds = new Set(
          examRows
            .filter((exam) =>
              assignedKeys.has(
                `${exam.classId}|${exam.section}|${exam.session}`,
              ),
            )
            .map((exam) => exam.id),
        );
        return rows.filter((notice) => {
          if (!allowed(notice.module, user.role)) return false;
          if (notice.type === "birthday" || notice.type === "attendance")
            return assignedStudentIds.has(Number(notice.relatedId));
          if (notice.type === "exam")
            return assignedExamIds.has(Number(notice.relatedId));
          return false;
        }).length;
      },
      [user?.id, user?.role, user?.teacherId],
      0,
    ) ?? 0;
  const [online, setOnline] = useState(navigator.onLine);
  const [moreOpen, setMoreOpen] = useState(false);
  const [mobileMore, setMobileMore] = useState(false);
  const [globalSearch, setGlobalSearch] = useState(false);
  const [globalQuery, setGlobalQuery] = useState("");
  const [matches, setMatches] = useState<
    { id: number; name: string; className: string; adm: string }[]
  >([]);
  const [locked, setLocked] = useState(false);
  const [lockPassword, setLockPassword] = useState("");
  const [lockError, setLockError] = useState("");
  const [unlocking, setUnlocking] = useState(false);
  const lastActivityAt = useRef(Date.now());
  const lockedRef = useRef(false);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);
  useEffect(() => {
    lockedRef.current = locked;
  }, [locked]);
  useEffect(() => {
    if (!user) {
      lockedRef.current = false;
      setLocked(false);
      return;
    }
    const timeoutMs = Math.max(0, Number(autoLockMinutes) || 0) * 60_000;
    const storedActivity = Number(
      localStorage.getItem("schoolflow-last-activity") ||
        sessionStorage.getItem("schoolflow-last-activity") ||
        0,
    );
    lastActivityAt.current = storedActivity > 0 ? storedActivity : Date.now();
    if (!timeoutMs) return;
    const lockIfIdle = () => {
      if (
        !lockedRef.current &&
        Date.now() - lastActivityAt.current >= timeoutMs
      ) {
        lockedRef.current = true;
        setLockPassword("");
        setLockError("");
        setLocked(true);
      }
    };
    const recordActivity = () => {
      if (lockedRef.current) return;
      const now = Date.now();
      if (now - lastActivityAt.current >= timeoutMs) {
        lockIfIdle();
        return;
      }
      if (now - lastActivityAt.current > 1000) {
        lastActivityAt.current = now;
        try {
          const storage = localStorage.getItem("schoolflow-session")
            ? localStorage
            : sessionStorage;
          storage.setItem("schoolflow-last-activity", String(now));
        } catch {
          // Idle locking still works in memory when browser storage is unavailable.
        }
      }
    };
    const onVisibility = () => {
      if (document.visibilityState === "visible") lockIfIdle();
    };
    const timer = window.setInterval(lockIfIdle, 5_000);
    window.addEventListener("pointerdown", recordActivity, { passive: true });
    window.addEventListener("pointermove", recordActivity, { passive: true });
    window.addEventListener("keydown", recordActivity);
    window.addEventListener("touchstart", recordActivity, { passive: true });
    window.addEventListener("wheel", recordActivity, { passive: true });
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener("pointerdown", recordActivity);
      window.removeEventListener("pointermove", recordActivity);
      window.removeEventListener("keydown", recordActivity);
      window.removeEventListener("touchstart", recordActivity);
      window.removeEventListener("wheel", recordActivity);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [user?.id, autoLockMinutes]);
  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const applyTheme = () => {
      document.documentElement.dataset.theme =
        theme === "system"
          ? media.matches
            ? "dark"
            : "light"
          : theme === "dark"
            ? "dark"
            : "light";
    };
    applyTheme();
    if (theme === "system") media.addEventListener("change", applyTheme);
    document.documentElement.style.setProperty(
      "--text-scale",
      `${Number(localStorage.getItem("schoolflow-text-scale") || 100)}%`,
    );
    return () => media.removeEventListener("change", applyTheme);
  }, [theme]);
  useEffect(() => {
    if (!user || location.pathname === "/change-password") return;
    if (setupComplete === undefined) return;
    let active = true;
    void setting<boolean>("setupComplete", false)
      .then((isComplete) => {
        if (!active) return;
        const destination = setupRedirectPath(location.pathname, isComplete);
        if (destination) navigate(destination, { replace: true });
      })
      .catch(() => {
        if (!active) return;
        const destination = setupRedirectPath(location.pathname, setupComplete);
        if (destination) navigate(destination, { replace: true });
      });
    return () => {
      active = false;
    };
  }, [setupComplete, user, location.pathname, navigate]);
  useEffect(() => {
    let active = true;
    if (!globalQuery.trim()) {
      setMatches([]);
      return;
    }
    const timer = setTimeout(async () => {
      const q = globalQuery.trim().toLowerCase();
      const assignedClassKeys =
        user?.role === "Teacher"
          ? new Set(
              user.teacherId
                ? (
                    await db.classes
                      .filter(
                        (item) =>
                          item.teacherId === user.teacherId &&
                          !item.deletedAt &&
                          item.status === "Active",
                      )
                      .toArray()
                  ).map((item) => `${item.id}|${item.section}|${item.session}`)
                : [],
            )
          : null;
      const all = await db.students
        .filter(
          (s) =>
            !s.deletedAt &&
            (!assignedClassKeys ||
              assignedClassKeys.has(
                `${s.classId}|${s.section}|${s.session}`,
              )) &&
            [
              s.name,
              s.admissionNo,
              s.father,
              s.mother,
              s.mobile,
              s.aadhaar,
              String(s.roll),
              s.section,
              s.session,
            ].some((value) =>
              String(value || "")
                .toLowerCase()
                .includes(q),
            ),
        )
        .limit(7)
        .toArray();
      const rows = await Promise.all(
        all.map(async (s) => {
          const schoolClass = await db.classes.get(s.classId);
          return {
            id: s.id!,
            name: s.name,
            className: `${schoolClass?.name || "Class"}-${s.section}`,
            adm: s.admissionNo,
          };
        }),
      );
      if (active) setMatches(rows);
    }, 220);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [globalQuery, user?.role, user?.teacherId]);
  if (!user)
    return <Navigate to="/" replace state={{ from: location.pathname }} />;
  if (mustChange && location.pathname !== "/change-password")
    return <Navigate to="/change-password" replace />;
  if (
    user &&
    location.pathname !== "/change-password" &&
    !allowed(location.pathname, user.role)
  )
    return <Navigate to="/home" replace />;
  if (setupComplete === undefined && location.pathname !== "/change-password")
    return (
      <div className="boot-screen">
        <div className="brand-mark">S</div>
        <span className="spinner" />
        <span>Checking school setup…</span>
      </div>
    );
  const logout = () => {
    localStorage.removeItem("schoolflow-session");
    sessionStorage.removeItem("schoolflow-session");
    localStorage.removeItem("schoolflow-last-activity");
    sessionStorage.removeItem("schoolflow-last-activity");
    lockedRef.current = false;
    setLocked(false);
    useAuth.getState().setUser(null);
    toast("Signed out securely.", "info");
    navigate("/");
  };
  const unlockSession = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!user || !lockPassword) return;
    setUnlocking(true);
    setLockError("");
    try {
      const record = await db.users.get(user.id);
      if (!record || record.status !== "Active") {
        logout();
        return;
      }
      if (!(await verifyStoredPassword(lockPassword, record))) {
        setLockError("Password sahi nahi hai. Dobara try karein.");
        return;
      }
      if (
        record.passwordAlgorithm === "bcrypt" ||
        !record.salt ||
        /^\$2[aby]\$/.test(record.passwordHash)
      ) {
        const salt = crypto.randomUUID();
        await db.users.update(record.id!, {
          salt,
          passwordHash: await hashPassword(lockPassword, salt),
          passwordAlgorithm: "sha256",
          desktopPasswordHash:
            record.desktopPasswordHash || record.passwordHash,
        });
      } else if (!record.desktopPasswordHash) {
        await db.users.update(record.id!, {
          desktopPasswordHash: await hashDesktopPassword(lockPassword),
        });
      }
      useAuth.getState().setUser({
        id: record.id!,
        username: record.username,
        fullName: record.fullName,
        role: record.role,
        teacherId: record.teacherId,
      });
      lastActivityAt.current = Date.now();
      try {
        const storage = localStorage.getItem("schoolflow-session")
          ? localStorage
          : sessionStorage;
        storage.setItem(
          "schoolflow-last-activity",
          String(lastActivityAt.current),
        );
      } catch {
        // The current session remains unlocked in memory.
      }
      lockedRef.current = false;
      setLocked(false);
      setLockPassword("");
      toast("Session unlocked.", "success");
    } catch {
      setLockError("Verification nahi ho saki. Dobara try karein.");
    } finally {
      setUnlocking(false);
    }
  };
  const isDarkTheme =
    theme === "dark" ||
    (theme === "system" &&
      window.matchMedia("(prefers-color-scheme: dark)").matches);
  const switchTheme = async () => {
    const next = isDarkTheme ? "light" : "dark";
    await saveSetting("theme", next);
    toast(`${next === "dark" ? "Dark" : "Light"} theme enabled.`);
  };
  const title =
    [...navLinks, ...moreLinks].find(
      (n) =>
        location.pathname === n.to || location.pathname.startsWith(`${n.to}/`),
    )?.label ||
    (location.pathname === "/setup" ? "School setup" : "Your workspace");
  return (
    <div className="app-frame">
      <aside className="sidebar">
        <Link to="/home" className="brand-lockup">
          <div className="brand-mark">S</div>
          <div>
            <strong>schoolflow</strong>
            <span>school ERP</span>
          </div>
          <button className="sidebar-toggle" aria-label="Collapse sidebar">
            <PanelLeftClose size={16} />
          </button>
        </Link>
        <div className="school-switch">
          <div className="school-avatar">
            {(schoolName || "S").slice(0, 1).toUpperCase()}
          </div>
          <div className="school-switch-copy">
            <strong>{schoolName || "Your school"}</strong>
            <span>{user.role} workspace</span>
          </div>
          <ChevronDown size={14} />
        </div>
        <nav className="side-nav">
          {["Workspace", "School", "Finance", "Academics", "Operations"].map(
            (group) => {
              const items = navLinks.filter(
                (n) => n.group === group && allowed(n.to, user.role),
              );
              return items.length ? (
                <div className="nav-group" key={group}>
                  <span className="nav-label">{group}</span>
                  {items.map((item) => {
                    const Icon = item.icon;
                    const active =
                      location.pathname === item.to ||
                      (item.to !== "/home" &&
                        location.pathname.startsWith(`${item.to}/`));
                    return (
                      <Link
                        key={item.to}
                        to={item.to}
                        className={`side-link ${active ? "active" : ""}`}
                      >
                        <Icon size={18} strokeWidth={active ? 2.3 : 1.8} />
                        <span>{item.label}</span>
                        {active && <span className="active-indicator" />}
                      </Link>
                    );
                  })}
                </div>
              ) : null;
            },
          )}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-tip">
            <div className="tip-icon">
              <Sparkles size={15} />
            </div>
            <strong>Always in sync with you</strong>
            <p>Your school data stays safely on this device.</p>
            <Link to="/backup">
              View backup settings <ArrowUpRightIcon />
            </Link>
          </div>
          <button className="side-link logout-link" onClick={logout}>
            <LogOut size={18} />
            <span>Sign out</span>
          </button>
        </div>
      </aside>
      <div className="main-column">
        <header className="topbar">
          <div className="topbar-left">
            <button
              className="mobile-brand-button"
              onClick={() => navigate("/home")}
            >
              <span className="brand-mark small">S</span>
            </button>
            <div className="breadcrumb">
              <span>{schoolName || "Your school"}</span>
              <b>/</b>
              <strong>{title}</strong>
            </div>
          </div>
          <div className="topbar-right">
            <button
              className="topbar-search"
              onClick={() => setGlobalSearch((v) => !v)}
              aria-label="Search students"
            >
              <Search size={17} />
              <span>Search anything</span>
              <kbd>⌘ K</kbd>
            </button>
            <div
              className={`connection-chip ${online ? "connected" : "disconnected"}`}
            >
              {online ? <Wifi size={14} /> : <WifiOff size={14} />}
              <span>{online ? "Offline ready" : "Offline"}</span>
            </div>
            <button
              className="icon-button theme-toggle"
              onClick={switchTheme}
              aria-label="Toggle theme"
            >
              {isDarkTheme ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <Link
              className="icon-button notification-button"
              to="/notifications"
              aria-label="Notifications"
            >
              <Bell size={18} />
              {unread > 0 && <i>{unread > 9 ? "9+" : unread}</i>}
            </Link>
            <button
              className="profile-chip"
              onClick={() => setMoreOpen((v) => !v)}
            >
              <div className="profile-avatar">
                {user.fullName
                  .split(" ")
                  .map((s) => s[0])
                  .slice(0, 2)
                  .join("")}
              </div>
              <span>{user.fullName.split(" ")[0]}</span>
              <ChevronDown size={14} />
            </button>
            {moreOpen && (
              <div className="profile-menu">
                <div className="profile-menu-name">
                  {user.fullName}
                  <small>{user.role}</small>
                </div>
                <Link to="/preferences" onClick={() => setMoreOpen(false)}>
                  <Settings size={15} /> Settings
                </Link>
                <Link to="/change-password" onClick={() => setMoreOpen(false)}>
                  <KeyRound size={15} /> Change password
                </Link>
                <button onClick={logout}>
                  <LogOut size={15} /> Sign out
                </button>
              </div>
            )}
          </div>
        </header>
        {globalSearch && (
          <div className="global-search-pop">
            <div className="search-box global-search-box">
              <Search size={17} />
              <input
                autoFocus
                value={globalQuery}
                onChange={(e) => setGlobalQuery(e.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && matches[0]) {
                    setGlobalSearch(false);
                    setGlobalQuery("");
                    navigate(`/students/${matches[0].id}`);
                  } else if (event.key === "Escape") {
                    setGlobalSearch(false);
                    setGlobalQuery("");
                  }
                }}
                placeholder="Find a student by name, admission no, parent or phone…"
              />
              <button
                className="search-clear"
                onClick={() => {
                  setGlobalSearch(false);
                  setGlobalQuery("");
                }}
              >
                <X size={16} />
              </button>
            </div>
            {globalQuery && (
              <div className="global-search-results">
                {matches.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => {
                      setGlobalSearch(false);
                      setGlobalQuery("");
                      navigate(`/students/${m.id}`);
                    }}
                  >
                    <span className="search-result-avatar">{m.name[0]}</span>
                    <span>
                      <b>{m.name}</b>
                      <small>
                        {m.className} · {m.adm}
                      </small>
                    </span>
                    <ArrowUpRightIcon />
                  </button>
                ))}
                {!matches.length && (
                  <p className="search-no-results">
                    No students found. Search works on your saved records.
                  </p>
                )}
              </div>
            )}
          </div>
        )}
        {!online && (
          <div className="offline-banner">
            <WifiOff size={15} />
            You're offline. Saved records are still available on this device.
          </div>
        )}
        <main className="main-content">
          <Outlet />
        </main>
        <div
          className="mobile-more-overlay"
          data-show={mobileMore}
          onClick={() => setMobileMore(false)}
        >
          <div
            className="mobile-more-sheet"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sheet-handle" />
            <div className="more-sheet-head">
              <div>
                <small>YOUR WORKSPACE</small>
                <h2>More modules</h2>
              </div>
              <button
                className="icon-button"
                onClick={() => setMobileMore(false)}
              >
                <X size={18} />
              </button>
            </div>
            <div className="more-module-grid">
              {moreLinks
                .filter((l) => allowed(l.to, user.role))
                .map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      onClick={() => setMobileMore(false)}
                    >
                      <span>
                        <Icon size={19} />
                      </span>
                      <b>{item.label}</b>
                    </Link>
                  );
                })}
            </div>
            <button className="more-sheet-logout" onClick={logout}>
              <LogOut size={16} /> Sign out from SchoolFlow
            </button>
          </div>
        </div>
        <nav className="bottom-nav">
          <Link
            to="/home"
            className={location.pathname === "/home" ? "active" : ""}
          >
            <Home size={19} />
            <span>Home</span>
          </Link>
          <Link
            to="/students"
            className={
              location.pathname.startsWith("/students") ? "active" : ""
            }
          >
            <Users size={19} />
            <span>Students</span>
          </Link>
          {allowed("/fees", user.role) ? (
            <Link
              to="/fees"
              className={location.pathname.startsWith("/fees") ? "active" : ""}
            >
              <CreditCard size={19} />
              <span>Fees</span>
            </Link>
          ) : (
            <Link
              to="/attendance"
              className={
                location.pathname.startsWith("/attendance") ? "active" : ""
              }
            >
              <CalendarDays size={19} />
              <span>Attend</span>
            </Link>
          )}
          {allowed("/exams", user.role) ? (
            <Link
              to="/exams"
              className={location.pathname.startsWith("/exams") ? "active" : ""}
            >
              <ClipboardList size={19} />
              <span>Exams</span>
            </Link>
          ) : allowed("/reports", user.role) ? (
            <Link
              to="/reports"
              className={
                location.pathname.startsWith("/reports") ? "active" : ""
              }
            >
              <FileChartColumn size={19} />
              <span>Reports</span>
            </Link>
          ) : (
            <Link
              to="/notifications"
              className={
                location.pathname.startsWith("/notifications") ? "active" : ""
              }
            >
              <Bell size={19} />
              <span>Alerts</span>
            </Link>
          )}
          <button onClick={() => setMobileMore(true)}>
            <MoreHorizontal size={19} />
            <span>More</span>
          </button>
        </nav>
      </div>
      {locked && (
        <div
          className="auto-lock-screen"
          role="dialog"
          aria-modal="true"
          aria-labelledby="auto-lock-title"
        >
          <div className="auto-lock-card">
            <span className="auto-lock-icon">
              <KeyRound size={24} />
            </span>
            <span className="card-eyebrow">SESSION PAUSED</span>
            <h1 id="auto-lock-title">
              Welcome back, {user.fullName.split(" ")[0]}.
            </h1>
            <p>
              Your workspace locked after inactivity. Re-enter your password to
              continue.
            </p>
            <form onSubmit={(event) => void unlockSession(event)}>
              <Input
                label="Password"
                type="password"
                autoComplete="current-password"
                autoFocus
                required
                value={lockPassword}
                onChange={(event) => setLockPassword(event.target.value)}
                error={lockError}
              />
              <Button
                size="lg"
                className="full-width"
                type="submit"
                disabled={unlocking || !lockPassword}
              >
                {unlocking ? "Checking…" : "Unlock workspace"}
                <ArrowRight size={16} />
              </Button>
            </form>
            <button className="auto-lock-signout" onClick={logout}>
              <LogOut size={15} /> Sign out instead
            </button>
            <small>Data remains saved locally on this device.</small>
          </div>
        </div>
      )}
    </div>
  );
}
function ArrowUpRightIcon() {
  return <span className="mini-arrow">↗</span>;
}

function LoginPage() {
  const user = useAuth((s) => s.user);
  const navigate = useNavigate();
  const { toast } = useToast();
  const [username, setUsername] = useState(
    () => localStorage.getItem("schoolflow-last-username") || "admin",
  );
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [loginRedirect, setLoginRedirect] = useState<string | null>(null);
  const schoolName =
    useLiveQuery(() => setting<string>("schoolName", ""), []) || "";
  useEffect(() => {
    if (user && !loginRedirect) {
      void (async () => {
        const actual = await db.users.get(user.id);
        const done = await setting<boolean>("setupComplete", false);
        navigate(
          actual?.mustChange ? "/change-password" : done ? "/home" : "/setup",
          { replace: true },
        );
      })();
    }
  }, [user, loginRedirect, navigate]);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const result = await loginLocal(username, password, remember);
      if (!result.ok) {
        setError(result.message);
        return;
      }
      const done = await setting<boolean>("setupComplete", false);
      const destination = result.mustChange
        ? "/change-password"
        : done
          ? "/home"
          : "/setup";
      setLoginRedirect(destination);
      toast(`Welcome back, ${username}.`, "success");
      navigate(destination, { replace: true });
    } catch {
      setError("Login nahi ho saka. Please try again.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="login-screen">
      <div className="login-showcase">
        <div className="login-showcase-top">
          <Link to="/" className="brand-lockup login-brand">
            <div className="brand-mark">S</div>
            <div>
              <strong>schoolflow</strong>
              <span>school ERP</span>
            </div>
          </Link>
          <div className="showcase-pill">
            <span className="status-pulse" /> DESIGNED FOR INDIAN SCHOOLS
          </div>
        </div>
        <div className="showcase-content">
          <div className="showcase-kicker">
            <span>✦</span> Your school, beautifully organised
          </div>
          <h1>
            More time for
            <br />
            <em>what matters.</em>
          </h1>
          <p>
            One calm workspace for students, fees, attendance and the everyday
            rhythm of your school.
          </p>
          <div className="showcase-visual">
            <div className="visual-orbit orbit-one" />
            <div className="visual-orbit orbit-two" />
            <div className="visual-card card-main">
              <div className="visual-card-top">
                <div className="visual-mini-logo">S</div>
                <span>THIS MONTH</span>
                <span className="visual-dots">•••</span>
              </div>
              <strong>School at a glance</strong>
              <div className="visual-stats">
                <div>
                  <i className="visual-dot indigo" />
                  <b>Students</b>
                  <span>Ready</span>
                </div>
                <div>
                  <i className="visual-dot green" />
                  <b>Attendance</b>
                  <span>On track</span>
                </div>
                <div>
                  <i className="visual-dot amber" />
                  <b>Fee desk</b>
                  <span>Organised</span>
                </div>
              </div>
              <div className="visual-chart">
                <div />
                <div />
                <div />
                <div />
                <div />
                <div />
                <div />
                <div />
                <div />
                <div />
                <div />
                <div />
              </div>
            </div>
            <div className="float-note note-one">
              <span className="float-icon purple">
                <CalendarDays size={15} />
              </span>
              <span>
                <b>Attendance</b>
                <small>Simple. Every day.</small>
              </span>
            </div>
            <div className="float-note note-two">
              <span className="float-icon green">
                <ShieldCheck size={15} />
              </span>
              <span>
                <b>Offline-first</b>
                <small>Your data stays yours</small>
              </span>
            </div>
          </div>
        </div>
        <div className="showcase-footer">
          <span>◌</span> Private by design <i /> Works offline <i /> Made for
          the people who make schools
        </div>
      </div>
      <div className="login-panel">
        <div className="login-mobile-brand">
          <div className="brand-mark">S</div>
          <b>schoolflow</b>
        </div>
        <div className="login-card-wrap">
          <div className="login-heading">
            <span className="welcome-overline">WELCOME BACK</span>
            <h2>
              Sign in to your
              <br />
              workspace<span>.</span>
            </h2>
            <p>{schoolName || "A clearer view of your school starts here."}</p>
          </div>
          <form className="login-form" onSubmit={submit}>
            <Input
              label="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              required
              placeholder="Enter your username"
            />
            <Input
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              required
              placeholder="Enter your password"
            />
            {error && <div className="form-alert">{error}</div>}
            <div className="login-options">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                />{" "}
                <span>Remember me</span>
              </label>
              <span className="muted-help">
                Forgot password? Ask your admin
              </span>
            </div>
            <Button
              type="submit"
              size="lg"
              className="login-submit"
              disabled={busy}
            >
              {busy ? (
                "Signing in…"
              ) : (
                <>
                  Sign in securely <span>→</span>
                </>
              )}
            </Button>
          </form>
          <div className="login-note">
            <span className="secure-icon">
              <ShieldCheck size={16} />
            </span>
            <p>
              Your sign-in is verified on this device. Your data never leaves
              your browser.
            </p>
          </div>
          <div className="login-credits">
            Developed by <b>Sanjaydat Kumar</b>
            <span>·</span> Version 1.0.0
          </div>
        </div>
      </div>
    </div>
  );
}
