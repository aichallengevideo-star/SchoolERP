import { Component, type ErrorInfo, type ReactNode } from 'react'
import { db, tablesForBackup } from './db'
import { saveFile, todayISO } from './lib'

export class ErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean; exporting: boolean }> {
  state = { failed: false, exporting: false }

  static getDerivedStateFromError() { return { failed: true } }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('SchoolFlow screen error:', error, info.componentStack)
  }

  exportData = async () => {
    this.setState({ exporting: true })
    try {
      const tables: Record<string, unknown[]> = {}
      for (const name of tablesForBackup) tables[name] = await db.table(name).toArray()
      const blob = new Blob([JSON.stringify({ app: 'SchoolFlow', version: 1, createdAt: new Date().toISOString(), tables })], { type: 'application/vnd.schoolflow.backup+json' })
      saveFile(blob, `schoolflow-emergency-export-${todayISO()}.schoolerp`)
    } catch (error) {
      console.error('Emergency export failed:', error)
    } finally {
      this.setState({ exporting: false })
    }
  }

  render() {
    if (!this.state.failed) return this.props.children
    return <main className="error-screen">
      <div className="error-mark">S</div>
      <span className="card-eyebrow">A QUICK PAUSE</span>
      <h1>Something unexpected happened.</h1>
      <p>Your saved records are still in this browser. You can export a safety copy before restarting this screen.</p>
      <div className="error-actions">
        <button className="btn btn-secondary" onClick={() => void this.exportData()} disabled={this.state.exporting}>{this.state.exporting ? 'Preparing export…' : 'Export local data'}</button>
        <button className="btn" onClick={() => window.location.reload()}>Restart SchoolFlow</button>
      </div>
      <small>If this keeps happening, note what you were doing and try again after a refresh.</small>
    </main>
  }
}
