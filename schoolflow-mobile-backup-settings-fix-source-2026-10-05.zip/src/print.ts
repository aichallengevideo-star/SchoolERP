import { Capacitor } from "@capacitor/core";
import { Printer } from "@capgo/capacitor-printer";
import type { FamilyBill, FeeDue, FeePayment, Student } from "./types";
import {
  amountToWords,
  displayDate,
  displayMonth,
  gradeFor,
  money,
  saveFile,
  todayISO,
} from "./lib";

export interface PrintSchool {
  name?: string;
  address?: string;
  phone?: string;
  email?: string;
  website?: string;
  logo?: string;
  principalName?: string;
  printFooter?: string;
  receiptFooter?: string;
  paymentDetails?: string;
}

export const escapeHtml = (value: unknown) =>
  String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

export function openPrintDocument(
  title: string,
  content: string,
  extraCss = "",
) {
  const oldPreview = document.getElementById("schoolflow-print-preview");
  oldPreview?.remove();
  const previewHtml = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)}</title><style>
    *{box-sizing:border-box}html,body{min-height:100%;margin:0}body{padding:18px;background:#e9edf5;color:#171923;font:14px/1.45 Arial,sans-serif}.sheet{max-width:920px;margin:0 auto;background:#fff;padding:26px;border:1px solid #dfe2eb;box-shadow:0 8px 28px rgba(29,34,55,.12)}.school-head{text-align:center;border-bottom:2px solid #20212b;padding-bottom:12px;margin-bottom:16px}.school-head img{max-width:84px;max-height:64px;object-fit:contain}.school-head h1{margin:4px;font-size:23px}.school-head p{margin:2px;color:#555}.signatures{display:flex;justify-content:space-between;gap:20px;margin-top:50px}.signatures span{border-top:1px solid #555;padding-top:6px;min-width:140px;text-align:center;font-size:12px}.muted{color:#606574;font-size:11px}.row{display:flex;justify-content:space-between;gap:12px;padding:7px 0;border-bottom:1px solid #e7e8ef}.amount{font-size:18px;font-weight:700}
    @media print{html,body{min-height:auto;background:#fff!important;color:#111!important}body{padding:0!important}.sheet{max-width:none!important;margin:0!important;padding:0!important;border:0!important;box-shadow:none!important}@page{size:A4;margin:10mm}}
    ${extraCss}
  </style></head><body>${content}</body></html>`;
  const overlay = document.createElement("div");
  overlay.id = "schoolflow-print-preview";
  overlay.setAttribute("role", "dialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-label", `Print preview: ${title}`);
  overlay.style.cssText =
    "position:fixed;inset:0;z-index:2147483646;display:flex;align-items:center;justify-content:center;padding:14px;background:rgba(13,17,35,.72);backdrop-filter:blur(5px);";
  const panel = document.createElement("section");
  panel.style.cssText =
    "display:flex;flex-direction:column;width:min(1100px,100%);height:min(94dvh,1100px);overflow:hidden;border:1px solid #d9dced;border-radius:16px;background:#fff;box-shadow:0 24px 80px rgba(0,0,0,.3);";
  const toolbar = document.createElement("div");
  toolbar.style.cssText =
    "display:flex;align-items:center;gap:10px;min-height:58px;padding:8px 12px;border-bottom:1px solid #e4e6ef;background:#fff;font:13px/1.3 system-ui,Arial,sans-serif;";
  const heading = document.createElement("div");
  heading.textContent = `Print preview · ${title}`;
  heading.style.cssText =
    "flex:1;min-width:0;overflow:hidden;color:#22243a;font-weight:700;text-overflow:ellipsis;white-space:nowrap;";
  const printButton = document.createElement("button");
  printButton.type = "button";
  printButton.textContent = "Print / Save PDF";
  printButton.setAttribute("aria-label", "Print or save this preview as PDF");
  printButton.style.cssText =
    "min-height:40px;padding:0 15px;border:0;border-radius:9px;background:#5558d9;color:#fff;font:650 13px system-ui,Arial,sans-serif;cursor:pointer;";
  const closeButton = document.createElement("button");
  closeButton.type = "button";
  closeButton.textContent = "Close";
  closeButton.setAttribute("aria-label", "Close print preview");
  closeButton.style.cssText =
    "min-height:40px;padding:0 14px;border:1px solid #d9dce7;border-radius:9px;background:#fff;color:#303247;font:600 13px system-ui,Arial,sans-serif;cursor:pointer;";
  const frame = document.createElement("iframe");
  frame.title = `Printable ${title}`;
  frame.setAttribute("sandbox", "allow-same-origin allow-modals");
  frame.style.cssText =
    "display:block;flex:1;width:100%;min-height:0;border:0;background:#e9edf5;";
  const previousOverflow = document.body.style.overflow;
  const onKeyDown = (event: KeyboardEvent) => {
    if (event.key === "Escape") closePreview();
  };
  const closePreview = () => {
    document.removeEventListener("keydown", onKeyDown);
    document.body.style.overflow = previousOverflow;
    overlay.remove();
  };
  printButton.addEventListener("click", async () => {
    if (Capacitor.isNativePlatform()) {
      printButton.disabled = true;
      printButton.textContent = "Opening print dialog…";
      try {
        await Printer.printHtml({ name: title, html: previewHtml });
        window.dispatchEvent(
          new CustomEvent("schoolflow:toast", {
            detail: {
              message:
                "Print dialog opened. Choose Save as PDF to create a PDF.",
              kind: "info",
            },
          }),
        );
      } catch (error) {
        console.error("Native print failed", error);
        window.dispatchEvent(
          new CustomEvent("schoolflow:toast", {
            detail: {
              message:
                "Could not open Android printing. Please enable a system print service and try again.",
              kind: "error",
            },
          }),
        );
      } finally {
        printButton.disabled = false;
        printButton.textContent = "Print / Save PDF";
      }
      return;
    }
    try {
      frame.contentWindow?.focus();
      frame.contentWindow?.print();
    } catch (error) {
      console.error("Browser print failed", error);
      window.dispatchEvent(
        new CustomEvent("schoolflow:toast", {
          detail: {
            message: "Browser print is unavailable in this view.",
            kind: "error",
          },
        }),
      );
    }
  });
  closeButton.addEventListener("click", closePreview);
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) closePreview();
  });
  toolbar.append(heading, printButton, closeButton);
  panel.append(toolbar, frame);
  overlay.append(panel);
  document.body.append(overlay);
  document.body.style.overflow = "hidden";
  document.addEventListener("keydown", onKeyDown);
  frame.srcdoc = previewHtml;
  closeButton.focus();
  return true;
}

const schoolHeader = (school: PrintSchool) =>
  `<header class="school-head">${school.logo ? `<img src="${escapeHtml(school.logo)}" alt="School logo">` : ""}<h1>${escapeHtml(school.name || "School")}</h1>${school.address ? `<p>${escapeHtml(school.address)}</p>` : ""}<p>${[school.phone, school.email, school.website].filter(Boolean).map(escapeHtml).join(" · ")}</p></header>`;

export function printFeeReceipt(
  input: {
    due: FeeDue;
    payment: FeePayment;
    student: Student;
    className: string;
  },
  school: PrintSchool,
  paper: "A4" | "thermal" = "A4",
) {
  const { due, payment, student, className } = input;
  const heads = [
    ["Tuition", due.tuition],
    ["Transport", due.transport],
    ["Exam", due.exam],
    ["Admission", due.admission],
    ["Library", due.library],
    ["Other", due.other],
  ].filter(([, value]) => Number(value) > 0) as [string, number][];
  const content = `<main class="sheet fee-receipt-sheet">${schoolHeader(school)}<h2 class="receipt-title">FEE RECEIPT</h2><div class="receipt-meta"><span>Receipt no.</span><b>${escapeHtml(payment.receiptNo)}</b></div><div class="receipt-meta"><span>Payment date</span><b>${escapeHtml(displayDate(payment.paidAt.slice(0, 10)))}</b></div><div class="receipt-meta"><span>Fee month</span><b>${escapeHtml(displayMonth(due.month))}</b></div><div class="receipt-meta"><span>Student</span><b>${escapeHtml(student.name)}</b></div><div class="receipt-meta"><span>Admission no.</span><b>${escapeHtml(student.admissionNo)}</b></div><div class="receipt-meta"><span>Class / section / roll</span><b>${escapeHtml(className)} · ${escapeHtml(student.section)} · ${escapeHtml(student.roll)}</b></div><div class="receipt-meta"><span>Parent / guardian</span><b>${escapeHtml(student.father || "—")}</b></div><table class="fee-head-table"><thead><tr><th align="left">Fee head</th><th align="right">Amount</th></tr></thead><tbody>${heads.map(([label, value]) => `<tr><td>${escapeHtml(label)}</td><td align="right">${money(value)}</td></tr>`).join("")}<tr><td>Discount</td><td align="right">− ${money(due.discount)}</td></tr><tr><td>Fine</td><td align="right">+ ${money(due.fine)}</td></tr><tr class="receipt-total"><th align="left">Total due</th><th align="right">${money(due.total)}</th></tr></tbody></table><div class="receipt-meta"><span>Total paid to date</span><b>${money(due.paid)}</b></div><div class="receipt-paid"><span>Received now · ${escapeHtml(payment.mode)}</span><b>${money(payment.amount)}</b></div><p class="receipt-words">${escapeHtml(amountToWords(payment.amount))}</p><div class="receipt-balance"><span>Remaining balance</span><b>${money(due.balance)}</b></div>${payment.remarks ? `<p class="receipt-remark">Note: ${escapeHtml(payment.remarks)}</p>` : ""}<p class="receipt-footer-note">${escapeHtml(school.receiptFooter || "Thank you for your payment.")}</p><div class="signatures"><span>Parent / guardian</span><span>Authorised signature</span></div></main>`;
  const paperCss =
    paper === "thermal"
      ? `@page{size:80mm auto;margin:3mm}body{padding:0!important;background:#fff!important;font:10px/1.35 Arial,sans-serif}@media print{@page{size:80mm auto;margin:3mm}}.sheet.fee-receipt-sheet{width:74mm;max-width:none;margin:0;padding:0}.school-head{padding-bottom:7px;margin-bottom:8px;border-bottom:1px dashed #222}.school-head img{max-width:32mm;max-height:18mm}.school-head h1{font-size:14px}.school-head p{font-size:9px}.receipt-title{text-align:center;font-size:13px;margin:8px 0}.receipt-meta{display:flex;justify-content:space-between;gap:4px;padding:3px 0;border-bottom:1px dotted #aaa}.receipt-meta span{color:#333}.receipt-meta b{text-align:right}.fee-head-table{width:100%;border-collapse:collapse;margin:8px 0}.fee-head-table td,.fee-head-table th{padding:3px 0;border-bottom:1px dotted #aaa}.receipt-paid,.receipt-balance{display:flex;justify-content:space-between;padding:6px 0;border-top:1px solid #222;font-size:12px;font-weight:bold}.receipt-words,.receipt-remark,.receipt-footer-note{font-size:9px}.signatures{margin-top:24px}.signatures span{min-width:0;width:42%}.toolbar{max-width:none}`
      : `.fee-receipt-sheet{max-width:740px}.receipt-title{text-align:center;letter-spacing:1px}.receipt-meta{display:flex;justify-content:space-between;gap:14px;padding:7px 0;border-bottom:1px solid #e5e5e5}.fee-head-table{width:100%;border-collapse:collapse;margin:12px 0}.fee-head-table td,.fee-head-table th{padding:8px;border-bottom:1px solid #ddd}.receipt-total{border-top:2px solid #222}.receipt-paid,.receipt-balance{display:flex;justify-content:space-between;padding:10px 0;border-top:1px solid #aaa;font-size:16px;font-weight:bold}.receipt-remark,.receipt-footer-note{margin-top:12px}.receipt-footer-note{text-align:center}.receipt-balance{font-size:18px}`;
  return openPrintDocument(
    `Fee receipt ${payment.receiptNo} · ${paper}`,
    content,
    paperCss,
  );
}

export function printDemandBills(
  batch: {
    id: string;
    month: string;
    months?: string[];
    payBy?: string;
    remarks?: string;
    students: {
      studentName: string;
      parent?: string;
      mobile?: string;
      admissionNo: string;
      className: string;
      section: string;
      heads?: Record<string, number>;
      backDues?: number;
      periods?: {
        month: string;
        heads: Record<string, number>;
        backDues: number;
        current: number;
        total: number;
      }[];
      total: number;
    }[];
  },
  school: PrintSchool,
) {
  const labels: Record<string, string> = {
    tuition: "Tuition",
    transport: "Transport",
    exam: "Exam",
    admission: "Admission",
    library: "Library",
    other: "Other",
  };
  const selectedMonths = batch.months?.length ? batch.months : [batch.month];
  const monthLabel = selectedMonths.map(displayMonth).join(" + ");
  const slips = batch.students
    .map((student) => {
      const periods = student.periods?.length
        ? student.periods
        : [
            {
              month: batch.month,
              heads: student.heads || {},
              backDues: student.backDues || 0,
              current: Math.max(0, student.total - (student.backDues || 0)),
              total: student.total,
            },
          ];
      const periodMarkup = periods
        .map((period) => {
          const heads = Object.entries(period.heads || {}).filter(
            ([, amount]) => amount > 0,
          );
          const lines = heads
            .map(
              ([key, amount]) =>
                `<div class="demand-row"><span>${escapeHtml(labels[key] || key)}</span><b>${money(amount)}</b></div>`,
            )
            .join("");
          const back = Number(period.backDues || 0);
          return `<div class="demand-period"><div class="demand-month">${escapeHtml(displayMonth(period.month))}</div>${lines}${back ? `<div class="demand-row"><span>Previous outstanding dues</span><b>${money(back)}</b></div>` : ""}<div class="demand-row demand-period-total"><span>Month amount</span><b>${money(period.total)}</b></div></div>`;
        })
        .join("");
      return `<article class="demand-slip"><div class="demand-head">${school.logo ? `<img src="${escapeHtml(school.logo)}" alt="">` : ""}<div><b>${escapeHtml(school.name || "School")}</b><small>${escapeHtml(school.address || "")}${school.phone ? ` · ${escapeHtml(school.phone)}` : ""}</small></div></div><div class="demand-caption">FEE DEMAND · ${escapeHtml(monthLabel)}</div><div class="demand-row"><span>Student</span><b>${escapeHtml(student.studentName)}</b></div><div class="demand-row"><span>Admission / class</span><b>${escapeHtml(student.admissionNo)} · ${escapeHtml(student.className)}-${escapeHtml(student.section)}</b></div>${periodMarkup}<div class="demand-row demand-total"><span>Grand amount requested</span><b>${money(student.total)}</b></div><div class="demand-pay"><b>Payment details</b><span>${escapeHtml(school.paymentDetails || "Pay at the school office. Please mention the student admission number.")}</span></div><div class="demand-row"><span>Pay by</span><b>${escapeHtml(batch.payBy ? displayDate(batch.payBy) : "Please pay at the earliest")}</b></div>${batch.remarks ? `<p class="demand-remark">${escapeHtml(batch.remarks)}</p>` : ""}<div class="demand-cut">✂ · · · · · · · · · · · · · · · · · · · ·</div></article>`;
    })
    .join("");
  const content = `<main class="sheet demand-sheet"><div class="demand-batch-title">${escapeHtml(batch.id)} · ${escapeHtml(monthLabel)}</div><div class="demand-grid">${slips}</div></main>`;
  const css = `.demand-sheet{max-width:none;padding:0}.demand-batch-title{text-align:right;color:#606574;font-size:9px;margin-bottom:5mm}.demand-grid{display:grid;grid-template-columns:1fr 1fr;gap:5mm}.demand-slip{position:relative;min-height:112mm;padding:6mm;border:1px dashed #8d8d8d;border-radius:2mm;break-inside:avoid;page-break-inside:avoid}.demand-head{display:flex;align-items:center;gap:3mm;padding-bottom:3mm;border-bottom:1px solid #333}.demand-head img{max-width:14mm;max-height:12mm;object-fit:contain}.demand-head b,.demand-head small{display:block}.demand-head b{font-size:11pt}.demand-head small{font-size:7pt;color:#555}.demand-caption{text-align:center;font-size:8pt;font-weight:bold;letter-spacing:.6px;margin:3mm 0}.demand-row{display:flex;justify-content:space-between;gap:5mm;padding:2mm 0;border-bottom:1px solid #e2e2e2;font-size:8pt}.demand-row span{color:#444}.demand-row b{text-align:right}.demand-month{margin-top:2mm;padding:2mm 0;border-bottom:1px solid #777;font-size:8pt;font-weight:bold}.demand-period-total{font-weight:bold}.demand-total{margin-top:2mm;border-top:2px solid #333;border-bottom:0;font-size:11pt;font-weight:bold}.demand-pay{display:grid;gap:1mm;margin-top:3mm;padding:3mm;background:#f4f4f4;font-size:7pt}.demand-remark{font-size:7pt}.demand-cut{position:absolute;right:0;bottom:2mm;left:0;text-align:center;color:#888;font-size:7pt}@media print{.demand-grid{gap:4mm}.demand-slip{min-height:127mm}.demand-batch-title{display:none}}`;
  return openPrintDocument("Demand bill slips", content, css);
}

export function printAdmissionReceipt(
  student: Student,
  school: PrintSchool,
  className: string,
) {
  const content = `<main class="sheet">${schoolHeader(school)}<h2>Admission acknowledgement</h2><p>Student record successfully created and entered in the school register.</p><div class="row"><span>Student name</span><b>${escapeHtml(student.name)}</b></div><div class="row"><span>Admission number</span><b>${escapeHtml(student.admissionNo)}</b></div><div class="row"><span>Class / section / roll</span><b>${escapeHtml(className)} · ${escapeHtml(student.section)} · ${escapeHtml(student.roll)}</b></div><div class="row"><span>Admission date</span><b>${escapeHtml(displayDate(student.admissionDate))}</b></div><div class="row"><span>Parent / guardian</span><b>${escapeHtml(student.father || "—")}</b></div><div class="row"><span>Academic session</span><b>${escapeHtml(student.session)}</b></div><p>${escapeHtml(school.receiptFooter || "Please retain this acknowledgement for your records.")}</p><div class="signatures"><span>Parent / guardian</span><span>School authority</span></div></main>`;
  return openPrintDocument("Admission receipt", content);
}

export function printStudentIdCards(
  students: Student[],
  school: PrintSchool,
  classNames: Record<number, string>,
) {
  const watermark = school.logo
    ? `<img class="school-watermark" src="${escapeHtml(school.logo)}" alt="" aria-hidden="true">`
    : `<div class="school-watermark watermark-letter" aria-hidden="true">${escapeHtml((school.name || "S").slice(0, 1).toUpperCase())}</div>`;
  const card = (student: Student) =>
    `<article class="card-pair"><section class="id-card front">${watermark}<div class="id-head">${school.logo ? `<img src="${escapeHtml(school.logo)}" alt="">` : `<b class="monogram">${escapeHtml((school.name || "S").slice(0, 1).toUpperCase())}</b>`}<div><strong>${escapeHtml(school.name || "School")}</strong><small>STUDENT IDENTITY CARD · ${escapeHtml(student.session)}</small></div></div><div class="front-body">${student.photo ? `<img class="photo" src="${escapeHtml(student.photo)}" alt="Student">` : `<div class="photo blank">${escapeHtml(student.name.slice(0, 1).toUpperCase())}</div>`}<div class="fields"><h2>${escapeHtml(student.name)}</h2><div><small>ADMISSION NO.</small><b>${escapeHtml(student.admissionNo)}</b></div><div><small>CLASS · SECTION · ROLL</small><b>${escapeHtml(classNames[student.classId] || "Class")} · ${escapeHtml(student.section)} · ${escapeHtml(student.roll)}</b></div><div><small>FATHER / GUARDIAN</small><b>${escapeHtml(student.father || "—")}</b></div><div><small>MOBILE</small><b>+91 ${escapeHtml(student.mobile)}</b></div><div><small>DOB</small><b>${escapeHtml(displayDate(student.dob))}</b></div>${student.bloodGroup ? `<div><small>BLOOD GROUP</small><b>${escapeHtml(student.bloodGroup)}</b></div>` : ""}</div></div><div class="valid">Valid for academic session ${escapeHtml(student.session)}</div></section><section class="id-card back">${watermark}<div class="back-brand">${school.logo ? `<img src="${escapeHtml(school.logo)}" alt="">` : ""}<b>${escapeHtml(school.name || "School")}</b></div><div class="address"><small>PERMANENT ADDRESS</small><p>${escapeHtml(student.address || "Not provided")}</p></div><p class="return-note">This ID card is the property of the school. If found, please return it to the school office.</p><div class="school-contact">${[school.address, school.phone, school.email, school.website].filter(Boolean).map(escapeHtml).join(" · ")}</div><div class="signatures"><span>Principal / authorised signature</span></div></section></article>`;
  const content = `<main class="sheet id-sheet">${students.map(card).join("")}</main>`;
  const css = `.id-sheet{display:grid;grid-template-columns:1fr 1fr;gap:9mm}.card-pair{display:contents}.id-card{position:relative;width:86mm;height:54mm;border:1px solid #aeb4cc;border-radius:4mm;overflow:hidden;padding:4mm;break-inside:avoid;background:linear-gradient(145deg,#fff,#f3f4ff)}.school-watermark{position:absolute;z-index:0;top:50%;left:50%;width:45mm;height:45mm;max-width:80%;object-fit:contain;transform:translate(-50%,-50%);opacity:.09;pointer-events:none}.watermark-letter{display:grid;place-items:center;color:rgba(82,85,190,.09);font-size:55pt;font-weight:900}.id-head,.front-body,.valid{position:relative;z-index:1}.id-head{display:flex;align-items:center;gap:3mm;border-bottom:1px solid #dfe1ee;padding-bottom:2mm}.id-head img,.back-brand img{max-width:12mm;max-height:9mm;object-fit:contain}.id-head strong{display:block;font-size:9pt}.id-head small{display:block;font-size:5.5pt;letter-spacing:.5px}.monogram{width:10mm;height:10mm;display:grid;place-items:center;background:#595ce0;color:white;border-radius:50%;font-size:14pt}.front-body{display:flex;gap:3mm;padding-top:3mm}.photo{width:20mm;height:25mm;object-fit:cover;border-radius:2mm;border:1px solid #ddd}.photo.blank{display:grid;place-items:center;background:#e8e9fb;font-size:18pt}.fields{display:grid;grid-template-columns:1fr 1fr;gap:1mm 2mm;flex:1}.fields h2{grid-column:1/-1;font-size:10pt;margin:0 0 1mm}.fields small,.address small{display:block;font-size:5pt;color:#626779}.fields b{display:block;font-size:6.5pt}.valid{position:absolute;bottom:2mm;left:4mm;font-size:5.5pt;color:#606574}.back{background:linear-gradient(145deg,#fcfcff,#e9eaff)}.back-brand,.address,.return-note,.school-contact,.back .signatures{position:relative;z-index:1}.back-brand{display:flex;align-items:center;gap:2mm;font-size:9pt}.address{margin-top:4mm}.address p{font-size:7pt;margin:1mm 0}.return-note{font-size:7pt;font-weight:bold;margin-top:4mm}.school-contact{position:absolute;bottom:4mm;left:4mm;right:4mm;font-size:5.5pt}.back .signatures{margin-top:4mm;justify-content:flex-end}.back .signatures span{min-width:35mm;font-size:5.5pt}.toolbar{max-width:none}@media print{.id-sheet{gap:7mm}.id-card{box-shadow:none}}`;
  return openPrintDocument("Student ID cards", content, css);
}

export function printTransferCertificate(
  student: Student,
  school: PrintSchool,
  className: string,
) {
  const content = `<main class="sheet">${schoolHeader(school)}<h2 style="text-align:center;text-decoration:underline">TRANSFER CERTIFICATE</h2><div class="row"><span>TC number</span><b>${escapeHtml(student.tcNumber || "—")}</b></div><div class="row"><span>Issue date</span><b>${escapeHtml(displayDate(student.tcIssueDate))}</b></div><div class="row"><span>Student name</span><b>${escapeHtml(student.name)}</b></div><div class="row"><span>Father / guardian</span><b>${escapeHtml(student.father || "—")}</b></div><div class="row"><span>Date of birth</span><b>${escapeHtml(displayDate(student.dob))}</b></div><div class="row"><span>Last class studied</span><b>${escapeHtml(student.lastClass || className)}</b></div><div class="row"><span>Admission number</span><b>${escapeHtml(student.admissionNo)}</b></div><div class="row"><span>Admission date</span><b>${escapeHtml(displayDate(student.admissionDate))}</b></div><div class="row"><span>Leaving reason</span><b>${escapeHtml(student.leavingReason || "—")}</b></div><div class="row"><span>Conduct</span><b>${escapeHtml(student.conduct || "Good")}</b></div><div class="row"><span>School dues</span><b>${escapeHtml(student.duesCleared === false ? "Pending" : "Cleared")}</b></div><p style="margin-top:24px">Certified that the above particulars are true according to the school register.</p><div class="signatures"><span>Class teacher</span><span>Principal / authorised signatory</span></div><p class="muted">${escapeHtml(school.printFooter || "")}</p></main>`;
  return openPrintDocument("Transfer certificate", content);
}

export function printFamilyBill(bill: FamilyBill, school: PrintSchool) {
  const items = bill.items || [];
  const content = `<main class="sheet">${schoolHeader(school)}<h2>Family fee statement</h2><div class="row"><span>Bill number</span><b>${escapeHtml(bill.billNo)}</b></div><div class="row"><span>Parent / guardian</span><b>${escapeHtml(bill.parent)} · +91 ${escapeHtml(bill.mobile)}</b></div><div class="row"><span>Bill date</span><b>${escapeHtml(displayDate(bill.createdAt.slice(0, 10)))}</b></div><table style="width:100%;border-collapse:collapse;margin-top:16px"><thead><tr><th align="left">Student</th><th align="left">Fee month / head</th><th align="right">Amount</th></tr></thead><tbody>${items.map((i) => `<tr><td style="padding:7px 0;border-bottom:1px solid #ddd">${escapeHtml(i.studentName)} · ${escapeHtml(i.className)}-${escapeHtml(i.section)}</td><td style="padding:7px 0;border-bottom:1px solid #ddd">${escapeHtml(displayMonth(i.feeMonth))} · ${escapeHtml(i.feeHead)}</td><td align="right" style="padding:7px 0;border-bottom:1px solid #ddd">${money(i.amount)}</td></tr>`).join("")}</tbody></table><div class="row"><span>Subtotal</span><b>${money(bill.total + bill.discount - bill.fine)}</b></div><div class="row"><span>Sibling discount</span><b>− ${money(bill.discount)}</b></div><div class="row"><span>Fine</span><b>+ ${money(bill.fine)}</b></div><div class="row amount"><span>Grand total</span><b>${money(bill.total)}</b></div><div class="row"><span>Paid</span><b>${money(bill.paid)}</b></div><div class="row"><span>Balance</span><b>${money(bill.balance ?? Math.max(0, bill.total - bill.paid))}</b></div><p>${escapeHtml(school.receiptFooter || "Thank you for your payment.")}</p><div class="signatures"><span>Parent / guardian</span><span>Authorised signature</span></div></main>`;
  return openPrintDocument("Family bill", content);
}

export function printSalarySlip(
  record: {
    name: string;
    role: string;
    month: string;
    basic: number;
    allowance: number;
    deduction: number;
    net: number;
    paymentDate?: string;
  },
  school: PrintSchool,
) {
  const content = `<main class="sheet">${schoolHeader(school)}<h2>Salary slip · ${escapeHtml(displayMonth(record.month))}</h2><div class="row"><span>Employee</span><b>${escapeHtml(record.name)}</b></div><div class="row"><span>Role</span><b>${escapeHtml(record.role)}</b></div><div class="row"><span>Paid on</span><b>${escapeHtml(record.paymentDate ? displayDate(record.paymentDate) : "Unpaid")}</b></div><div class="row"><span>Basic salary</span><b>${money(record.basic)}</b></div><div class="row"><span>Allowance</span><b>${money(record.allowance)}</b></div><div class="row"><span>Deductions</span><b>− ${money(record.deduction)}</b></div><div class="row amount"><span>Net salary</span><b>${money(record.net)}</b></div><p>${escapeHtml(amountToWords(record.net))}</p><div class="signatures"><span>Employee</span><span>Accountant</span><span>Principal</span></div></main>`;
  return openPrintDocument("Salary slip", content);
}

export function printDataReport(
  input: {
    title: string;
    columns: string[];
    rows: Record<string, unknown>[];
    subtitle?: string;
  },
  school: PrintSchool,
) {
  const moneyColumn = (key: string) =>
    /amount|balance|total|paid|subtotal|fine|discount|payable|collection/i.test(
      key,
    );
  const content = `<main class="sheet report-print-sheet">${schoolHeader(school)}<div class="report-title"><div><p class="report-kicker">OFFICIAL SCHOOL REPORT</p><h2>${escapeHtml(input.title)}</h2><p class="report-subtitle">${escapeHtml(input.subtitle || "All matching records")}</p></div><div class="report-date"><span>Prepared on</span><b>${escapeHtml(displayDate(todayISO()))}</b><span>${input.rows.length} records</span></div></div><table class="report-print-table"><thead><tr>${input.columns.map((column) => `<th>${escapeHtml(column.replace(/_/g, " "))}</th>`).join("")}</tr></thead><tbody>${input.rows
    .map(
      (row) =>
        `<tr>${input.columns
          .map((column) => {
            const value = row[column];
            const cell =
              typeof value === "number" && moneyColumn(column)
                ? money(value)
                : String(value ?? "—");
            return `<td>${escapeHtml(cell)}</td>`;
          })
          .join("")}</tr>`,
    )
    .join(
      "",
    )}</tbody></table><footer class="report-print-footer"><span>${escapeHtml(school.printFooter || "School record · Keep confidential")}</span><span>School copy · Generated locally</span></footer></main>`;
  const css = `@page{size:A4 landscape;margin:10mm}.report-print-sheet{max-width:none;padding:0}.report-title{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;margin:12px 0 16px;padding:0 0 12px;border-bottom:2px solid #333}.report-title h2{margin:3px 0 4px;font-size:20px;text-transform:uppercase;letter-spacing:.4px}.report-kicker{margin:0;color:#555;font-size:9px;font-weight:700;letter-spacing:1px}.report-subtitle{margin:4px 0 0;color:#505463;font-size:11px}.report-date{display:grid;gap:3px;min-width:105px;text-align:right;color:#555;font-size:9px}.report-date b{color:#171923;font-size:11px}.report-print-table{width:100%;border-collapse:collapse;font-size:9px}.report-print-table thead{display:table-header-group}.report-print-table th{padding:8px 7px;border:1px solid #aeb3c1;background:#eef0f6;text-align:left;font-size:8px;text-transform:uppercase;letter-spacing:.25px}.report-print-table td{padding:7px;border:1px solid #c8cbd4;vertical-align:top}.report-print-table tbody tr:nth-child(even){background:#f7f8fb}.report-print-table tr{break-inside:avoid;page-break-inside:avoid}.report-print-footer{display:flex;justify-content:space-between;gap:12px;margin-top:13px;padding-top:7px;border-top:1px solid #9da1aa;color:#555;font-size:8px}@media print{.report-print-table th{-webkit-print-color-adjust:exact;print-color-adjust:exact;background:#eef0f6!important}.report-print-table tbody tr:nth-child(even){-webkit-print-color-adjust:exact;print-color-adjust:exact;background:#f7f8fb!important}}`;
  return openPrintDocument(input.title, content, css);
}

export function printMarksheet(
  input: {
    examName: string;
    student: Student;
    className: string;
    section: string;
    rows: { subject: string; marks: number; maxMarks: number }[];
    rank: number;
    percentage: number;
    grade: string;
    pass: boolean;
  },
  school: PrintSchool,
) {
  const total = input.rows.reduce((sum, row) => sum + row.marks, 0);
  const max = input.rows.reduce((sum, row) => sum + row.maxMarks, 0);
  const content = `<main class="sheet">${schoolHeader(school)}<h2 style="text-align:center">${escapeHtml(input.examName)} · MARKSHEET</h2><div class="row"><span>Student</span><b>${escapeHtml(input.student.name)}</b></div><div class="row"><span>Admission number</span><b>${escapeHtml(input.student.admissionNo)}</b></div><div class="row"><span>Class / roll</span><b>${escapeHtml(input.className)}-${escapeHtml(input.section)} / ${escapeHtml(input.student.roll)}</b></div><table style="width:100%;border-collapse:collapse;margin-top:14px"><thead><tr><th align="left">Subject</th><th>Maximum</th><th>Obtained</th><th>Grade</th><th>Status</th></tr></thead><tbody>${input.rows.map((row) => `<tr><td style="padding:8px;border-bottom:1px solid #ddd">${escapeHtml(row.subject)}</td><td align="center">${row.maxMarks}</td><td align="center">${row.marks}</td><td align="center">${gradeFor(row.maxMarks ? (row.marks / row.maxMarks) * 100 : 0)}</td><td align="center">${row.marks / row.maxMarks >= 0.33 ? "Pass" : "Fail"}</td></tr>`).join("")}</tbody></table><div class="row"><span>Total</span><b>${total} / ${max}</b></div><div class="row"><span>Percentage / grade</span><b>${input.percentage.toFixed(2)}% · ${escapeHtml(input.grade)}</b></div><div class="row"><span>Rank / result</span><b>${input.rank} · ${input.pass ? "Pass" : "Fail / Incomplete"}</b></div><div class="signatures"><span>Class teacher</span><span>Principal</span><span>Parent</span></div></main>`;
  return openPrintDocument("Student marksheet", content);
}

export function printWallResult(
  rows: {
    rank: number;
    name: string;
    admissionNo: string;
    percentage: number;
    grade: string;
  }[],
  examName: string,
  school: PrintSchool,
) {
  const bodyRows = rows
    .slice(0, 10)
    .map(
      (row) =>
        `<tr><td>${row.rank}</td><td>${escapeHtml(row.name)}</td><td>${escapeHtml(row.admissionNo)}</td><td>${row.percentage.toFixed(2)}%</td><td>${escapeHtml(row.grade)}</td></tr>`,
    )
    .join("");
  const logo = school.logo
    ? `<img src="${escapeHtml(school.logo)}" alt="School logo">`
    : `<span class="wall-logo-fallback">${escapeHtml((school.name || "S").slice(0, 1).toUpperCase())}</span>`;
  const contact = [school.address, school.phone, school.email]
    .filter(Boolean)
    .map(escapeHtml)
    .join(" · ");
  const content = `<main class="sheet wall"><header class="wall-header"><div class="wall-brand">${logo}<div><h2>${escapeHtml(school.name || "School")}</h2>${contact ? `<p>${contact}</p>` : ""}</div></div><div class="wall-title"><small>EXAM RESULT</small><h1>${escapeHtml(examName)}</h1></div></header><table><thead><tr><th>Rank</th><th>Student name</th><th>Admission no.</th><th>Percentage</th><th>Grade</th></tr></thead><tbody>${bodyRows || `<tr><td colspan="5">No results available.</td></tr>`}</tbody></table><footer>${escapeHtml(school.printFooter || "School academic record")}</footer></main>`;
  return openPrintDocument(
    "Class wall result",
    content,
    `.wall{padding:18px;background:#fff;color:#161616}.wall-header{display:flex;align-items:center;justify-content:space-between;gap:14px;margin:0 0 10px;padding:0 0 9px;border-bottom:1.5px solid #333}.wall-brand{display:flex;align-items:center;gap:9px;min-width:0}.wall-brand img{display:block;width:38px;height:38px;flex:0 0 38px;object-fit:contain}.wall-logo-fallback{display:grid;width:38px;height:38px;flex:0 0 38px;place-items:center;border:1px solid #bbb;border-radius:50%;font:700 20px Georgia,serif}.wall-brand h2{margin:0;font-size:16px;line-height:1.2}.wall-brand p{margin:2px 0 0;color:#555;font-size:9px}.wall-title{text-align:right}.wall-title small{color:#555;font-size:8px;letter-spacing:.8px}.wall-title h1{margin:2px 0 0;font-size:17px}.wall table{width:100%;border-collapse:collapse;font-size:10px}.wall th,.wall td{padding:7px 8px;border:1px solid #9b9b9b}.wall th{background:#f0f0f0;text-align:left}.wall td:first-child,.wall td:nth-last-child(-n+2){text-align:center}.wall footer{margin-top:8px;color:#555;font-size:8px;text-align:right}@media print{.wall{padding:0!important}}`,
  );
}

export function downloadWallResultSvg(
  rows: {
    rank: number;
    name: string;
    admissionNo: string;
    percentage: number;
    grade: string;
  }[],
  examName: string,
  school: PrintSchool,
) {
  const entries = rows
    .slice(0, 10)
    .map((row, index) => {
      const y = 352 + index * 88;
      const name =
        row.name.length > 30 ? `${row.name.slice(0, 29)}…` : row.name;
      return `<g><rect x="72" y="${y}" width="936" height="70" rx="18" fill="#ffffff"/><text x="104" y="${y + 46}" font-size="28" font-weight="800" fill="#5b5bd6">#${row.rank}</text><text x="190" y="${y + 31}" font-size="23" font-weight="700" fill="#24243b">${escapeHtml(name)}</text><text x="190" y="${y + 53}" font-size="14" fill="#73748b">${escapeHtml(row.admissionNo)} · ${escapeHtml(row.grade)}</text><text x="956" y="${y + 43}" text-anchor="end" font-size="23" font-weight="800" fill="#17805d">${row.percentage.toFixed(2)}%</text></g>`;
    })
    .join("");
  const logo = school.logo
    ? `<image href="${escapeHtml(school.logo)}" x="78" y="68" width="60" height="60" preserveAspectRatio="xMidYMid meet"/>`
    : `<circle cx="108" cy="98" r="28" fill="#ffffff" fill-opacity=".18"/><text x="108" y="109" text-anchor="middle" font-size="33" font-family="Georgia,serif" font-style="italic" font-weight="700" fill="#ffffff">${escapeHtml((school.name || "S").slice(0, 1).toUpperCase())}</text>`;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350"><defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f1f0ff"/><stop offset="1" stop-color="#fff4e8"/></linearGradient><linearGradient id="hero" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#4d50c9"/><stop offset="1" stop-color="#9369e6"/></linearGradient></defs><rect width="1080" height="1350" fill="url(#bg)"/><rect x="48" y="40" width="984" height="220" rx="28" fill="url(#hero)"/>${logo}<text x="158" y="104" font-family="Arial,sans-serif" font-size="25" font-weight="700" fill="#ffffff">${escapeHtml(school.name || "School")}</text><text x="158" y="132" font-family="Arial,sans-serif" font-size="13" letter-spacing="2" fill="#e4e4ff">EXAM RESULTS</text><text x="78" y="195" font-family="Arial,sans-serif" font-size="29" font-weight="800" fill="#ffffff">${escapeHtml(examName)}</text><text x="78" y="229" font-family="Arial,sans-serif" font-size="14" fill="#f0eeff">Celebrating effort, growth and achievement</text><text x="76" y="292" font-family="Arial,sans-serif" font-size="13" font-weight="700" letter-spacing="2" fill="#77788d">TOP STUDENTS</text>${entries}<text x="540" y="1265" text-anchor="middle" font-family="Arial,sans-serif" font-size="13" fill="#818198">${escapeHtml(school.printFooter || "School academic record")}</text></svg>`;
  const filename = `class-result-${
    examName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "exam"
  }.svg`;
  saveFile(new Blob([svg], { type: "image/svg+xml;charset=utf-8" }), filename);
  return filename;
}

export interface MarksheetData {
  examName: string;
  student: Student;
  className: string;
  section: string;
  rows: { subject: string; marks: number; maxMarks: number }[];
  rank: number;
  percentage: number;
  grade: string;
  pass: boolean;
}

export function printClassMarksheets(
  inputs: MarksheetData[],
  school: PrintSchool,
) {
  const sections = inputs.map((input) => {
    const total = input.rows.reduce((sum, row) => sum + row.marks, 0);
    const max = input.rows.reduce((sum, row) => sum + row.maxMarks, 0);
    return `<section class="sheet marksheet"><div class="sheet-top">${schoolHeader(school)}<h2 style="text-align:center">${escapeHtml(input.examName)} · MARKSHEET</h2></div><div class="row"><span>Student</span><b>${escapeHtml(input.student.name)}</b></div><div class="row"><span>Admission number</span><b>${escapeHtml(input.student.admissionNo)}</b></div><div class="row"><span>Class / roll / session</span><b>${escapeHtml(input.className)}-${escapeHtml(input.section)} / ${escapeHtml(input.student.roll)} / ${escapeHtml(input.student.session)}</b></div><table style="width:100%;border-collapse:collapse;margin-top:14px"><thead><tr><th align="left">Subject</th><th>Maximum</th><th>Obtained</th><th>Grade</th><th>Status</th></tr></thead><tbody>${input.rows.map((row) => `<tr><td style="padding:8px;border-bottom:1px solid #ddd">${escapeHtml(row.subject)}</td><td align="center">${row.maxMarks}</td><td align="center">${row.marks}</td><td align="center">${gradeFor(row.maxMarks ? (row.marks / row.maxMarks) * 100 : 0)}</td><td align="center">${row.marks / row.maxMarks >= 0.33 ? "Pass" : "Fail"}</td></tr>`).join("")}</tbody></table><div class="row"><span>Total</span><b>${total} / ${max}</b></div><div class="row"><span>Percentage / grade</span><b>${input.percentage.toFixed(2)}% · ${escapeHtml(input.grade)}</b></div><div class="row"><span>Rank / result</span><b>${input.rank} · ${input.pass ? "Pass" : "Fail / Incomplete"}</b></div><div class="signatures"><span>Class teacher</span><span>Principal</span><span>Parent</span></div></section>`;
  });
  return openPrintDocument(
    "Bulk marksheets",
    sections.join(""),
    ".marksheet{break-after:page;page-break-after:always}.marksheet:last-child{break-after:auto;page-break-after:auto}",
  );
}

export interface ProgressStudentReport {
  student: Student;
  className: string;
  section: string;
  session: string;
  terms: {
    label: string;
    examName: string;
    subjects: Record<string, { marks: number; maxMarks: number } | undefined>;
  }[];
}

export function printProgressReports(
  reports: ProgressStudentReport[],
  subjectNames: string[],
  school: PrintSchool,
) {
  const pages = reports.map((report) => {
    const rows = subjectNames
      .map((subject) => {
        const first = report.terms[0]?.subjects[subject];
        const second = report.terms[1]?.subjects[subject];
        const final = report.terms[2]?.subjects[subject];
        const earned = [first, second, final].reduce(
          (sum, x) => sum + (x?.marks || 0),
          0,
        );
        const maximum = [first, second, final].reduce(
          (sum, x) => sum + (x?.maxMarks || 0),
          0,
        );
        return `<tr><td>${escapeHtml(subject)}</td><td>${first ? `${first.marks}/${first.maxMarks}` : "—"}</td><td>${second ? `${second.marks}/${second.maxMarks}` : "—"}</td><td>${final ? `${final.marks}/${final.maxMarks}` : "—"}</td><td>${maximum ? `${((earned / maximum) * 100).toFixed(1)}%` : "—"}</td></tr>`;
      })
      .join("");
    const totals = [0, 1, 2].map((index) => {
      const term = report.terms[index];
      if (!term) return "—";
      const vals = Object.values(term.subjects).filter(
        (x): x is { marks: number; maxMarks: number } => Boolean(x),
      );
      const marks = vals.reduce((sum, x) => sum + x.marks, 0);
      const max = vals.reduce((sum, x) => sum + x.maxMarks, 0);
      return max
        ? `${marks}/${max} (${((marks / max) * 100).toFixed(1)}%)`
        : "—";
    });
    const overallValues = report.terms.flatMap((term) =>
      Object.values(term.subjects).filter(
        (x): x is { marks: number; maxMarks: number } => Boolean(x),
      ),
    );
    const overallMarks = overallValues.reduce(
      (sum, value) => sum + value.marks,
      0,
    );
    const overallMax = overallValues.reduce(
      (sum, value) => sum + value.maxMarks,
      0,
    );
    const overall = overallMax
      ? `${overallMarks}/${overallMax} (${((overallMarks / overallMax) * 100).toFixed(1)}%)`
      : "—";
    return `<section class="sheet progress-sheet"><div class="sheet-top">${schoolHeader(school)}<h2 style="text-align:center">FINAL PROGRESS REPORT</h2></div><div class="row"><span>Student</span><b>${escapeHtml(report.student.name)}</b></div><div class="row"><span>Admission / class / session</span><b>${escapeHtml(report.student.admissionNo)} · ${escapeHtml(report.className)}-${escapeHtml(report.section)} · ${escapeHtml(report.session)}</b></div><table style="width:100%;border-collapse:collapse;margin-top:14px"><thead><tr><th align="left">Subject</th><th>${escapeHtml(report.terms[0]?.label || "Term 1")}</th><th>${escapeHtml(report.terms[1]?.label || "Term 2")}</th><th>${escapeHtml(report.terms[2]?.label || "Final")}</th><th>Overall</th></tr></thead><tbody>${rows}</tbody><tfoot><tr><th align="left">Total / percentage</th>${totals.map((value) => `<th>${escapeHtml(value)}</th>`).join("")}<th>${escapeHtml(overall)}</th></tr></tfoot></table><div class="signatures"><span>Class teacher</span><span>Principal</span><span>Parent</span></div><p class="muted">${escapeHtml(school.printFooter || "Keep growing, keep learning.")}</p></section>`;
  });
  return openPrintDocument(
    "Final progress reports",
    pages.join(""),
    ".progress-sheet{break-after:page;page-break-after:always}.progress-sheet:last-child{break-after:auto;page-break-after:auto}table th,table td{border:1px solid #bfc2cf;padding:7px;text-align:center}table td:first-child{text-align:left}",
  );
}
