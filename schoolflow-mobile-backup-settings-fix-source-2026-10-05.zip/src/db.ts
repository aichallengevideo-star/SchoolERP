import Dexie, { type Table } from "dexie";
import type {
  AppUser,
  AuditLog,
  BackupLog,
  DemandBatchRecord,
  Attendance,
  Exam,
  ExamResult,
  FamilyBill,
  FeeDue,
  FeePayment,
  FeeStructure,
  Notification,
  Payroll,
  PromotionLog,
  SchoolClass,
  Setting,
  Student,
  StudentDocument,
  StudentTimeline,
  Teacher,
  TransportRoute,
} from "./types";
import { hashDesktopPassword, hashPassword } from "./lib";

export class SchoolDB extends Dexie {
  students!: Table<Student, number>;
  classes!: Table<SchoolClass, number>;
  teachers!: Table<Teacher, number>;
  attendance!: Table<Attendance, number>;
  feeStructures!: Table<FeeStructure, number>;
  feeDues!: Table<FeeDue, number>;
  feePayments!: Table<FeePayment, number>;
  exams!: Table<Exam, number>;
  examResults!: Table<ExamResult, number>;
  transportRoutes!: Table<TransportRoute, number>;
  payroll!: Table<Payroll, number>;
  users!: Table<AppUser, number>;
  settings!: Table<Setting, string>;
  auditLogs!: Table<AuditLog, number>;
  notifications!: Table<Notification, number>;
  promotions!: Table<PromotionLog, number>;
  familyBills!: Table<FamilyBill, number>;
  studentTimeline!: Table<StudentTimeline, number>;
  documents!: Table<StudentDocument, number>;
  demandBatches!: Table<DemandBatchRecord, number>;
  backupLogs!: Table<BackupLog, number>;

  constructor() {
    super("schoolflow-erp");
    this.version(1).stores({
      students:
        "++id, &normalizedAdmissionNo, name, father, classId, [classId+section+session], status, admissionDate, deletedAt",
      classes: "++id, &[name+section+session], status, session, deletedAt",
      teachers: "++id, &teacherId, name, status",
      attendance:
        "++id, &[studentId+date], date, classId, [classId+section+date], session",
      feeStructures: "++id, &[classId+section+session], classId, session",
      feeDues:
        "++id, &[studentId+session+month], studentId, session, month, status",
      feePayments: "++id, &receiptNo, studentId, dueId, paidAt",
      exams: "++id, &[name+classId+section+session], classId, session, date",
      examResults:
        "++id, &[examId+studentId+subject], examId, studentId, subject",
      transportRoutes: "++id, &name, status",
      payroll: "++id, &[name+month], name, month, status",
      users: "++id, &username, role, status",
      settings: "&key",
      auditLogs: "++id, username, entity, createdAt",
      notifications: "++id, isRead, severity, createdAt",
      promotions: "++id, studentId, createdAt",
      familyBills: "++id, &billNo, familyKey, createdAt",
    });
    this.version(2).stores({
      students:
        "++id, &normalizedAdmissionNo, name, father, classId, [classId+section+session], status, admissionDate, deletedAt",
      classes: "++id, &[name+section+session], status, session, deletedAt",
      teachers: "++id, &teacherId, name, status",
      attendance:
        "++id, &[studentId+date], date, classId, [classId+section+date], session",
      feeStructures: "++id, &[classId+section+session], classId, session",
      feeDues:
        "++id, &[studentId+session+month], studentId, session, month, status",
      feePayments: "++id, &receiptNo, studentId, dueId, paidAt",
      exams: "++id, &[name+classId+section+session], classId, session, date",
      examResults:
        "++id, &[examId+studentId+subject], examId, studentId, subject",
      transportRoutes: "++id, &name, status",
      payroll: "++id, &[name+month], name, month, status",
      users: "++id, &username, role, status",
      settings: "&key",
      auditLogs: "++id, username, entity, createdAt",
      notifications: "++id, isRead, severity, createdAt",
      promotions: "++id, studentId, createdAt",
      familyBills: "++id, &billNo, familyKey, createdAt",
      studentTimeline: "++id, studentId, eventType, createdAt",
      documents: "++id, studentId, docType, createdAt, deletedAt",
      demandBatches: "++id, &batchNo, session, month, createdAt",
      backupLogs: "++id, filename, type, createdAt",
    });
  }
}

export const db = new SchoolDB();

export const DEFAULT_SETTINGS: Record<string, unknown> = {
  schoolName: "",
  address: "",
  phone: "",
  email: "",
  website: "",
  principalName: "",
  academicSession: "2026-27",
  defaultFeeMonth: new Date().toISOString().slice(0, 7),
  resultTemplate: "premium",
  printFooter: "",
  receiptFooter: "",
  paymentDetails: "",
  theme: "light",
  textSize: 100,
  autoBackup: "weekly",
  autoBackupFrequency: "weekly",
  keepBackupsCount: 12,
  autoLockMinutes: 15,
  lastBackup: "",
  setupComplete: false,
  developerName: "Sanjaydat Kumar",
  defaultFeeDay: 10,
  bigText: false,
};

export async function ensureSeed() {
  if (!(await db.users.count())) {
    const salt = crypto.randomUUID();
    const defaultPassword = "admin123";
    await db.users.add({
      username: "admin",
      passwordHash: await hashPassword(defaultPassword, salt),
      salt,
      passwordAlgorithm: "sha256",
      desktopPasswordHash: await hashDesktopPassword(defaultPassword),
      fullName: "School Administrator",
      role: "Admin",
      status: "Active",
      mustChange: true,
    });
  }
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    if ((await db.settings.get(key)) === undefined)
      await db.settings.put({ key, value });
  }
}

export async function setting<T = unknown>(
  key: string,
  fallback?: T,
): Promise<T> {
  const item = await db.settings.get(key);
  return (item?.value as T) ?? (fallback as T);
}
export async function saveSetting(key: string, value: unknown) {
  await db.settings.put({ key, value });
}
export async function logStudentEvent(
  studentId: number,
  eventType: string,
  title: string,
  details?: string,
  username = "admin",
) {
  await db.studentTimeline.add({
    studentId,
    eventType,
    title,
    details,
    username,
    createdAt: new Date().toISOString(),
  });
}
export async function audit(
  username: string,
  action: string,
  entity: string,
  entityId?: string | number,
  details?: string,
  before?: unknown,
  after?: unknown,
) {
  await db.auditLogs.add({
    username,
    action,
    entity,
    entityId,
    details,
    beforeJson: before === undefined ? undefined : JSON.stringify(before),
    afterJson: after === undefined ? undefined : JSON.stringify(after),
    createdAt: new Date().toISOString(),
  });
}
export const tablesForBackup = [
  "students",
  "classes",
  "teachers",
  "attendance",
  "feeStructures",
  "feeDues",
  "feePayments",
  "exams",
  "examResults",
  "transportRoutes",
  "payroll",
  "users",
  "settings",
  "auditLogs",
  "notifications",
  "promotions",
  "familyBills",
  "studentTimeline",
  "documents",
  "demandBatches",
  "backupLogs",
] as const;
