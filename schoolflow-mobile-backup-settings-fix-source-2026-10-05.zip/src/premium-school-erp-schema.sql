-- Schema extracted from the user-provided public Premium School ERP backup.
-- Contains schema only; no school records or credential values.

-- TABLE: attendance
CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL REFERENCES students(id), class_id INTEGER REFERENCES classes(id), attendance_date TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('Present','Absent','Late')), academic_session TEXT NOT NULL, remarks TEXT, created_by INTEGER REFERENCES users(id), created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, UNIQUE(student_id, attendance_date));

-- TABLE: audit_logs
CREATE TABLE audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER REFERENCES users(id), action TEXT NOT NULL, entity TEXT NOT NULL, entity_id TEXT, before_json TEXT, after_json TEXT, ip_address TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);

-- TABLE: backup_logs
CREATE TABLE backup_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, backup_path TEXT NOT NULL, backup_type TEXT NOT NULL, verified INTEGER DEFAULT 0, file_size INTEGER, status TEXT, message TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);

-- TABLE: classes
CREATE TABLE classes(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, section TEXT NOT NULL DEFAULT '', academic_session TEXT NOT NULL, class_teacher_id INTEGER REFERENCES teachers(id), room_number TEXT, status TEXT DEFAULT 'Active', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, deleted_at TEXT, UNIQUE(name, section, academic_session));

-- TABLE: documents
CREATE TABLE documents(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER REFERENCES students(id), doc_type TEXT NOT NULL, file_path TEXT NOT NULL, remarks TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT);

-- TABLE: exam_results
CREATE TABLE exam_results(id INTEGER PRIMARY KEY AUTOINCREMENT, exam_id INTEGER NOT NULL REFERENCES exams(id), student_id INTEGER NOT NULL REFERENCES students(id), subject_name TEXT NOT NULL, max_marks REAL NOT NULL, marks_obtained REAL NOT NULL, grade TEXT, result_status TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, UNIQUE(exam_id, student_id, subject_name));

-- TABLE: exam_subjects
CREATE TABLE exam_subjects(id INTEGER PRIMARY KEY AUTOINCREMENT, exam_id INTEGER NOT NULL REFERENCES exams(id), subject_name TEXT NOT NULL, max_marks REAL NOT NULL DEFAULT 100, UNIQUE(exam_id, subject_name));

-- TABLE: exams
CREATE TABLE exams(id INTEGER PRIMARY KEY AUTOINCREMENT, exam_name TEXT NOT NULL, class_id INTEGER REFERENCES classes(id), section TEXT, academic_session TEXT NOT NULL, max_marks REAL DEFAULT 100, exam_date TEXT, status TEXT DEFAULT 'Active', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, deleted_at TEXT, UNIQUE(exam_name,class_id,section,academic_session));

-- TABLE: family_bill_items
CREATE TABLE family_bill_items(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  family_bill_id INTEGER NOT NULL REFERENCES family_bills(id),
  student_id INTEGER NOT NULL REFERENCES students(id),
  fee_month TEXT NOT NULL,
  fee_head TEXT NOT NULL,
  amount REAL NOT NULL DEFAULT 0,
  source TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- TABLE: family_bills
CREATE TABLE family_bills(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  family_key TEXT NOT NULL,
  parent_name TEXT,
  parent_mobile TEXT,
  bill_number TEXT NOT NULL UNIQUE,
  academic_session TEXT NOT NULL,
  months TEXT NOT NULL,
  student_names TEXT,
  class_summary TEXT,
  roll_summary TEXT,
  subtotal REAL DEFAULT 0,
  discount REAL DEFAULT 0,
  fine REAL DEFAULT 0,
  total REAL DEFAULT 0,
  paid_amount REAL DEFAULT 0,
  balance REAL DEFAULT 0,
  status TEXT DEFAULT 'Pending' CHECK(status IN ('Pending','Partial','Paid')),
  bill_date TEXT DEFAULT CURRENT_DATE,
  paid_date TEXT,
  payment_mode TEXT,
  remarks TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT,
  deleted_at TEXT
);

-- TABLE: fee_structures
CREATE TABLE fee_structures(id INTEGER PRIMARY KEY AUTOINCREMENT, class_id INTEGER REFERENCES classes(id), section TEXT, academic_session TEXT NOT NULL, tuition_fee REAL DEFAULT 0, transport_fee REAL DEFAULT 0, exam_fee REAL DEFAULT 0, admission_fee REAL DEFAULT 0, library_fee REAL DEFAULT 0, other_fee REAL DEFAULT 0, total REAL DEFAULT 0, status TEXT DEFAULT 'Active', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, deleted_at TEXT, UNIQUE(class_id, section, academic_session));

-- TABLE: fees
CREATE TABLE fees(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_number TEXT NOT NULL UNIQUE, student_id INTEGER NOT NULL REFERENCES students(id), academic_session TEXT NOT NULL, fee_month TEXT, tuition_fee REAL DEFAULT 0, transport_fee REAL DEFAULT 0, exam_fee REAL DEFAULT 0, admission_fee REAL DEFAULT 0, library_fee REAL DEFAULT 0, other_fee REAL DEFAULT 0, discount REAL DEFAULT 0, fine REAL DEFAULT 0, subtotal REAL DEFAULT 0, paid_amount REAL DEFAULT 0, balance REAL DEFAULT 0, status TEXT NOT NULL CHECK(status IN ('Paid','Pending','Partial')), paid_date TEXT, payment_mode TEXT, remarks TEXT, created_by INTEGER REFERENCES users(id), created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, deleted_at TEXT);

-- TABLE: notifications
CREATE TABLE notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, title TEXT NOT NULL, message TEXT, module TEXT, severity TEXT DEFAULT 'info', is_read INTEGER DEFAULT 0, related_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP, read_at TEXT);

-- TABLE: payroll
CREATE TABLE payroll(id INTEGER PRIMARY KEY AUTOINCREMENT, employee_name TEXT NOT NULL, role TEXT, month TEXT NOT NULL, year INTEGER NOT NULL, basic_salary REAL DEFAULT 0, allowance REAL DEFAULT 0, deduction REAL DEFAULT 0, net_salary REAL DEFAULT 0, status TEXT DEFAULT 'Unpaid' CHECK(status IN ('Paid','Unpaid')), payment_date TEXT, remarks TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, deleted_at TEXT, UNIQUE(employee_name, month, year));

-- TABLE: permissions
CREATE TABLE permissions(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, description TEXT);

-- TABLE: promotion_logs
CREATE TABLE promotion_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL REFERENCES students(id), from_class_id INTEGER, to_class_id INTEGER, from_section TEXT, to_section TEXT, old_session TEXT, new_session TEXT, old_roll_number TEXT, new_roll_number TEXT, promotion_type TEXT, rank_used INTEGER, remarks TEXT, created_by INTEGER REFERENCES users(id), created_at TEXT DEFAULT CURRENT_TIMESTAMP);

-- TABLE: role_permissions
CREATE TABLE role_permissions(role_id INTEGER NOT NULL REFERENCES roles(id), permission_id INTEGER NOT NULL REFERENCES permissions(id), PRIMARY KEY(role_id, permission_id));

-- TABLE: roles
CREATE TABLE roles(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, description TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, deleted_at TEXT);

-- TABLE: schema_migrations
CREATE TABLE schema_migrations(version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);

-- TABLE: settings
CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);

-- TABLE: student_timeline
CREATE TABLE student_timeline(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL REFERENCES students(id), event_type TEXT NOT NULL, event_title TEXT NOT NULL, details TEXT, created_by INTEGER REFERENCES users(id), created_at TEXT DEFAULT CURRENT_TIMESTAMP);

-- TABLE: students
CREATE TABLE students(
  id INTEGER PRIMARY KEY AUTOINCREMENT, admission_number TEXT NOT NULL, normalized_admission_number TEXT NOT NULL UNIQUE, student_name TEXT NOT NULL, father_name TEXT, mother_name TEXT, class_id INTEGER REFERENCES classes(id), section TEXT, roll_number TEXT, dob TEXT, gender TEXT, religion TEXT, aadhaar_number TEXT, mobile_number TEXT, address TEXT, photo_path TEXT, transport_route_id INTEGER REFERENCES transport_routes(id), vehicle_number TEXT, academic_session TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Active' CHECK(status IN ('Active','Left','TC Issued','Passed Out','Inactive')), leaving_date TEXT, leaving_reason TEXT, tc_number TEXT, tc_issue_date TEXT, last_class TEXT, admission_date TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, deleted_at TEXT
);

-- TABLE: teachers
CREATE TABLE teachers(id INTEGER PRIMARY KEY AUTOINCREMENT, teacher_id TEXT NOT NULL UNIQUE, name TEXT NOT NULL, gender TEXT, subject TEXT, qualification TEXT, mobile TEXT, address TEXT, joining_date TEXT, salary REAL DEFAULT 0, status TEXT DEFAULT 'Active', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, deleted_at TEXT);

-- TABLE: transport_routes
CREATE TABLE transport_routes(id INTEGER PRIMARY KEY AUTOINCREMENT, route_name TEXT NOT NULL UNIQUE, vehicle_number TEXT, driver_name TEXT, driver_phone TEXT, monthly_fee REAL NOT NULL DEFAULT 0, remarks TEXT, status TEXT DEFAULT 'Active', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, deleted_at TEXT);

-- TABLE: users
CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, full_name TEXT NOT NULL, role_id INTEGER NOT NULL REFERENCES roles(id), status TEXT NOT NULL DEFAULT 'Active', last_login_at TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT, deleted_at TEXT);

-- INDEX: idx_attendance_date
CREATE INDEX idx_attendance_date ON attendance(attendance_date, class_id, status);

-- INDEX: idx_classes_session
CREATE INDEX idx_classes_session ON classes(academic_session,name,section);

-- INDEX: idx_family_bill_items_bill
CREATE INDEX idx_family_bill_items_bill ON family_bill_items(family_bill_id, student_id, fee_month);

-- INDEX: idx_family_bill_items_student
CREATE INDEX idx_family_bill_items_student ON family_bill_items(student_id, fee_month);

-- INDEX: idx_family_bills_key
CREATE INDEX idx_family_bills_key ON family_bills(family_key, academic_session, status);

-- INDEX: idx_family_bills_number
CREATE INDEX idx_family_bills_number ON family_bills(bill_number);

-- INDEX: idx_family_bills_status
CREATE INDEX idx_family_bills_status ON family_bills(status, bill_date);

-- INDEX: idx_fee_duplicate_due
CREATE UNIQUE INDEX idx_fee_duplicate_due ON fees(student_id, academic_session, fee_month) WHERE deleted_at IS NULL;

-- INDEX: idx_students_roll_active
CREATE UNIQUE INDEX idx_students_roll_active ON students(class_id, section, academic_session, roll_number) WHERE deleted_at IS NULL AND status='Active' AND roll_number IS NOT NULL AND roll_number<>'';

-- INDEX: idx_students_search
CREATE INDEX idx_students_search ON students(normalized_admission_number, student_name, father_name, mother_name, mobile_number, aadhaar_number, academic_session, status);

