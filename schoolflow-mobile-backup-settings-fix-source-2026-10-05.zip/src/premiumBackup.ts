import initSqlJs from "sql.js";
import { strFromU8, strToU8, unzipSync, zipSync } from "fflate";
import wasmUrl from "sql.js/dist/sql-wasm.wasm?url";
import desktopSchema from "./premium-school-erp-schema.sql?raw";
import { hashDesktopPassword } from "./lib";
import type {
  AppUser,
  Attendance,
  BackupLog,
  DemandBatchRecord,
  Exam,
  ExamResult,
  FamilyBill,
  FeeDue,
  FeePayment,
  FeeStructure,
  Notification,
  Payroll,
  PromotionLog,
  SchoolClass,
  Setting,
  Student,
  StudentDocument,
  StudentTimeline,
  Teacher,
  TransportRoute,
} from "./types";

const BRIDGE_SETTING_KEY = "__schoolflow_portable_bridge_v1";
const DESKTOP_SCHEMA_VERSION = 3;
const DESKTOP_ROLES = [
  "Admin",
  "Teacher",
  "Accountant",
  "Reception",
  "Principal",
];
const DESKTOP_TABLES = [
  "attendance",
  "audit_logs",
  "backup_logs",
  "classes",
  "documents",
  "exams",
  "exam_results",
  "exam_subjects",
  "family_bill_items",
  "family_bills",
  "fee_structures",
  "fees",
  "notifications",
  "payroll",
  "permissions",
  "promotion_logs",
  "role_permissions",
  "roles",
  "schema_migrations",
  "settings",
  "student_timeline",
  "students",
  "teachers",
  "transport_routes",
  "users",
] as const;

type Row = Record<string, any>;
type SqlDatabase = any;
type MobileTables = Record<string, unknown[]>;
type ZipEntries = Record<string, Uint8Array>;

export interface DesktopZipBackup {
  tables: MobileTables;
  createdAt: string;
  source: "premium-desktop-zip";
  exactMobileRoundTrip: boolean;
  warnings: string[];
}

interface MobileBridgePayload {
  app: "SchoolFlow";
  version: 1;
  snapshotHash: string;
  tables: MobileTables;
}

let sqlPromise: Promise<any> | undefined;
const loadSql = async () => {
  sqlPromise ??= initSqlJs({
    locateFile: (file) => {
      if (!file.endsWith(".wasm")) return file;
      if (typeof window === "undefined")
        return new URL(
          "../node_modules/sql.js/dist/sql-wasm.wasm",
          import.meta.url,
        ).pathname;
      return wasmUrl;
    },
  });
  return sqlPromise;
};

const stringValue = (value: unknown, fallback = "") =>
  value === null || value === undefined ? fallback : String(value);
const nullableString = (value: unknown) =>
  value === null || value === undefined || value === "" ? null : String(value);
const numeric = (value: unknown, fallback = 0) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};
const nullableNumber = (value: unknown) => {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};
const sqlValue = (value: unknown): string | number | null => {
  if (value === undefined || value === null) return null;
  if (typeof value === "string") return value;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value === "boolean") return value ? 1 : 0;
  return JSON.stringify(value);
};
const quoted = (value: string) => `"${value.replace(/"/g, '""')}"`;

function rowsFor(db: SqlDatabase, table: string): Row[] {
  const order = table === "sqlite_master" ? "" : " ORDER BY rowid";
  const result = db.exec(`SELECT * FROM ${quoted(table)}${order}`)[0];
  if (!result) return [];
  return result.values.map((values: unknown[]) =>
    Object.fromEntries(
      result.columns.map((column: string, index: number) => [
        column,
        values[index],
      ]),
    ),
  );
}

function insertRows(
  db: SqlDatabase,
  table: string,
  columns: string[],
  values: unknown[][],
) {
  if (!values.length) return;
  const statement = db.prepare(
    `INSERT INTO ${quoted(table)} (${columns.map(quoted).join(",")}) VALUES (${columns.map(() => "?").join(",")})`,
  );
  try {
    for (const row of values) statement.run(row.map(sqlValue));
  } finally {
    statement.free();
  }
}

const rolesSeed = DESKTOP_ROLES.map((name, index) => ({
  id: index + 1,
  name,
}));
const roleIdFor = (role: unknown) =>
  rolesSeed.find(
    (item) => item.name.toLowerCase() === stringValue(role).toLowerCase(),
  )?.id ?? 1;

function normalizeExtensionTables(tables: MobileTables): MobileTables {
  const normalized: MobileTables = {};
  for (const [name, rows] of Object.entries(tables)) {
    if (!Array.isArray(rows)) continue;
    if (name === "students") {
      normalized[name] = rows.map((row) => {
        const { photo: _photo, ...rest } = (row || {}) as Row;
        return rest;
      });
    } else if (name === "documents") {
      normalized[name] = rows.map((row) => {
        const { dataUrl: _dataUrl, ...rest } = (row || {}) as Row;
        return rest;
      });
    } else if (name === "settings") {
      normalized[name] = rows.filter((row) => (row as Setting)?.key !== "logo");
    } else {
      normalized[name] = rows;
    }
  }
  return normalized;
}

function makeLocalStamp(value: Date) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${value.getFullYear()}${pad(value.getMonth() + 1)}${pad(value.getDate())}_${pad(value.getHours())}${pad(value.getMinutes())}${pad(value.getSeconds())}`;
}
function manifestDate(value: Date) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())} ${pad(value.getHours())}:${pad(value.getMinutes())}:${pad(value.getSeconds())}`;
}

function parseDataUrl(
  value: unknown,
): { bytes: Uint8Array; mime: string; extension: string } | null {
  if (typeof value !== "string" || !value.startsWith("data:")) return null;
  const comma = value.indexOf(",");
  if (comma < 0) return null;
  const metadata = value.slice(5, comma);
  const data = value.slice(comma + 1);
  const mime = metadata.split(";")[0] || "application/octet-stream";
  try {
    if (metadata.includes(";base64")) {
      const binary = atob(data);
      const bytes = new Uint8Array(binary.length);
      for (let index = 0; index < binary.length; index++)
        bytes[index] = binary.charCodeAt(index);
      return { bytes, mime, extension: extensionForMime(mime) };
    }
    const bytes = new TextEncoder().encode(decodeURIComponent(data));
    return { bytes, mime, extension: extensionForMime(mime) };
  } catch {
    return null;
  }
}

function extensionForMime(mime: string) {
  const normalized = mime.toLowerCase().split(";")[0];
  const known: Record<string, string> = {
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
    "image/svg+xml": "svg",
    "application/pdf": "pdf",
  };
  return known[normalized] || "bin";
}
function mimeForPath(path: string) {
  const ext = path.toLowerCase().split(".").pop();
  const known: Record<string, string> = {
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    png: "image/png",
    webp: "image/webp",
    gif: "image/gif",
    svg: "image/svg+xml",
    pdf: "application/pdf",
  };
  return known[ext || ""] || "application/octet-stream";
}
function base64Of(bytes: Uint8Array) {
  let binary = "";
  const step = 0x8000;
  for (let offset = 0; offset < bytes.length; offset += step) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + step));
  }
  return btoa(binary);
}
function dataUrlOf(bytes: Uint8Array, mime: string) {
  return `data:${mime};base64,${base64Of(bytes)}`;
}
function pathBaseName(path: unknown) {
  return (
    stringValue(path).replace(/\\/g, "/").split("/").filter(Boolean).pop() || ""
  );
}
function findAsset(entries: ZipEntries, path: unknown, folders: string[]) {
  const normalized = stringValue(path).replace(/\\/g, "/").replace(/^\/+/, "");
  if (normalized && entries[normalized]) return entries[normalized];
  const base = pathBaseName(path);
  if (!base) return undefined;
  for (const folder of folders) {
    const found = entries[`${folder.replace(/\/+$/, "")}/${base}`];
    if (found) return found;
  }
  const caseInsensitive = Object.keys(entries).find(
    (key) =>
      key.toLowerCase() === normalized.toLowerCase() ||
      key.toLowerCase().endsWith(`/${base.toLowerCase()}`),
  );
  return caseInsensitive ? entries[caseInsensitive] : undefined;
}

function rowsSnapshot(db: SqlDatabase) {
  return DESKTOP_TABLES.map((table) => {
    const rows = rowsFor(db, table);
    return [
      table,
      table === "settings"
        ? rows.filter((row) => row.key !== BRIDGE_SETTING_KEY)
        : rows,
    ];
  });
}
async function sha256Hex(value: string) {
  const digest = await globalThis.crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(value),
  );
  return Array.from(new Uint8Array(digest), (byte) =>
    byte.toString(16).padStart(2, "0"),
  ).join("");
}
async function snapshotHash(db: SqlDatabase) {
  return sha256Hex(JSON.stringify(rowsSnapshot(db)));
}

async function buildDesktopRows(
  tables: MobileTables,
  now: string,
  assets: ZipEntries,
) {
  const rows = (name: string) => (tables[name] || []) as Row[];
  const students = rows("students");
  const classes = rows("classes");
  const teachers = rows("teachers");
  const routes = rows("transportRoutes");
  const users = rows("users");
  const dues = rows("feeDues");
  const payments = rows("feePayments");
  const exams = rows("exams");
  const examResults = rows("examResults");
  const settings = rows("settings");
  const auditLogs = rows("auditLogs");
  const notifications = rows("notifications");
  const familyBills = rows("familyBills");
  const documents = rows("documents");
  const timeline = rows("studentTimeline");
  const promotions = rows("promotions");
  const payroll = rows("payroll");
  const attendance = rows("attendance");
  const feeStructures = rows("feeStructures");
  const backupLogs = rows("backupLogs");

  const teacherIds = new Set(teachers.map((teacher) => numeric(teacher.id)));
  const routeIds = new Set(routes.map((route) => numeric(route.id)));
  const classById = new Map(classes.map((item) => [numeric(item.id), item]));
  const studentById = new Map(students.map((item) => [numeric(item.id), item]));
  const userIdByName = new Map(
    users.map((item) => [
      stringValue(item.username).toLowerCase(),
      numeric(item.id),
    ]),
  );
  const idValue = (row: Row) => nullableNumber(row.id);
  const sqlTables: Record<string, { columns: string[]; values: unknown[][] }> =
    {};
  const setRows = (table: string, columns: string[], values: unknown[][]) => {
    sqlTables[table] = { columns, values };
  };

  setRows(
    "roles",
    ["id", "name", "description", "created_at"],
    rolesSeed.map((role) => [role.id, role.name, "School role", now]),
  );
  setRows("permissions", ["id", "code", "description"], []);
  setRows("role_permissions", ["role_id", "permission_id"], []);
  setRows(
    "schema_migrations",
    ["version", "name", "applied_at"],
    [
      [1, "001_initial", now],
      [2, "002_family_billing", now],
      [3, "003_app_settings", now],
    ],
  );

  setRows(
    "teachers",
    [
      "id",
      "teacher_id",
      "name",
      "gender",
      "subject",
      "qualification",
      "mobile",
      "address",
      "joining_date",
      "salary",
      "status",
      "created_at",
      "updated_at",
      "deleted_at",
    ],
    teachers.map((item) => [
      idValue(item),
      item.teacherId,
      item.name,
      item.gender,
      item.subject,
      item.qualification,
      item.mobile,
      item.address,
      item.joiningDate,
      numeric(item.salary),
      item.status,
      item.createdAt || now,
      item.updatedAt || now,
      item.deletedAt,
    ]),
  );
  setRows(
    "transport_routes",
    [
      "id",
      "route_name",
      "vehicle_number",
      "driver_name",
      "driver_phone",
      "monthly_fee",
      "remarks",
      "status",
      "created_at",
      "updated_at",
      "deleted_at",
    ],
    routes.map((item) => [
      idValue(item),
      item.name,
      item.vehicle,
      item.driver,
      item.phone,
      numeric(item.monthlyFee),
      item.remarks,
      item.status,
      item.createdAt || now,
      item.updatedAt || now,
      item.deletedAt,
    ]),
  );
  setRows(
    "classes",
    [
      "id",
      "name",
      "section",
      "academic_session",
      "class_teacher_id",
      "room_number",
      "status",
      "created_at",
      "updated_at",
      "deleted_at",
    ],
    classes.map((item) => [
      idValue(item),
      item.name,
      item.section,
      item.session,
      teacherIds.has(numeric(item.teacherId)) ? item.teacherId : null,
      item.room,
      item.status,
      item.createdAt || now,
      item.updatedAt || now,
      item.deletedAt,
    ]),
  );

  const photoPaths = new Map<number, string>();
  for (const student of students) {
    const id = numeric(student.id);
    const asset = parseDataUrl(student.photo);
    if (!asset || !student.id) continue;
    const path = `photos/student_${id}.${asset.extension}`;
    assets[path] = asset.bytes;
    photoPaths.set(id, path);
  }
  const logoSetting = settings.find((item) => item.key === "logo");
  let logoPath = "";
  const logoAsset = parseDataUrl(logoSetting?.value);
  if (logoAsset) {
    logoPath = `logos/school_logo.${logoAsset.extension}`;
    assets[logoPath] = logoAsset.bytes;
  }
  const documentPathById = new Map<number, string>();
  for (const document of documents) {
    const id = numeric(document.id);
    const asset = parseDataUrl(document.dataUrl);
    if (!asset || !document.id) continue;
    const path = `photos/document_${id}.${asset.extension}`;
    assets[path] = asset.bytes;
    documentPathById.set(id, path);
  }

  setRows(
    "students",
    [
      "id",
      "admission_number",
      "normalized_admission_number",
      "student_name",
      "father_name",
      "mother_name",
      "class_id",
      "section",
      "roll_number",
      "dob",
      "gender",
      "religion",
      "aadhaar_number",
      "mobile_number",
      "address",
      "photo_path",
      "transport_route_id",
      "vehicle_number",
      "academic_session",
      "status",
      "leaving_date",
      "leaving_reason",
      "tc_number",
      "tc_issue_date",
      "last_class",
      "admission_date",
      "created_at",
      "updated_at",
      "deleted_at",
    ],
    students.map((item) => [
      idValue(item),
      item.admissionNo,
      item.normalizedAdmissionNo || item.admissionNo,
      item.name,
      item.father,
      item.mother,
      classById.has(numeric(item.classId)) ? item.classId : null,
      item.section,
      item.roll === undefined ? null : String(item.roll),
      item.dob,
      item.gender,
      item.religion,
      item.aadhaar,
      item.mobile,
      item.address,
      photoPaths.get(numeric(item.id)) || null,
      routeIds.has(numeric(item.routeId)) ? item.routeId : null,
      item.vehicleNumber,
      item.session,
      item.status,
      item.leavingDate,
      item.leavingReason,
      item.tcNumber,
      item.tcIssueDate,
      item.lastClass,
      item.admissionDate,
      item.createdAt || now,
      item.updatedAt || now,
      item.deletedAt,
    ]),
  );

  const desktopUsers: unknown[][] = [];
  for (const user of users as (Row & Partial<AppUser>)[]) {
    let passwordHash =
      user.desktopPasswordHash ||
      (user.passwordAlgorithm === "bcrypt" ? user.passwordHash : "");
    let status = user.status || "Active";
    if (!passwordHash && status === "Active") {
      throw new Error(
        `User ${user.username || "(unknown)"} must sign in once after this update before exporting a desktop ZIP.`,
      );
    }
    if (!passwordHash) {
      passwordHash = await hashDesktopPassword(crypto.randomUUID());
      status = "Inactive";
    }
    desktopUsers.push([
      idValue(user),
      user.username,
      passwordHash,
      user.fullName,
      roleIdFor(user.role),
      status,
      user.lastLoginAt,
      user.createdAt || now,
      user.updatedAt || now,
      user.deletedAt,
    ]);
  }
  setRows(
    "users",
    [
      "id",
      "username",
      "password_hash",
      "full_name",
      "role_id",
      "status",
      "last_login_at",
      "created_at",
      "updated_at",
      "deleted_at",
    ],
    desktopUsers,
  );

  setRows(
    "attendance",
    [
      "id",
      "student_id",
      "class_id",
      "attendance_date",
      "status",
      "academic_session",
      "remarks",
      "created_by",
      "created_at",
      "updated_at",
    ],
    attendance
      .filter((item) => studentById.has(numeric(item.studentId)))
      .map((item) => [
        idValue(item),
        item.studentId,
        classById.has(numeric(item.classId)) ? item.classId : null,
        item.date,
        item.status,
        item.session,
        item.remarks,
        userIdByName.get(stringValue(item.username).toLowerCase()) || null,
        item.createdAt || item.updatedAt || now,
        item.updatedAt || now,
      ]),
  );
  setRows(
    "fee_structures",
    [
      "id",
      "class_id",
      "section",
      "academic_session",
      "tuition_fee",
      "transport_fee",
      "exam_fee",
      "admission_fee",
      "library_fee",
      "other_fee",
      "total",
      "status",
      "created_at",
      "updated_at",
      "deleted_at",
    ],
    feeStructures.map((item) => [
      idValue(item),
      classById.has(numeric(item.classId)) ? item.classId : null,
      item.section,
      item.session,
      numeric(item.tuition),
      numeric(item.transport),
      numeric(item.exam),
      numeric(item.admission),
      numeric(item.library),
      numeric(item.other),
      numeric(item.total),
      item.status,
      item.createdAt || now,
      item.updatedAt || now,
      item.deletedAt,
    ]),
  );

  const paymentByDue = new Map<number, Row[]>();
  for (const payment of payments) {
    const id = numeric(payment.dueId);
    paymentByDue.set(id, [...(paymentByDue.get(id) || []), payment]);
  }
  const feeRows = dues
    .filter((due) => studentById.has(numeric(due.studentId)))
    .map((due) => {
      const duePayments = (paymentByDue.get(numeric(due.id)) || []).sort(
        (a, b) => stringValue(a.paidAt).localeCompare(stringValue(b.paidAt)),
      );
      const latest = duePayments[duePayments.length - 1];
      const heads = [
        due.tuition,
        due.transport,
        due.exam,
        due.admission,
        due.library,
        due.other,
      ].reduce((sum, amount) => sum + numeric(amount), 0);
      const receipt =
        latest?.receiptNo ||
        `MOBILE-DUE-${due.id ?? `${due.studentId}-${due.session}-${due.month}`}`;
      return [
        idValue(due),
        receipt,
        due.studentId,
        due.session,
        due.month,
        numeric(due.tuition),
        numeric(due.transport),
        numeric(due.exam),
        numeric(due.admission),
        numeric(due.library),
        numeric(due.other),
        numeric(due.discount),
        numeric(due.fine),
        heads,
        numeric(due.paid),
        numeric(due.balance),
        due.status,
        latest?.paidAt || null,
        latest?.mode || null,
        latest?.remarks || null,
        userIdByName.get(stringValue(latest?.username).toLowerCase()) || null,
        due.createdAt || now,
        due.updatedAt || now,
        null,
      ];
    });
  setRows(
    "fees",
    [
      "id",
      "receipt_number",
      "student_id",
      "academic_session",
      "fee_month",
      "tuition_fee",
      "transport_fee",
      "exam_fee",
      "admission_fee",
      "library_fee",
      "other_fee",
      "discount",
      "fine",
      "subtotal",
      "paid_amount",
      "balance",
      "status",
      "paid_date",
      "payment_mode",
      "remarks",
      "created_by",
      "created_at",
      "updated_at",
      "deleted_at",
    ],
    feeRows,
  );

  setRows(
    "exams",
    [
      "id",
      "exam_name",
      "class_id",
      "section",
      "academic_session",
      "max_marks",
      "exam_date",
      "status",
      "created_at",
      "updated_at",
      "deleted_at",
    ],
    exams.map((item) => [
      idValue(item),
      item.name,
      classById.has(numeric(item.classId)) ? item.classId : null,
      item.section,
      item.session,
      numeric(item.maxMarks, 100),
      item.date,
      item.status === "Completed" ? "Completed" : "Active",
      item.createdAt || now,
      item.updatedAt || now,
      item.deletedAt,
    ]),
  );
  const examIdSet = new Set(exams.map((item) => numeric(item.id)));
  const subjectRows: unknown[][] = [];
  for (const exam of exams) {
    for (const subject of Array.isArray(exam.subjects) ? exam.subjects : []) {
      subjectRows.push([
        null,
        exam.id,
        subject,
        numeric(exam.subjectMaxMarks?.[subject], numeric(exam.maxMarks, 100)),
      ]);
    }
  }
  setRows(
    "exam_subjects",
    ["id", "exam_id", "subject_name", "max_marks"],
    subjectRows,
  );
  setRows(
    "exam_results",
    [
      "id",
      "exam_id",
      "student_id",
      "subject_name",
      "max_marks",
      "marks_obtained",
      "grade",
      "result_status",
      "created_at",
      "updated_at",
    ],
    examResults
      .filter(
        (item) =>
          examIdSet.has(numeric(item.examId)) &&
          studentById.has(numeric(item.studentId)),
      )
      .map((item) => [
        idValue(item),
        item.examId,
        item.studentId,
        item.subject,
        numeric(item.maxMarks),
        numeric(item.marks),
        item.grade,
        item.result,
        now,
        now,
      ]),
  );

  setRows(
    "payroll",
    [
      "id",
      "employee_name",
      "role",
      "month",
      "year",
      "basic_salary",
      "allowance",
      "deduction",
      "net_salary",
      "status",
      "payment_date",
      "remarks",
      "created_at",
      "updated_at",
      "deleted_at",
    ],
    payroll.map((item) => {
      const parts = stringValue(item.month).match(/^(\d{4})[-/](\d{1,2})$/);
      const year = parts ? numeric(parts[1]) : new Date().getFullYear();
      const month = parts
        ? String(Number(parts[2])).padStart(2, "0")
        : stringValue(item.month);
      return [
        idValue(item),
        item.name,
        item.role,
        month,
        year,
        numeric(item.basic),
        numeric(item.allowance),
        numeric(item.deduction),
        numeric(item.net),
        item.status,
        item.paymentDate,
        item.remarks,
        item.createdAt || now,
        item.updatedAt || now,
        item.deletedAt,
      ];
    }),
  );

  setRows(
    "audit_logs",
    [
      "id",
      "user_id",
      "action",
      "entity",
      "entity_id",
      "before_json",
      "after_json",
      "ip_address",
      "created_at",
    ],
    auditLogs.map((item) => [
      idValue(item),
      userIdByName.get(stringValue(item.username).toLowerCase()) || null,
      item.action,
      item.entity,
      item.entityId === undefined ? null : String(item.entityId),
      item.beforeJson,
      item.afterJson || item.details,
      null,
      item.createdAt || now,
    ]),
  );
  setRows(
    "notifications",
    [
      "id",
      "type",
      "title",
      "message",
      "module",
      "severity",
      "is_read",
      "related_id",
      "created_at",
      "read_at",
    ],
    notifications.map((item) => [
      idValue(item),
      item.type,
      item.title,
      item.message,
      item.module,
      item.severity,
      item.isRead ? 1 : 0,
      nullableNumber(item.relatedId),
      item.createdAt || now,
      item.readAt,
    ]),
  );
  setRows(
    "promotion_logs",
    [
      "id",
      "student_id",
      "from_class_id",
      "to_class_id",
      "from_section",
      "to_section",
      "old_session",
      "new_session",
      "old_roll_number",
      "new_roll_number",
      "promotion_type",
      "rank_used",
      "remarks",
      "created_by",
      "created_at",
    ],
    promotions
      .filter((item) => studentById.has(numeric(item.studentId)))
      .map((item) => {
        const fromClass = classes.find(
          (candidate) =>
            candidate.name === item.fromClass &&
            candidate.session === item.fromSession,
        );
        const toClass = classes.find(
          (candidate) =>
            candidate.name === item.toClass &&
            candidate.session === item.toSession,
        );
        return [
          idValue(item),
          item.studentId,
          fromClass?.id ?? null,
          toClass?.id ?? null,
          item.fromSection,
          item.toSection,
          item.fromSession,
          item.toSession,
          String(item.oldRoll),
          String(item.newRoll),
          item.type,
          item.rankUsed,
          item.remarks,
          userIdByName.get(stringValue(item.username).toLowerCase()) || null,
          item.createdAt || now,
        ];
      }),
  );

  const familyItemRows: unknown[][] = [];
  const studentNamesForBill = (bill: Row) =>
    (bill.studentIds || [])
      .map((id: unknown) => studentById.get(numeric(id)))
      .filter(Boolean) as Row[];
  const currentSession = stringValue(
    settings.find((item) => item.key === "academicSession")?.value,
    "",
  );
  setRows(
    "family_bills",
    [
      "id",
      "family_key",
      "parent_name",
      "parent_mobile",
      "bill_number",
      "academic_session",
      "months",
      "student_names",
      "class_summary",
      "roll_summary",
      "subtotal",
      "discount",
      "fine",
      "total",
      "paid_amount",
      "balance",
      "status",
      "bill_date",
      "paid_date",
      "payment_mode",
      "remarks",
      "created_at",
      "updated_at",
      "deleted_at",
    ],
    familyBills.map((bill) => {
      const billStudents = studentNamesForBill(bill);
      const months = Array.isArray(bill.months) ? bill.months : [];
      const itemRows = Array.isArray(bill.items) ? bill.items : [];
      const subtotal = itemRows.reduce(
        (sum: number, item: Row) => sum + numeric(item.amount),
        0,
      );
      for (const item of itemRows) {
        if (!studentById.has(numeric(item.studentId))) continue;
        familyItemRows.push([
          null,
          bill.id,
          item.studentId,
          item.feeMonth,
          item.feeHead,
          numeric(item.amount),
          item.source,
          item.createdAt || bill.createdAt || now,
        ]);
      }
      const billTotal = numeric(bill.total);
      const billDiscount = numeric(bill.discount);
      const billFine = numeric(bill.fine);
      const paid = numeric(bill.paid);
      return [
        idValue(bill),
        bill.familyKey,
        bill.parent,
        bill.mobile,
        bill.billNo,
        currentSession,
        JSON.stringify(months),
        billStudents.map((student) => student.name).join(", "),
        billStudents
          .map(
            (student) =>
              `${classById.get(numeric(student.classId))?.name || ""}-${student.section || ""}`,
          )
          .join(", "),
        billStudents.map((student) => String(student.roll ?? "")).join(", "),
        subtotal || billTotal + billDiscount - billFine,
        billDiscount,
        billFine,
        billTotal,
        paid,
        numeric(bill.balance, Math.max(0, billTotal - paid)),
        bill.status ||
          (paid >= billTotal ? "Paid" : paid ? "Partial" : "Pending"),
        stringValue(bill.createdAt).slice(0, 10) || null,
        bill.paymentDate || null,
        bill.paymentMode,
        bill.remarks,
        bill.createdAt || now,
        bill.updatedAt || now,
        bill.deletedAt,
      ];
    }),
  );
  setRows(
    "family_bill_items",
    [
      "id",
      "family_bill_id",
      "student_id",
      "fee_month",
      "fee_head",
      "amount",
      "source",
      "created_at",
    ],
    familyItemRows,
  );

  setRows(
    "student_timeline",
    [
      "id",
      "student_id",
      "event_type",
      "event_title",
      "details",
      "created_by",
      "created_at",
    ],
    timeline
      .filter((item) => studentById.has(numeric(item.studentId)))
      .map((item) => [
        idValue(item),
        item.studentId,
        item.eventType,
        item.title,
        item.details,
        userIdByName.get(stringValue(item.username).toLowerCase()) || null,
        item.createdAt || now,
      ]),
  );
  setRows(
    "documents",
    [
      "id",
      "student_id",
      "doc_type",
      "file_path",
      "remarks",
      "created_at",
      "deleted_at",
    ],
    documents
      .filter((item) => studentById.has(numeric(item.studentId)))
      .map((item) => [
        idValue(item),
        item.studentId,
        item.docType,
        documentPathById.get(numeric(item.id)) ||
          `photos/document_${item.id || "new"}.bin`,
        item.remarks,
        item.createdAt || now,
        item.deletedAt,
      ]),
  );
  setRows(
    "backup_logs",
    [
      "id",
      "backup_path",
      "backup_type",
      "verified",
      "file_size",
      "status",
      "message",
      "created_at",
    ],
    backupLogs.map((item) => [
      idValue(item),
      item.filename,
      item.type,
      item.verified ? 1 : 0,
      numeric(item.size),
      "created",
      null,
      item.createdAt || now,
    ]),
  );

  const desktopSettingMap: Record<string, string> = {
    schoolName: "school_name",
    address: "school_address",
    phone: "school_phone",
    email: "school_email",
    website: "school_website",
    principalName: "principal_name",
    academicSession: "academic_session",
    defaultFeeMonth: "default_fee_month",
    resultTemplate: "default_result_template",
    printFooter: "print_footer_note",
    receiptFooter: "receipt_footer_note",
    autoBackup: "auto_backup",
    autoBackupFrequency: "auto_backup_frequency",
    keepBackupsCount: "keep_backups_count",
    developerName: "developer_name",
    theme: "theme_preference",
  };
  const settingPairs = new Map<string, unknown>();
  for (const item of settings) {
    if (item.key === "logo" || item.key === "setupComplete") continue;
    settingPairs.set(
      desktopSettingMap[item.key] || `mobile_${item.key}`,
      item.value,
    );
  }
  if (logoPath) settingPairs.set("logo_path", logoPath);
  else settingPairs.set("logo_path", "");
  const settingRows = [...settingPairs.entries()].map(([key, value]) => [
    key,
    typeof value === "string" ? value : JSON.stringify(value),
    now,
  ]);
  setRows("settings", ["key", "value", "updated_at"], settingRows);

  return {
    sqlTables,
    students,
    classes,
    teachers,
    routes,
    users,
    dues,
    payments,
    exams,
    familyBills,
    documents,
    currentSession,
  };
}

export async function createPremiumSchoolErpZip(
  tables: MobileTables,
  createdAt = new Date().toISOString(),
): Promise<Blob> {
  const SQL = await loadSql();
  const database: SqlDatabase = new SQL.Database();
  try {
    database.exec("PRAGMA foreign_keys=OFF;");
    database.exec(desktopSchema);
    const suppliedDate = new Date(createdAt);
    const date = Number.isFinite(suppliedDate.getTime())
      ? suppliedDate
      : new Date();
    const now = date.toISOString();
    const files: ZipEntries = {};
    const mapped = await buildDesktopRows(tables, now, files);
    for (const table of DESKTOP_TABLES) {
      const data = mapped.sqlTables[table];
      if (data) insertRows(database, table, data.columns, data.values);
    }
    const bridgePayload: MobileBridgePayload = {
      app: "SchoolFlow",
      version: 1,
      snapshotHash: await snapshotHash(database),
      tables: normalizeExtensionTables(tables),
    };
    insertRows(
      database,
      "settings",
      ["key", "value", "updated_at"],
      [[BRIDGE_SETTING_KEY, JSON.stringify(bridgePayload), now]],
    );
    database.exec("PRAGMA foreign_keys=ON;");
    const foreignErrors =
      database.exec("PRAGMA foreign_key_check")[0]?.values || [];
    if (foreignErrors.length)
      throw new Error(
        "Some records could not be linked in the desktop backup database.",
      );
    const dbBytes = database.export();
    files["school_erp.sqlite3"] = dbBytes;
    files["manifest.txt"] = strToU8(
      `Premium School ERP full backup\nCreated: ${manifestDate(date)}\nIncludes: SQLite database + photos/logos folders`,
    );
    return new Blob([zipSync(files, { level: 6 })], {
      type: "application/zip",
    });
  } finally {
    database.close();
  }
}

function rawValue(value: unknown) {
  return value === undefined || value === null ? "" : String(value);
}
function parseSetting(value: unknown, key: string) {
  const raw = rawValue(value);
  const boolKeys = new Set(["setupComplete", "bigText"]);
  const numberKeys = new Set(["textSize", "keepBackupsCount", "defaultFeeDay"]);
  if (boolKeys.has(key)) return raw === "true" || raw === "1";
  if (numberKeys.has(key) && raw !== "") return numeric(raw);
  if (raw === "true") return true;
  if (raw === "false") return false;
  return raw;
}
function safeJson(value: unknown): any {
  if (typeof value !== "string") return undefined;
  try {
    return JSON.parse(value);
  } catch {
    return undefined;
  }
}
function parseMonthList(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(String);
  const parsed = safeJson(value);
  if (Array.isArray(parsed)) return parsed.map(String);
  return stringValue(value)
    .split(/[,|]/)
    .map((item) => item.trim())
    .filter(Boolean);
}
function parseManifestCreatedAt(value: Uint8Array | undefined) {
  if (!value) return new Date().toISOString();
  const manifest = strFromU8(value);
  const line = manifest
    .split(/\r?\n/)
    .find((item) => item.startsWith("Created:"));
  const raw = line?.slice("Created:".length).trim();
  if (!raw) return new Date().toISOString();
  const normalized = raw.replace(" ", "T");
  const date = new Date(normalized);
  return Number.isFinite(date.getTime()) ? date.toISOString() : raw;
}
function fileRows(db: SqlDatabase, table: string) {
  try {
    return rowsFor(db, table);
  } catch {
    return [];
  }
}

function mapDesktopTablesToMobile(
  db: SqlDatabase,
  files: ZipEntries,
  bridge?: MobileBridgePayload,
): MobileTables {
  const source = Object.fromEntries(
    DESKTOP_TABLES.map((table) => [table, fileRows(db, table)]),
  ) as Record<string, Row[]>;
  const desktopSettings = source.settings.filter(
    (row) => row.key !== BRIDGE_SETTING_KEY,
  );
  const roles = new Map(
    source.roles.map((role) => [
      numeric(role.id),
      stringValue(role.name, "Admin"),
    ]),
  );
  const studentsById = new Map(
    source.students.map((item) => [numeric(item.id), item]),
  );
  const classesById = new Map(
    source.classes.map((item) => [numeric(item.id), item]),
  );
  const studentAssetRows = new Map<number, string>();
  const settingsObj = new Map(
    desktopSettings.map((item) => [
      stringValue(item.key),
      rawValue(item.value),
    ]),
  );

  const users: AppUser[] = source.users.map((item) => {
    const username = stringValue(item.username).toLowerCase();
    const fullName = stringValue(item.full_name).toLowerCase();
    const teacher = source.teachers.find(
      (candidate) =>
        stringValue(candidate.teacher_id).toLowerCase() === username ||
        stringValue(candidate.name).toLowerCase() === fullName,
    );
    return {
      id: numeric(item.id),
      username,
      passwordHash: stringValue(item.password_hash),
      salt: "",
      passwordAlgorithm: "bcrypt",
      desktopPasswordHash: stringValue(item.password_hash),
      fullName: stringValue(item.full_name, stringValue(item.username)),
      role: (roles.get(numeric(item.role_id)) || "Admin") as AppUser["role"],
      teacherId: teacher ? numeric(teacher.id) : undefined,
      status:
        stringValue(item.status, "Active") === "Inactive"
          ? "Inactive"
          : "Active",
      mustChange: false,
      lastLoginAt: nullableString(item.last_login_at) || undefined,
    };
  });

  const teachers: Teacher[] = source.teachers.map((item) => ({
    id: numeric(item.id),
    teacherId: stringValue(item.teacher_id),
    name: stringValue(item.name),
    gender: stringValue(item.gender),
    subject: stringValue(item.subject),
    qualification: nullableString(item.qualification) || undefined,
    mobile: stringValue(item.mobile),
    address: nullableString(item.address) || undefined,
    joiningDate: nullableString(item.joining_date) || undefined,
    salary: numeric(item.salary),
    status:
      stringValue(item.status, "Active") === "Inactive" ? "Inactive" : "Active",
    deletedAt: nullableString(item.deleted_at) || undefined,
  }));
  const classes: SchoolClass[] = source.classes.map((item) => ({
    id: numeric(item.id),
    name: stringValue(item.name),
    section: stringValue(item.section),
    session: stringValue(item.academic_session),
    teacherId: nullableNumber(item.class_teacher_id) ?? undefined,
    room: nullableString(item.room_number) || undefined,
    status:
      stringValue(item.status, "Active") === "Inactive" ? "Inactive" : "Active",
    createdAt: stringValue(item.created_at),
    updatedAt: stringValue(item.updated_at, stringValue(item.created_at)),
    deletedAt: nullableString(item.deleted_at) || undefined,
  }));
  const routes: TransportRoute[] = source.transport_routes.map((item) => ({
    id: numeric(item.id),
    name: stringValue(item.route_name),
    vehicle: stringValue(item.vehicle_number),
    driver: stringValue(item.driver_name),
    phone: stringValue(item.driver_phone),
    monthlyFee: numeric(item.monthly_fee),
    capacity: 0,
    remarks: nullableString(item.remarks) || undefined,
    status:
      stringValue(item.status, "Active") === "Inactive" ? "Inactive" : "Active",
  }));
  const routeIds = new Set(routes.map((route) => route.id));
  const students: Student[] = source.students.map((item) => {
    const photoBytes = findAsset(files, item.photo_path, ["photos"]);
    const photoPath = stringValue(item.photo_path);
    const id = numeric(item.id);
    if (photoBytes)
      studentAssetRows.set(
        id,
        dataUrlOf(
          photoBytes,
          mimeForPath(photoPath || pathBaseName(item.photo_path)),
        ),
      );
    return {
      id,
      admissionNo: stringValue(item.admission_number),
      normalizedAdmissionNo: stringValue(
        item.normalized_admission_number,
        stringValue(item.admission_number).toUpperCase(),
      ),
      name: stringValue(item.student_name),
      father: stringValue(item.father_name),
      mother: stringValue(item.mother_name),
      classId: nullableNumber(item.class_id) ?? 0,
      section: stringValue(item.section),
      roll: numeric(item.roll_number),
      dob: stringValue(item.dob),
      gender: stringValue(item.gender),
      religion: nullableString(item.religion) || undefined,
      aadhaar: nullableString(item.aadhaar_number) || undefined,
      mobile: stringValue(item.mobile_number),
      address: nullableString(item.address) || undefined,
      photo: photoBytes
        ? dataUrlOf(
            photoBytes,
            mimeForPath(photoPath || pathBaseName(item.photo_path)),
          )
        : undefined,
      routeId: routeIds.has(numeric(item.transport_route_id))
        ? numeric(item.transport_route_id)
        : undefined,
      vehicleNumber: nullableString(item.vehicle_number) || undefined,
      session: stringValue(item.academic_session),
      status: stringValue(item.status, "Active") as Student["status"],
      leavingDate: nullableString(item.leaving_date) || undefined,
      leavingReason: nullableString(item.leaving_reason) || undefined,
      tcNumber: nullableString(item.tc_number) || undefined,
      tcIssueDate: nullableString(item.tc_issue_date) || undefined,
      lastClass: nullableString(item.last_class) || undefined,
      admissionDate: stringValue(
        item.admission_date,
        stringValue(item.created_at),
      ),
      createdAt: stringValue(item.created_at),
      updatedAt: stringValue(item.updated_at, stringValue(item.created_at)),
      deletedAt: nullableString(item.deleted_at) || undefined,
    };
  });
  const studentIds = new Set(students.map((student) => student.id));
  const attendance: Attendance[] = source.attendance
    .filter((item) => studentIds.has(numeric(item.student_id)))
    .map((item) => ({
      id: numeric(item.id),
      studentId: numeric(item.student_id),
      classId: nullableNumber(item.class_id) ?? 0,
      section: stringValue(classesById.get(numeric(item.class_id))?.section),
      session: stringValue(item.academic_session),
      date: stringValue(item.attendance_date),
      status: stringValue(item.status, "Present") as Attendance["status"],
      remarks: nullableString(item.remarks) || undefined,
      updatedAt: stringValue(item.updated_at, stringValue(item.created_at)),
    }));
  const feeStructures: FeeStructure[] = source.fee_structures.map((item) => ({
    id: numeric(item.id),
    classId: nullableNumber(item.class_id) ?? 0,
    section: stringValue(item.section),
    session: stringValue(item.academic_session),
    tuition: numeric(item.tuition_fee),
    transport: numeric(item.transport_fee),
    exam: numeric(item.exam_fee),
    admission: numeric(item.admission_fee),
    library: numeric(item.library_fee),
    other: numeric(item.other_fee),
    total: numeric(item.total),
    status:
      stringValue(item.status, "Active") === "Inactive" ? "Inactive" : "Active",
  }));
  const feeDues: FeeDue[] = source.fees
    .filter((item) => studentIds.has(numeric(item.student_id)))
    .map((item) => {
      const paid = numeric(item.paid_amount);
      const balance = numeric(item.balance);
      const total =
        paid + balance ||
        numeric(item.subtotal) - numeric(item.discount) + numeric(item.fine);
      return {
        id: numeric(item.id),
        studentId: numeric(item.student_id),
        session: stringValue(item.academic_session),
        month: stringValue(item.fee_month),
        tuition: numeric(item.tuition_fee),
        transport: numeric(item.transport_fee),
        exam: numeric(item.exam_fee),
        admission: numeric(item.admission_fee),
        library: numeric(item.library_fee),
        other: numeric(item.other_fee),
        discount: numeric(item.discount),
        fine: numeric(item.fine),
        total,
        paid,
        balance,
        status: stringValue(
          item.status,
          balance ? "Pending" : "Paid",
        ) as FeeDue["status"],
        createdAt: stringValue(item.created_at),
        updatedAt: stringValue(item.updated_at, stringValue(item.created_at)),
      };
    });
  const feePayments: FeePayment[] = source.fees
    .filter(
      (item) =>
        studentIds.has(numeric(item.student_id)) &&
        numeric(item.paid_amount) > 0,
    )
    .map((item) => ({
      receiptNo: stringValue(item.receipt_number),
      dueId: numeric(item.id),
      studentId: numeric(item.student_id),
      amount: numeric(item.paid_amount),
      mode: stringValue(item.payment_mode),
      paidAt: stringValue(item.paid_date, stringValue(item.created_at)),
      remarks: nullableString(item.remarks) || undefined,
    }));

  const examSubjects = new Map<number, Row[]>();
  for (const subject of source.exam_subjects) {
    const list = examSubjects.get(numeric(subject.exam_id)) || [];
    list.push(subject);
    examSubjects.set(numeric(subject.exam_id), list);
  }
  const exams: Exam[] = source.exams.map((item) => {
    const subjects = examSubjects.get(numeric(item.id)) || [];
    return {
      id: numeric(item.id),
      name: stringValue(item.exam_name),
      classId: nullableNumber(item.class_id) ?? 0,
      section: stringValue(item.section),
      session: stringValue(item.academic_session),
      date: stringValue(item.exam_date),
      subjects: subjects.map((subject) => stringValue(subject.subject_name)),
      subjectMaxMarks: Object.fromEntries(
        subjects.map((subject) => [
          stringValue(subject.subject_name),
          numeric(subject.max_marks, 100),
        ]),
      ),
      maxMarks: numeric(item.max_marks, 100),
      status:
        stringValue(item.status) === "Completed" ? "Completed" : "Planned",
    };
  });
  const examIds = new Set(exams.map((item) => item.id));
  const examResults: ExamResult[] = source.exam_results
    .filter(
      (item) =>
        examIds.has(numeric(item.exam_id)) &&
        studentIds.has(numeric(item.student_id)),
    )
    .map((item) => ({
      id: numeric(item.id),
      examId: numeric(item.exam_id),
      studentId: numeric(item.student_id),
      subject: stringValue(item.subject_name),
      maxMarks: numeric(item.max_marks),
      marks: numeric(item.marks_obtained),
      grade: stringValue(item.grade),
      result: stringValue(
        item.result_status,
        numeric(item.marks_obtained) >= numeric(item.max_marks) / 2
          ? "Pass"
          : "Fail",
      ) as ExamResult["result"],
    }));
  const transportRoutes = routes;
  const payroll: Payroll[] = source.payroll.map((item) => ({
    id: numeric(item.id),
    name: stringValue(item.employee_name),
    role: stringValue(item.role),
    month: `${numeric(item.year)}-${String(item.month).padStart(2, "0")}`,
    basic: numeric(item.basic_salary),
    allowance: numeric(item.allowance),
    deduction: numeric(item.deduction),
    net: numeric(item.net_salary),
    status: stringValue(item.status, "Unpaid") as Payroll["status"],
    paymentDate: nullableString(item.payment_date) || undefined,
    updatedAt: stringValue(item.updated_at, stringValue(item.created_at)),
  }));
  const userNameById = new Map(
    users.map((user) => [numeric(user.id), user.username]),
  );
  const auditLogs = source.audit_logs.map((item) => ({
    id: numeric(item.id),
    username: userNameById.get(numeric(item.user_id)) || "admin",
    action: stringValue(item.action),
    entity: stringValue(item.entity),
    entityId: nullableString(item.entity_id) || undefined,
    beforeJson: nullableString(item.before_json) || undefined,
    afterJson: nullableString(item.after_json) || undefined,
    details: nullableString(item.after_json) || undefined,
    createdAt: stringValue(item.created_at),
  }));
  const notifications: Notification[] = source.notifications.map((item) => ({
    id: numeric(item.id),
    type: stringValue(item.type),
    title: stringValue(item.title),
    message: stringValue(item.message),
    module: stringValue(item.module),
    severity: stringValue(item.severity, "info") as Notification["severity"],
    isRead: Boolean(numeric(item.is_read)),
    createdAt: stringValue(item.created_at),
    relatedId: nullableNumber(item.related_id) ?? undefined,
  }));
  const promotions: PromotionLog[] = source.promotion_logs
    .filter((item) => studentIds.has(numeric(item.student_id)))
    .map((item) => ({
      id: numeric(item.id),
      studentId: numeric(item.student_id),
      fromClass: stringValue(
        classesById.get(numeric(item.from_class_id))?.name,
      ),
      toClass: stringValue(classesById.get(numeric(item.to_class_id))?.name),
      fromSession: stringValue(item.old_session),
      toSession: stringValue(item.new_session),
      oldRoll: numeric(item.old_roll_number),
      newRoll: numeric(item.new_roll_number),
      type: stringValue(item.promotion_type, "normal") as PromotionLog["type"],
      rankUsed: nullableNumber(item.rank_used) ?? undefined,
      remarks: nullableString(item.remarks) || undefined,
      createdAt: stringValue(item.created_at),
      username: userNameById.get(numeric(item.created_by)) || undefined,
    }));
  const familyItemsByBill = new Map<number, Row[]>();
  for (const item of source.family_bill_items) {
    const id = numeric(item.family_bill_id);
    familyItemsByBill.set(id, [...(familyItemsByBill.get(id) || []), item]);
  }
  const familyBills: FamilyBill[] = source.family_bills.map((item) => {
    const items = familyItemsByBill.get(numeric(item.id)) || [];
    const itemDtos = items
      .filter((line) => studentIds.has(numeric(line.student_id)))
      .map((line) => {
        const student = studentsById.get(numeric(line.student_id));
        const classItem = student
          ? classesById.get(numeric(student.class_id))
          : undefined;
        return {
          studentId: numeric(line.student_id),
          studentName: stringValue(student?.student_name),
          className: stringValue(classItem?.name),
          section: stringValue(student?.section),
          feeMonth: stringValue(line.fee_month),
          feeHead: stringValue(line.fee_head),
          amount: numeric(line.amount),
          source: stringValue(line.source, "Due") as any,
        };
      });
    const months = parseMonthList(item.months);
    return {
      id: numeric(item.id),
      billNo: stringValue(item.bill_number),
      familyKey: stringValue(item.family_key),
      parent: stringValue(item.parent_name),
      mobile: stringValue(item.parent_mobile),
      studentIds: [...new Set(itemDtos.map((line) => line.studentId))],
      total: numeric(item.total),
      discount: numeric(item.discount),
      fine: numeric(item.fine),
      paid: numeric(item.paid_amount),
      createdAt: stringValue(item.created_at),
      months,
      balance: numeric(item.balance),
      status: stringValue(item.status, "Pending") as FamilyBill["status"],
      paymentMode: nullableString(item.payment_mode) || undefined,
      updatedAt: nullableString(item.updated_at) || undefined,
      items: itemDtos,
    };
  });
  const timeline: StudentTimeline[] = source.student_timeline
    .filter((item) => studentIds.has(numeric(item.student_id)))
    .map((item) => ({
      id: numeric(item.id),
      studentId: numeric(item.student_id),
      eventType: stringValue(item.event_type),
      title: stringValue(item.event_title),
      details: nullableString(item.details) || undefined,
      createdAt: stringValue(item.created_at),
      username: userNameById.get(numeric(item.created_by)) || undefined,
    }));
  const documents: StudentDocument[] = source.documents
    .filter((item) => studentIds.has(numeric(item.student_id)))
    .map((item) => {
      const filePath = stringValue(item.file_path);
      const bytes = findAsset(files, filePath, ["photos", "documents"]);
      return {
        id: numeric(item.id),
        studentId: numeric(item.student_id),
        docType: stringValue(item.doc_type),
        fileName: pathBaseName(filePath) || `document-${item.id}`,
        mimeType: mimeForPath(filePath),
        dataUrl: bytes ? dataUrlOf(bytes, mimeForPath(filePath)) : "",
        remarks: nullableString(item.remarks) || undefined,
        createdAt: stringValue(item.created_at),
        deletedAt: nullableString(item.deleted_at) || undefined,
      };
    });
  const studentTimeline = timeline;
  const backupLogs: BackupLog[] = source.backup_logs.map((item) => ({
    id: numeric(item.id),
    filename: pathBaseName(item.backup_path) || stringValue(item.backup_path),
    size: numeric(item.file_size),
    type: stringValue(item.backup_type, "download") as BackupLog["type"],
    verified: Boolean(numeric(item.verified)),
    createdAt: stringValue(item.created_at),
  }));
  const mobileSettingsMap: Record<string, string> = {
    school_name: "schoolName",
    school_address: "address",
    school_phone: "phone",
    school_email: "email",
    school_website: "website",
    principal_name: "principalName",
    academic_session: "academicSession",
    default_fee_month: "defaultFeeMonth",
    default_result_template: "resultTemplate",
    print_footer_note: "printFooter",
    receipt_footer_note: "receiptFooter",
    auto_backup: "autoBackup",
    auto_backup_frequency: "autoBackupFrequency",
    keep_backups_count: "keepBackupsCount",
    theme_preference: "theme",
    developer_name: "developerName",
  };
  const settings: Setting[] = desktopSettings
    .map((item) => {
      const key =
        mobileSettingsMap[stringValue(item.key)] ||
        stringValue(item.key).replace(/^mobile_/, "");
      return { key, value: parseSetting(item.value, key) };
    })
    .filter((item) => !item.key.startsWith("__schoolflow"));
  const logoBytes = findAsset(files, settingsObj.get("logo_path"), [
    "logos",
    "photos",
  ]);
  if (logoBytes)
    settings.push({
      key: "logo",
      value: dataUrlOf(
        logoBytes,
        mimeForPath(stringValue(settingsObj.get("logo_path"))),
      ),
    });
  settings.push({ key: "setupComplete", value: true });

  const tableResult: MobileTables = {
    students,
    classes,
    teachers,
    attendance,
    feeStructures,
    feeDues,
    feePayments,
    exams,
    examResults,
    transportRoutes,
    payroll,
    users,
    settings,
    auditLogs,
    notifications,
    promotions,
    familyBills,
    studentTimeline,
    documents,
    demandBatches: [],
    backupLogs,
  };

  if (
    bridge &&
    bridge.version === 1 &&
    bridge.tables &&
    typeof bridge.tables === "object"
  ) {
    for (const [name, rows] of Object.entries(bridge.tables)) {
      if (Array.isArray(rows)) tableResult[name] = rows;
    }
    for (const student of tableResult.students as Student[]) {
      const photo = studentAssetRows.get(numeric(student.id));
      if (photo) student.photo = photo;
    }
    const documentDataById = new Map(
      documents.map((item) => [item.id, item.dataUrl]),
    );
    for (const document of tableResult.documents as StudentDocument[]) {
      const dataUrl = documentDataById.get(document.id);
      if (dataUrl) document.dataUrl = dataUrl;
    }
    const bridgedSettings = tableResult.settings as Setting[];
    const logo = settings.find((item) => item.key === "logo");
    if (logo && !bridgedSettings.some((item) => item.key === "logo"))
      bridgedSettings.push(logo);
    return tableResult;
  }

  return tableResult;
}

export async function parsePremiumSchoolErpZip(
  data: Uint8Array,
): Promise<DesktopZipBackup> {
  let files: ZipEntries;
  try {
    files = unzipSync(data);
  } catch {
    throw new Error(
      "ZIP file could not be opened. Select a Premium School ERP full-backup ZIP.",
    );
  }
  const databaseBytes = files["school_erp.sqlite3"];
  if (!databaseBytes)
    throw new Error("This ZIP is missing school_erp.sqlite3.");
  const manifest = files["manifest.txt"];
  const SQL = await loadSql();
  let database: SqlDatabase;
  try {
    database = new SQL.Database(databaseBytes);
  } catch {
    throw new Error(
      "The ZIP contains an invalid or unsupported school_erp.sqlite3 database.",
    );
  }
  try {
    let migrations: Row[];
    try {
      migrations = rowsFor(database, "schema_migrations");
    } catch {
      throw new Error(
        "This database has no supported SchoolERP migration history.",
      );
    }
    const migrationVersions = migrations
      .map((item) => Number(item.version))
      .filter(Number.isFinite);
    if (!migrationVersions.length)
      throw new Error(
        "This database has no supported SchoolERP migration history.",
      );
    const highest = Math.max(...migrationVersions);
    if (highest > DESKTOP_SCHEMA_VERSION)
      throw new Error(
        "This desktop backup uses a newer database version. Update the mobile app before restoring it.",
      );
    // Query required tables directly; this also catches non-SchoolERP SQLite files.
    for (const required of [
      "students",
      "classes",
      "users",
      "settings",
      "fees",
    ]) {
      try {
        database.exec(`SELECT * FROM ${quoted(required)} LIMIT 0`);
      } catch {
        throw new Error(`Desktop backup is missing the ${required} table.`);
      }
    }
    const setting = rowsFor(database, "settings").find(
      (item) => item.key === BRIDGE_SETTING_KEY,
    );
    const bridge = safeJson(setting?.value) as MobileBridgePayload | undefined;
    let exactMobileRoundTrip = false;
    if (
      bridge &&
      bridge.app === "SchoolFlow" &&
      bridge.version === 1 &&
      typeof bridge.snapshotHash === "string"
    ) {
      try {
        exactMobileRoundTrip =
          bridge.snapshotHash === (await snapshotHash(database));
      } catch {
        exactMobileRoundTrip = false;
      }
    }
    const tables = mapDesktopTablesToMobile(
      database,
      files,
      exactMobileRoundTrip ? bridge : undefined,
    );
    const warnings = exactMobileRoundTrip
      ? []
      : [
          "This ZIP was created by the desktop app (or its database changed after export). Data was mapped into the mobile format; some desktop-only fields may not have a mobile equivalent.",
        ];
    return {
      tables,
      createdAt: parseManifestCreatedAt(manifest),
      source: "premium-desktop-zip",
      exactMobileRoundTrip,
      warnings,
    };
  } finally {
    database.close();
  }
}

export function desktopZipFilename(date = new Date()) {
  return `school_erp_full_backup_${makeLocalStamp(date)}.zip`;
}

export function isDesktopZipFile(file: File) {
  return (
    file.name.toLowerCase().endsWith(".zip") ||
    file.type === "application/zip" ||
    file.type === "application/x-zip-compressed"
  );
}
