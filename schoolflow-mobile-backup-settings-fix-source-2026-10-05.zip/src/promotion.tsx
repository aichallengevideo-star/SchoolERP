import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Check,
  CircleAlert,
  Download,
  Layers3,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { audit, db } from "./db";
import { useAuth, useToast } from "./state";
import {
  Badge,
  Button,
  Card,
  Input,
  Modal,
  PageTitle,
  SearchBox,
  Select,
} from "./ui";
import {
  csvString,
  currentSession,
  displayDate,
  money,
  nextAcademicSession,
  rankRows,
  roundMoney,
  saveFile,
  todayISO,
} from "./lib";
import type { SchoolClass } from "./types";

const useClasses = () => {
  const user = useAuth((state) => state.user);
  const classes =
    useLiveQuery(
      () =>
        db.classes
          .filter(
            (schoolClass) =>
              !schoolClass.deletedAt && schoolClass.status === "Active",
          )
          .sortBy("name"),
      [],
      [],
    ) || [];
  return user?.role === "Teacher"
    ? user.teacherId
      ? classes.filter(
          (schoolClass) => schoolClass.teacherId === user.teacherId,
        )
      : []
    : classes;
};
const useSettings = () =>
  useLiveQuery(
    async () =>
      Object.fromEntries(
        (await db.settings.toArray()).map((entry) => [entry.key, entry.value]),
      ),
    [],
    {} as Record<string, any>,
  ) || {};
const currentUser = () => useAuth.getState().user?.username || "admin";
function TinyEmpty({ title, text }: { title: string; text: string }) {
  return (
    <div className="mini-empty">
      <div className="mini-empty-icon">
        <Layers3 size={17} />
      </div>
      <span>
        <b>{title}</b>
        <small>{text}</small>
      </span>
    </div>
  );
}

export function PromotionPage() {
  const classes = useClasses();
  const settings = useSettings();
  const students =
    useLiveQuery(
      () =>
        db.students
          .filter((s) => !s.deletedAt && s.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const exams = useLiveQuery(() => db.exams.toArray(), [], []) || [];
  const logs =
    useLiveQuery(
      () => db.promotions.orderBy("createdAt").reverse().toArray(),
      [],
      [],
    ) || [];
  const results = useLiveQuery(() => db.examResults.toArray(), [], []) || [];
  const { toast } = useToast();
  const location = useLocation();
  const [sourceKey, setSourceKey] = useState("");
  const [targetId, setTargetId] = useState(0);
  const [newSession, setNewSession] = useState(() =>
    nextAcademicSession(currentSession()),
  );
  const [newSessionEdited, setNewSessionEdited] = useState(false);
  const [mode, setMode] = useState<"normal" | "rank">("normal");
  const [examId, setExamId] = useState(0);
  const [preview, setPreview] = useState(false);
  const [busy, setBusy] = useState(false);
  const [sectionSize, setSectionSize] = useState("40");
  const [passOnly, setPassOnly] = useState(false);
  const [promotionSearch, setPromotionSearch] = useState("");
  const [singleStudentId, setSingleStudentId] = useState(0);
  const [singleTargetId, setSingleTargetId] = useState(0);
  const [singleSession, setSingleSession] = useState(() =>
    nextAcademicSession(currentSession()),
  );
  const [singleSessionEdited, setSingleSessionEdited] = useState(false);
  const [singlePreview, setSinglePreview] = useState(false);
  const [singleBusy, setSingleBusy] = useState(false);
  useEffect(() => {
    const configuredSession = String(settings.academicSession || "");
    if (configuredSession && !newSessionEdited)
      setNewSession(nextAcademicSession(configuredSession));
    if (configuredSession && !singleSessionEdited)
      setSingleSession(nextAcademicSession(configuredSession));
  }, [settings.academicSession, newSessionEdited, singleSessionEdited]);
  useEffect(() => {
    if (!sourceKey && classes[0])
      setSourceKey(
        `${classes[0].id}|${classes[0].section}|${classes[0].session}`,
      );
    if (!targetId && classes.length)
      setTargetId((classes[1] || classes[0]).id!);
  }, [classes, sourceKey, targetId]);
  useEffect(() => {
    const id = Number(new URLSearchParams(location.search).get("student"));
    if (id) setSingleStudentId(id);
  }, [location.search]);
  const [sourceIdStr, fromSection, fromSession] = sourceKey.split("|");
  const sourceId = Number(sourceIdStr);
  const fromClass = classes.find(
    (c) => c.id === sourceId && c.section === fromSection,
  );
  const target = classes.find((c) => c.id === targetId);
  const sourceStudents = students.filter(
    (s) =>
      s.classId === sourceId &&
      s.section === fromSection &&
      s.session === fromSession,
  );
  const exam = exams.find((e) => e.id === examId);
  const rankedSources = rankRows(
    sourceStudents
      .map((student) => {
        const own = results.filter(
          (r) => r.examId === examId && r.studentId === student.id,
        );
        const marks = own.reduce((a, r) => a + r.marks, 0);
        const max = own.reduce((a, r) => a + r.maxMarks, 0);
        const pass = Boolean(
          exam &&
          own.length >= exam.subjects.length &&
          own.every((r) => r.result === "Pass"),
        );
        return {
          student,
          name: student.name,
          marks,
          percentage: max ? roundMoney((marks / max) * 100) : 0,
          pass,
          own,
        };
      })
      .filter((r) => r.own.length > 0),
  );
  const sorted = rankedSources.filter((r) => !passOnly || r.pass);
  const rankDestinations = target
    ? (() => {
        const destinations = new Map<string, SchoolClass>();
        for (const destination of classes.filter(
          (c) => c.name === target.name && c.session === newSession,
        ))
          destinations.set(destination.section, destination);
        for (const template of classes.filter(
          (c) => c.name === target.name && c.session === target.session,
        ))
          if (!destinations.has(template.section))
            destinations.set(template.section, template);
        return [...destinations.values()].sort((a, b) =>
          a.section.localeCompare(b.section),
        );
      })()
    : [];
  const normalDestination = target
    ? classes.find(
        (c) =>
          c.name === target.name &&
          c.section === target.section &&
          c.session === newSession,
      ) || target
    : undefined;
  const selectedDestinations =
    mode === "rank"
      ? rankDestinations
      : normalDestination
        ? [normalDestination]
        : [];
  const splitLimit = Math.max(
    1,
    Number(sectionSize) || sourceStudents.length || 1,
  );
  const existingByDestination = new Map<number, number[]>();
  for (const dest of selectedDestinations) {
    existingByDestination.set(
      dest.id!,
      students
        .filter(
          (s) =>
            s.status === "Active" &&
            s.classId === dest.id &&
            s.section === dest.section &&
            s.session === newSession &&
            !sourceStudents.some((src) => src.id === s.id),
        )
        .map((s) => s.roll),
    );
  }
  const nextRollByDestination = new Map<number, number>();
  for (const dest of selectedDestinations)
    nextRollByDestination.set(
      dest.id!,
      Math.max(0, ...(existingByDestination.get(dest.id!) || [])) + 1,
    );
  const assigned = new Map<number, number>();
  const normalStart = normalDestination
    ? Math.max(
        0,
        ...students
          .filter(
            (s) =>
              s.status === "Active" &&
              s.classId === normalDestination.id &&
              s.section === normalDestination.section &&
              s.session === newSession,
          )
          .map((s) => s.roll),
      ) + 1
    : 1;
  const moveRows =
    mode === "rank" && exam
      ? sorted.map((x, i) => {
          const dest =
            selectedDestinations[
              Math.min(
                Math.floor((x.rank - 1) / splitLimit),
                Math.max(0, selectedDestinations.length - 1),
              )
            ] || target;
          const offset = assigned.get(dest?.id || 0) || 0;
          assigned.set(dest?.id || 0, offset + 1);
          const base = nextRollByDestination.get(dest?.id || 0) || 1;
          return {
            ...x,
            destination: dest,
            newRoll: base + offset,
            rank: x.rank,
          };
        })
      : sourceStudents
          .slice()
          .sort((a, b) => a.roll - b.roll)
          .map((student, index) => ({
            student,
            marks: 0,
            percentage: 0,
            pass: true,
            own: [],
            destination: target,
            newRoll: normalStart + index,
            rank: undefined as number | undefined,
          }));
  const apply = async () => {
    if (
      !fromClass ||
      !target ||
      !sourceStudents.length ||
      !moveRows.length ||
      (mode === "rank" && (!exam || !rankedSources.length))
    ) {
      toast(
        "Choose a source class and a destination with students to promote.",
        "error",
      );
      return;
    }
    if (!newSession.trim() || selectedDestinations.length === 0) {
      toast(
        "Choose a destination class and enter a valid new session.",
        "error",
      );
      return;
    }
    if (sourceId === targetId && fromSession === newSession) {
      toast(
        "The destination must be a different class or academic session.",
        "error",
      );
      return;
    }
    setBusy(true);
    const now = new Date().toISOString();
    try {
      await db.transaction(
        "rw",
        db.classes,
        db.students,
        db.promotions,
        db.studentTimeline,
        async () => {
          const destinationIds = new Map<string, number>();
          for (const destination of selectedDestinations) {
            const key = `${destination.name}|${destination.section}`;
            if (destinationIds.has(key)) continue;
            const existingClass = await db.classes
              .where("[name+section+session]")
              .equals([destination.name, destination.section, newSession])
              .first();
            if (existingClass) {
              if (existingClass.deletedAt || existingClass.status !== "Active")
                throw new Error(
                  `Destination ${destination.name}-${destination.section} is inactive in ${newSession}. Reactivate it in Classes first.`,
                );
              destinationIds.set(key, existingClass.id!);
            } else {
              const classId = await db.classes.add({
                name: destination.name,
                section: destination.section,
                session: newSession,
                room: destination.room,
                teacherId: destination.teacherId,
                status: "Active",
                createdAt: now,
                updatedAt: now,
              });
              destinationIds.set(key, classId);
            }
          }
          for (const r of moveRows) {
            const s = r.student;
            const destination = r.destination || target;
            const destinationId = destinationIds.get(
              `${destination.name}|${destination.section}`,
            );
            if (!destinationId)
              throw new Error("A destination class could not be prepared.");
            const existing = await db.students
              .where("[classId+section+session]")
              .equals([destinationId, destination.section, newSession])
              .filter(
                (x) =>
                  !x.deletedAt &&
                  x.status === "Active" &&
                  x.roll === r.newRoll &&
                  x.id !== s.id,
              )
              .first();
            if (existing)
              throw new Error(
                `Roll ${r.newRoll} is already in use in the destination class.`,
              );
          }
          for (const r of moveRows) {
            const s = r.student;
            const destination = r.destination || target;
            const destinationId = destinationIds.get(
              `${destination.name}|${destination.section}`,
            )!;
            await db.promotions.add({
              studentId: s.id!,
              fromClass: `${fromClass.name}-${fromSection}`,
              toClass: `${destination.name}-${destination.section}`,
              fromSession,
              toSession: newSession,
              oldRoll: s.roll,
              newRoll: r.newRoll,
              type: mode,
              rankUsed: r.rank,
              remarks:
                mode === "rank"
                  ? r.pass
                    ? "Pass"
                    : "Fail / incomplete"
                  : undefined,
              username: currentUser(),
              createdAt: now,
            });
            await db.students.update(s.id!, {
              classId: destinationId,
              section: destination.section,
              session: newSession,
              roll: r.newRoll,
              updatedAt: now,
            });
            await db.studentTimeline.add({
              studentId: s.id!,
              eventType: "promotion",
              title: "Student promoted",
              details: `${fromClass.name}-${fromSection} → ${destination.name}-${destination.section} · ${fromSession} → ${newSession} · Roll ${s.roll} → ${r.newRoll}`,
              username: currentUser(),
              createdAt: now,
            });
          }
        },
      );
      await audit(
        currentUser(),
        "Applied class promotion",
        "Promotion",
        now,
        `${moveRows.length} students · ${mode}`,
      );
      toast(`${moveRows.length} students promoted. Promotion log is ready.`);
      setPreview(false);
    } catch (e) {
      toast(
        e instanceof Error
          ? e.message
          : "Promotion could not be applied. No changes were made.",
        "error",
      );
    } finally {
      setBusy(false);
    }
  };
  const visibleLogs = logs.filter((l) => {
    const student = students.find((x) => x.id === l.studentId);
    return [
      student?.name || "",
      student?.admissionNo || "",
      l.fromClass,
      l.toClass,
      l.fromSession,
      l.toSession,
    ].some((x) => x.toLowerCase().includes(promotionSearch.toLowerCase()));
  });
  const exportLogs = () =>
    saveFile(
      new Blob(
        [
          csvString(
            visibleLogs.map((l) => ({
              student: students.find((x) => x.id === l.studentId)?.name,
              from_class: l.fromClass,
              to_class: l.toClass,
              from_session: l.fromSession,
              to_session: l.toSession,
              old_roll: l.oldRoll,
              new_roll: l.newRoll,
              type: l.type,
              rank: l.rankUsed,
              date: l.createdAt,
              user: l.username,
            })),
          ),
        ],
        { type: "text/csv" },
      ),
      `promotion-log-${todayISO()}.csv`,
    );
  const [singleStudent, singleTarget] = [
    students.find((s) => s.id === singleStudentId),
    classes.find((c) => c.id === singleTargetId),
  ];
  const confirmSingle = async () => {
    if (!singleStudent || !singleTarget || !singleSession.trim()) {
      toast("Choose a student, destination class and new session.", "error");
      return;
    }
    const sourceClass = classes.find(
      (c) =>
        c.id === singleStudent.classId &&
        c.section === singleStudent.section &&
        c.session === singleStudent.session,
    );
    if (
      sourceClass?.name === singleTarget.name &&
      sourceClass.section === singleTarget.section &&
      singleStudent.session === singleSession
    ) {
      toast(
        "The destination must be a different class or academic session.",
        "error",
      );
      return;
    }
    setSingleBusy(true);
    const now = new Date().toISOString();
    try {
      let destinationId = 0;
      let newRoll = 1;
      await db.transaction(
        "rw",
        db.classes,
        db.students,
        db.promotions,
        db.studentTimeline,
        async () => {
          const existingClass = await db.classes
            .where("[name+section+session]")
            .equals([singleTarget.name, singleTarget.section, singleSession])
            .first();
          if (existingClass) {
            if (existingClass.deletedAt || existingClass.status !== "Active")
              throw new Error(
                `Destination ${singleTarget.name}-${singleTarget.section} is inactive in ${singleSession}. Reactivate it in Classes first.`,
              );
            destinationId = existingClass.id!;
          } else {
            destinationId = await db.classes.add({
              name: singleTarget.name,
              section: singleTarget.section,
              session: singleSession,
              room: singleTarget.room,
              teacherId: singleTarget.teacherId,
              status: "Active",
              createdAt: now,
              updatedAt: now,
            });
          }
          const destinationStudents = await db.students
            .where("[classId+section+session]")
            .equals([destinationId, singleTarget.section, singleSession])
            .toArray();
          const rolls = destinationStudents
            .filter(
              (student) =>
                !student.deletedAt &&
                student.status === "Active" &&
                student.id !== singleStudent.id,
            )
            .map((student) => student.roll);
          newRoll = Math.max(0, ...rolls) + 1;
          if (
            destinationStudents.some(
              (student) =>
                !student.deletedAt &&
                student.status === "Active" &&
                student.id !== singleStudent.id &&
                student.roll === newRoll,
            )
          )
            throw new Error(
              `Roll ${newRoll} is already in use in the destination class.`,
            );
          await db.promotions.add({
            studentId: singleStudent.id!,
            fromClass: `${sourceClass?.name || singleStudent.classId}-${singleStudent.section}`,
            toClass: `${singleTarget.name}-${singleTarget.section}`,
            fromSession: singleStudent.session,
            toSession: singleSession,
            oldRoll: singleStudent.roll,
            newRoll,
            type: "single",
            username: currentUser(),
            createdAt: now,
          });
          await db.students.update(singleStudent.id!, {
            classId: destinationId,
            section: singleTarget.section,
            session: singleSession,
            roll: newRoll,
            updatedAt: now,
          });
          await db.studentTimeline.add({
            studentId: singleStudent.id!,
            eventType: "promotion",
            title: "Single student promoted",
            details: `${singleTarget.name}-${singleTarget.section} · ${singleStudent.session} → ${singleSession} · Roll ${singleStudent.roll} → ${newRoll}`,
            username: currentUser(),
            createdAt: now,
          });
        },
      );
      await audit(
        currentUser(),
        "Promoted one student",
        "Promotion",
        singleStudent.id,
        `${singleStudent.name} → ${singleTarget.name}-${singleTarget.section} · ${singleSession}`,
      );
      toast(
        `${singleStudent.name} promoted to ${singleTarget.name}-${singleTarget.section} · ${singleSession} · roll ${newRoll}.`,
      );
      setSinglePreview(false);
    } catch (error) {
      toast(
        error instanceof Error
          ? error.message
          : "The student could not be promoted. No changes were made.",
        "error",
      );
    } finally {
      setSingleBusy(false);
    }
  };
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="ACADEMIC YEAR CHANGEOVER"
        title="Student promotion"
        subtitle="Plan the move first. Review every student and roll number before committing."
      />
      <div className="promotion-banner">
        <span className="promotion-icon">
          <Sparkles size={18} />
        </span>
        <span>
          <b>Promotion is an all-or-nothing action.</b>
          <small>
            Every student move is logged. The preview below is the last chance
            to check the class and roll sequence.
          </small>
        </span>
      </div>
      <div className="promotion-layout">
        <Card className="promotion-config">
          <div className="card-head">
            <div>
              <span className="card-eyebrow">PROMOTION PLAN</span>
              <h3>Choose your move</h3>
            </div>
            <span className="step-number">01</span>
          </div>
          <label className="field">
            <span className="field-label">Promotion type</span>
            <div className="segmented-control">
              <button
                type="button"
                className={mode === "normal" ? "active" : ""}
                onClick={() => setMode("normal")}
              >
                Normal promotion
              </button>
              <button
                type="button"
                className={mode === "rank" ? "active" : ""}
                onClick={() => setMode("rank")}
              >
                Rank-based order
              </button>
            </div>
          </label>
          <Select
            label="From class"
            value={sourceKey}
            onChange={(e) => setSourceKey(e.target.value)}
          >
            <option value="">Select source class</option>
            {classes.map((c) => (
              <option
                key={`${c.id}|${c.section}|${c.session}`}
                value={`${c.id}|${c.section}|${c.session}`}
              >
                {c.name} · {c.section} · {c.session}
              </option>
            ))}
          </Select>
          <div className="promotion-arrow">
            <span>{sourceStudents.length} students in source</span>
            <ArrowDownRight size={17} />
          </div>
          <Select
            label="To class"
            value={targetId || ""}
            onChange={(e) => setTargetId(Number(e.target.value))}
          >
            <option value="">Select destination class</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} · {c.section}
              </option>
            ))}
          </Select>
          <Input
            label="New academic session"
            value={newSession}
            onChange={(e) => {
              setNewSession(e.target.value);
              setNewSessionEdited(true);
            }}
            placeholder="e.g. 2027-28"
          />
          <div className="form-helper">
            Missing destination class sections are created automatically when
            promotion is confirmed.
          </div>
          {mode === "rank" && (
            <Select
              label="Rank students by exam"
              value={examId || ""}
              onChange={(e) => setExamId(Number(e.target.value))}
            >
              <option value="">Select exam</option>
              {exams
                .filter(
                  (e) =>
                    e.classId === sourceId &&
                    e.section === fromSection &&
                    e.session === fromSession,
                )
                .map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} · {displayDate(e.date)}
                  </option>
                ))}
            </Select>
          )}
          {mode === "rank" && (
            <>
              <Input
                label="Students per section"
                type="number"
                min="1"
                value={sectionSize}
                onChange={(e) => setSectionSize(e.target.value)}
                hint="Example: 40 assigns ranks 1–40 to section A, 41–80 to B."
              />
              <label className="toggle-row">
                <input
                  type="checkbox"
                  checked={passOnly}
                  onChange={(e) => setPassOnly(e.target.checked)}
                />
                <span>
                  <b>Promote pass students only</b>
                  <small>
                    Students who failed or have incomplete marks will be
                    excluded from this rank-based preview.
                  </small>
                </span>
              </label>
              <div className="form-helper">
                Matching destination sections:{" "}
                {rankDestinations.map((c) => c.section).join(", ") ||
                  "none yet — create sections for the new session"}
              </div>
            </>
          )}
          <div className="promotion-safety">
            <ShieldCheck size={16} />
            <span>
              Student fee, attendance and exam history remains linked to the
              student.
            </span>
          </div>
          <Button
            size="lg"
            className="full-width"
            onClick={() => setPreview(true)}
            disabled={
              !sourceStudents.length ||
              !targetId ||
              !newSession.trim() ||
              (mode === "rank" &&
                (!rankDestinations.length ||
                  !exam ||
                  !rankedSources.length ||
                  !sorted.length))
            }
          >
            Review promotion <ArrowRight size={16} />
          </Button>
        </Card>
        <Card className="promotion-history">
          <div className="card-head">
            <div>
              <span className="card-eyebrow">RECENT PROMOTIONS</span>
              <h3>Promotion log</h3>
            </div>
            <div className="table-actions">
              <span className="history-count">{logs.length}</span>
              <Button size="sm" variant="secondary" onClick={exportLogs}>
                <Download size={14} /> Export log
              </Button>
            </div>
          </div>
          <SearchBox
            value={promotionSearch}
            onChange={setPromotionSearch}
            placeholder="Filter promotion log…"
          />
          {visibleLogs.length ? (
            <div className="promotion-log-list">
              {visibleLogs.slice(0, 30).map((l) => {
                const s = students.find((x) => x.id === l.studentId);
                return (
                  <div key={l.id}>
                    <span className="promotion-log-icon">
                      <ArrowUpRight size={15} />
                    </span>
                    <span>
                      <b>{s?.name || "Student"}</b>
                      <small>
                        {l.fromClass} → {l.toClass} · {l.fromSession} to{" "}
                        {l.toSession}
                      </small>
                    </span>
                    <Badge tone="violet">#{l.newRoll}</Badge>
                  </div>
                );
              })}
            </div>
          ) : (
            <TinyEmpty
              title="No promotion logs"
              text="Completed promotions will be recorded here."
            />
          )}
          <Link to="/reports" className="overview-footer">
            Export full promotion log <ArrowRight size={14} />
          </Link>
        </Card>
      </div>
      <Card className="promotion-config">
        <div className="card-head">
          <div>
            <span className="card-eyebrow">INDIVIDUAL MOVE</span>
            <h3>Promote one student</h3>
          </div>
          <span className="step-number">↗</span>
        </div>
        <div className="form-grid">
          <Select
            label="Student"
            value={singleStudentId || ""}
            onChange={(e) => setSingleStudentId(Number(e.target.value))}
          >
            <option value="">Select student</option>
            {students.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} · {s.admissionNo} · {s.session}
              </option>
            ))}
          </Select>
          <Select
            label="Destination class"
            value={singleTargetId || ""}
            onChange={(e) => setSingleTargetId(Number(e.target.value))}
          >
            <option value="">Select class</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} · {c.section} · {c.session}
              </option>
            ))}
          </Select>
          <Input
            label="New academic session"
            value={singleSession}
            onChange={(e) => {
              setSingleSession(e.target.value);
              setSingleSessionEdited(true);
            }}
          />
          <div className="form-helper full-span">
            If this class section does not exist for the new session, it is
            created automatically after confirmation.
          </div>
          <Button
            onClick={() => setSinglePreview(true)}
            disabled={
              !singleStudentId || !singleTargetId || !singleSession.trim()
            }
          >
            Review individual promotion
          </Button>
        </div>
      </Card>
      <Modal
        open={singlePreview}
        onClose={() => setSinglePreview(false)}
        title="Confirm individual promotion"
        subtitle={
          singleStudent && singleTarget
            ? `${singleStudent.name} → ${singleTarget.name}-${singleTarget.section} · ${singleSession}`
            : ""
        }
      >
        {singleStudent && singleTarget && (
          <>
            <div className="restore-warning">
              <CircleAlert size={16} />
              <span>
                The student's class, session and roll number will change and a
                permanent promotion log will be written.
              </span>
            </div>
            <div className="modal-actions">
              <Button
                variant="secondary"
                onClick={() => setSinglePreview(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={() => void confirmSingle()}
                disabled={singleBusy}
              >
                {singleBusy ? "Promoting…" : "Confirm promotion"}
              </Button>
            </div>
          </>
        )}
      </Modal>
      <Modal
        open={preview}
        onClose={() => setPreview(false)}
        title="Review promotion"
        subtitle={`${moveRows.length} student records · No changes yet.`}
        size="lg"
      >
        <div className="promotion-preview-note">
          <CircleAlert size={16} />
          <span>
            Check the new class, session and roll numbers. Confirming updates
            every row in one transaction.
          </span>
        </div>
        <div className="promotion-preview-head">
          <span>STUDENT</span>
          <span>OLD ROLL</span>
          <span>TO SECTION</span>
          <span>NEW ROLL</span>
        </div>
        <div className="promotion-preview-list">
          {moveRows.map((r, i) => (
            <div key={r.student.id}>
              <span>
                <b>{r.student.name}</b>
                <small>
                  {r.student.admissionNo}
                  {mode === "rank" && exam
                    ? ` · ${r.percentage.toFixed(1)}% rank ${r.rank ?? i + 1}`
                    : ""}
                </small>
              </span>
              <span>{r.student.roll || "—"}</span>
              <span>
                {r.destination?.name}-{r.destination?.section}
              </span>
              <span>
                <Badge tone="green">{r.newRoll}</Badge>
              </span>
            </div>
          ))}
        </div>
        <div className="promotion-confirm-meta">
          <span>
            {fromClass?.name}-{fromSection} → {target?.name} ·{" "}
            {mode === "rank"
              ? `${rankDestinations.length} rank-distribution sections`
              : target?.section}
          </span>
          <b>Session {newSession}</b>
        </div>
        <div className="modal-actions">
          <Button variant="secondary" onClick={() => setPreview(false)}>
            Go back
          </Button>
          <Button onClick={() => void apply()} disabled={busy}>
            {busy ? "Applying…" : "Confirm promotion"}
            <Check size={16} />
          </Button>
        </div>
      </Modal>
    </div>
  );
}
