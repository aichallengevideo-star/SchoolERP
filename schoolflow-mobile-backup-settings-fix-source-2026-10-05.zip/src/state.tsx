import { create } from "zustand";
import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { db } from "./db";
import { hashDesktopPassword, hashPassword, verifyStoredPassword } from "./lib";
import type { AppUser } from "./types";

export interface SessionUser {
  id: number;
  username: string;
  fullName: string;
  role: AppUser["role"];
  teacherId?: number;
}
interface AuthState {
  user: SessionUser | null;
  setUser: (user: SessionUser | null) => void;
}
export const useAuth = create<AuthState>((set) => ({
  user: null,
  setUser: (user) => set({ user }),
}));

export async function loginLocal(
  username: string,
  password: string,
  remember = true,
) {
  const user = await db.users
    .where("username")
    .equals(username.trim().toLowerCase())
    .first();
  if (!user || user.status !== "Active")
    return {
      ok: false as const,
      message: "Username ya password match nahi hua.",
    };
  if (!(await verifyStoredPassword(password, user)))
    return {
      ok: false as const,
      message: "Username ya password match nahi hua.",
    };
  const passwordUpdate: Partial<AppUser> = {};
  if (
    user.passwordAlgorithm === "bcrypt" ||
    !user.salt ||
    /^\$2[aby]\$/.test(user.passwordHash)
  ) {
    const salt = crypto.randomUUID();
    passwordUpdate.salt = salt;
    passwordUpdate.passwordHash = await hashPassword(password, salt);
    passwordUpdate.passwordAlgorithm = "sha256";
    passwordUpdate.desktopPasswordHash =
      user.desktopPasswordHash || user.passwordHash;
  } else if (!user.desktopPasswordHash) {
    passwordUpdate.desktopPasswordHash = await hashDesktopPassword(password);
  }
  await db.users.update(user.id!, {
    ...passwordUpdate,
    lastLoginAt: new Date().toISOString(),
  });
  const session: SessionUser = {
    id: user.id!,
    username: user.username,
    fullName: user.fullName,
    role: user.role,
    teacherId: user.teacherId,
  };
  const serialized = JSON.stringify(session);
  try {
    localStorage.setItem("schoolflow-last-username", user.username);
  } catch {
    // Keep login available when browser storage is restricted.
  }
  const now = String(Date.now());
  if (remember) {
    localStorage.setItem("schoolflow-session", serialized);
    localStorage.setItem("schoolflow-last-activity", now);
    sessionStorage.removeItem("schoolflow-session");
    sessionStorage.removeItem("schoolflow-last-activity");
  } else {
    sessionStorage.setItem("schoolflow-session", serialized);
    sessionStorage.setItem("schoolflow-last-activity", now);
    localStorage.removeItem("schoolflow-session");
    localStorage.removeItem("schoolflow-last-activity");
  }
  useAuth.getState().setUser(session);
  return { ok: true as const, mustChange: Boolean(user.mustChange) };
}

export async function changePasswordLocal(
  userId: number,
  currentPassword: string,
  newPassword: string,
) {
  const user = await db.users.get(userId);
  if (!user) throw new Error("User account nahi mila.");
  if (!(await verifyStoredPassword(currentPassword, user)))
    throw new Error("Current password sahi nahi hai.");
  const salt = crypto.randomUUID();
  await db.users.update(userId, {
    salt,
    passwordHash: await hashPassword(newPassword, salt),
    passwordAlgorithm: "sha256",
    desktopPasswordHash: await hashDesktopPassword(newPassword),
    mustChange: false,
  });
}

interface Toast {
  id: number;
  message: string;
  kind: "success" | "error" | "info";
}
interface ToastApi {
  toast: (message: string, kind?: Toast["kind"]) => void;
}
const ToastContext = createContext<ToastApi>({ toast: () => undefined });
export const useToast = () => useContext(ToastContext);
export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const api = useMemo<ToastApi>(
    () => ({
      toast: (message, kind = "success") => {
        const id = Date.now() + Math.random();
        setToasts((items) => [...items, { id, message, kind }]);
        setTimeout(
          () => setToasts((items) => items.filter((t) => t.id !== id)),
          3400,
        );
      },
    }),
    [],
  );
  useEffect(() => {
    const onAppToast = (event: Event) => {
      const detail = (
        event as CustomEvent<{
          message?: string;
          kind?: Toast["kind"];
        }>
      ).detail;
      if (detail?.message) api.toast(detail.message, detail.kind);
    };
    window.addEventListener("schoolflow:toast", onAppToast);
    return () => window.removeEventListener("schoolflow:toast", onAppToast);
  }, [api]);
  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="toast-stack" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.kind}`}>
            <span className="toast-dot" />
            {t.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
