export const SCHOOLFLOW_BACKUP_APP = "SchoolFlow" as const;
export const SCHOOLFLOW_BACKUP_FORMAT = "schoolerp-portable" as const;
export const SCHOOLFLOW_BACKUP_VERSION = 1 as const;

export interface SchoolFlowBackup {
  app: typeof SCHOOLFLOW_BACKUP_APP;
  format: typeof SCHOOLFLOW_BACKUP_FORMAT;
  version: typeof SCHOOLFLOW_BACKUP_VERSION;
  createdAt: string;
  tables: Record<string, unknown[]>;
}

export function createSchoolFlowBackup(
  tables: Record<string, unknown[]>,
  createdAt = new Date().toISOString(),
): SchoolFlowBackup {
  return {
    app: SCHOOLFLOW_BACKUP_APP,
    format: SCHOOLFLOW_BACKUP_FORMAT,
    version: SCHOOLFLOW_BACKUP_VERSION,
    createdAt,
    tables,
  };
}

export function parseSchoolFlowBackup(value: unknown): SchoolFlowBackup {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw new Error("Backup file is not a valid SchoolERP file.");

  const raw = value as Record<string, unknown>;
  if (raw.app !== SCHOOLFLOW_BACKUP_APP)
    throw new Error("This file is not a SchoolFlow backup.");
  if (raw.format !== undefined && raw.format !== SCHOOLFLOW_BACKUP_FORMAT)
    throw new Error("This backup uses an unsupported SchoolERP format.");
  const version = Number(raw.version ?? SCHOOLFLOW_BACKUP_VERSION);
  if (version !== SCHOOLFLOW_BACKUP_VERSION)
    throw new Error(
      version > SCHOOLFLOW_BACKUP_VERSION
        ? "This backup was created by a newer app version. Update SchoolERP on this device first."
        : "This backup version is not supported.",
    );
  if (
    !raw.tables ||
    typeof raw.tables !== "object" ||
    Array.isArray(raw.tables)
  )
    throw new Error("Backup is missing its school data tables.");

  const tables = raw.tables as Record<string, unknown>;
  for (const required of ["students", "users", "settings"]) {
    if (!Array.isArray(tables[required]))
      throw new Error(
        `Backup is incomplete: the ${required} table is missing.`,
      );
  }

  const rows = Object.fromEntries(
    Object.entries(tables).filter(([, value]) => Array.isArray(value)),
  ) as Record<string, unknown[]>;
  return {
    app: SCHOOLFLOW_BACKUP_APP,
    format: SCHOOLFLOW_BACKUP_FORMAT,
    version: SCHOOLFLOW_BACKUP_VERSION,
    createdAt: String(raw.createdAt || ""),
    tables: rows,
  };
}
