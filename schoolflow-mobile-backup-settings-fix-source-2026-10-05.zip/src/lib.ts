import { Capacitor } from "@capacitor/core";
import { Directory, Filesystem } from "@capacitor/filesystem";
import { Share } from "@capacitor/share";

export const money = (value: number | string | null | undefined) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Number(value || 0));
export const numberIN = (value: number | string | null | undefined) =>
  new Intl.NumberFormat("en-IN").format(Number(value || 0));
export const setupRedirectPath = (
  pathname: string,
  setupComplete: boolean | undefined,
): "/home" | "/setup" | undefined => {
  if (setupComplete === undefined || pathname === "/change-password")
    return undefined;
  if (setupComplete) return pathname === "/setup" ? "/home" : undefined;
  return pathname === "/setup" ? undefined : "/setup";
};
export const todayISO = () => {
  const d = new Date();
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
};
export const monthISO = (date = new Date()) => {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 7);
};
export const displayDate = (date?: string) =>
  date
    ? new Intl.DateTimeFormat("en-IN", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
      }).format(new Date(`${date.slice(0, 10)}T00:00:00`))
    : "—";
export const displayMonth = (month: string) => {
  const [y, m] = month.split("-").map(Number);
  return new Intl.DateTimeFormat("en-IN", {
    month: "long",
    year: "numeric",
  }).format(new Date(y, m - 1, 1));
};
export const normalizeAdmission = (value: string) =>
  value
    .trim()
    .toUpperCase()
    .replace(/[\s/\-]/g, "");
export const validMobile = (value: string) => /^[6-9]\d{9}$/.test(value.trim());
export const normalizeIndiaPhone = (value: string) => {
  const digits = value.replace(/\D/g, "");
  if (digits.length === 10) return `91${digits}`;
  if (digits.length === 11 && digits.startsWith("0"))
    return `91${digits.slice(1)}`;
  if (digits.length === 12 && digits.startsWith("91")) return digits;
  return digits;
};
export const validIndiaPhone = (value: string) =>
  /^91[6-9]\d{9}$/.test(normalizeIndiaPhone(value));
export const validAadhaar = (value: string) =>
  /^\d{12}$/.test(value.replace(/\s/g, ""));
export const maskAadhaar = (value?: string) =>
  value ? `XXXX XXXX ${value.replace(/\s/g, "").slice(-4)}` : "—";
export const validPastOrToday = (date: string) => !date || date <= todayISO();
export const gradeFor = (percentage: number) =>
  percentage >= 91
    ? "A1"
    : percentage >= 81
      ? "A2"
      : percentage >= 71
        ? "B1"
        : percentage >= 61
          ? "B2"
          : percentage >= 51
            ? "C1"
            : percentage >= 41
              ? "C2"
              : percentage >= 33
                ? "D"
                : "E";
export const rankRows = <
  T extends { percentage: number; marks: number; name: string },
>(
  rows: T[],
) => {
  const sorted = [...rows].sort(
    (a, b) =>
      b.percentage - a.percentage ||
      b.marks - a.marks ||
      a.name.localeCompare(b.name),
  );
  let rank = 0;
  let previous: string | undefined;
  return sorted.map((row, index) => {
    const key = row.percentage.toFixed(2);
    if (key !== previous) {
      rank = index + 1;
      previous = key;
    }
    return { ...row, rank };
  });
};
export const roundMoney = (n: number) =>
  Math.round((Number(n) + Number.EPSILON) * 100) / 100;
export const initials = (name: string) =>
  name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((s) => s[0] || "")
    .join("")
    .toUpperCase();
export const currentSession = () =>
  `${new Date().getFullYear()}-${String(new Date().getFullYear() + 1).slice(-2)}`;
export const nextAcademicSession = (session: string) => {
  const startYear = Number(session.trim().slice(0, 4));
  if (!/^\d{4}-\d{2}$/.test(session.trim()) || !Number.isFinite(startYear)) {
    const currentYear = new Date().getFullYear();
    return `${currentYear + 1}-${String(currentYear + 2).slice(-2)}`;
  }
  const nextStart = startYear + 1;
  return `${nextStart}-${String(nextStart + 1).slice(-2)}`;
};
export const hashPassword = async (password: string, salt: string) => {
  const data = new TextEncoder().encode(`${salt}:${password}`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map((x) => x.toString(16).padStart(2, "0"))
    .join("");
};

export const hashDesktopPassword = async (password: string) => {
  const bcrypt = await import("bcryptjs");
  return bcrypt.hash(password, 12);
};

export async function verifyStoredPassword(
  password: string,
  user: {
    passwordHash: string;
    salt?: string;
    passwordAlgorithm?: "sha256" | "bcrypt";
  },
) {
  if (
    user.passwordAlgorithm === "bcrypt" ||
    /^\$2[aby]\$/.test(user.passwordHash)
  ) {
    try {
      const bcrypt = await import("bcryptjs");
      return await bcrypt.compare(password, user.passwordHash);
    } catch {
      return false;
    }
  }
  if (!user.salt) return false;
  return (await hashPassword(password, user.salt)) === user.passwordHash;
}
export const csvString = (rows: Record<string, unknown>[]) => {
  if (!rows.length) return "";
  const headers = Object.keys(rows[0]);
  const quote = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [
    headers.map(quote).join(","),
    ...rows.map((r) => headers.map((k) => quote(r[k])).join(",")),
  ].join("\r\n");
};
const blobToBase64 = (blob: Blob) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () =>
      reject(reader.error || new Error("File read failed"));
    reader.onload = () => {
      const value = String(reader.result || "");
      const comma = value.indexOf(",");
      resolve(comma >= 0 ? value.slice(comma + 1) : value);
    };
    reader.readAsDataURL(blob);
  });

const announceFileAction = (
  message: string,
  kind: "success" | "error" | "info" = "info",
) => {
  if (typeof window !== "undefined")
    window.dispatchEvent(
      new CustomEvent("schoolflow:toast", { detail: { message, kind } }),
    );
};

const browserDownload = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.rel = "noopener";
  link.style.position = "fixed";
  link.style.left = "-10000px";
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
};

export const saveFile = async (
  blob: Blob,
  filename: string,
): Promise<boolean> => {
  const safeFilename = filename.replace(/[\\/:*?\"<>|\u0000-\u001f]/g, "_");
  const isNative = Capacitor.isNativePlatform();
  try {
    if (isNative) {
      const file = await Filesystem.writeFile({
        path: `schoolflow-exports/${safeFilename}`,
        data: await blobToBase64(blob),
        directory: Directory.Cache,
        recursive: true,
      });
      await Share.share({
        title: safeFilename,
        text: "SchoolERP export",
        files: [file.uri],
        dialogTitle: "Save or share this file",
      });
      return true;
    }
    browserDownload(blob, safeFilename);
    return true;
  } catch (error) {
    console.error("SchoolERP file export failed", error);
    announceFileAction(
      "File could not be exported. Please try again or use the system share option.",
      "error",
    );
    if (!isNative) {
      try {
        browserDownload(blob, safeFilename);
        return true;
      } catch (fallbackError) {
        console.error("Browser download fallback failed", fallbackError);
      }
    }
    return false;
  }
};
export const amountToWords = (amount: number) => {
  const rounded = Math.round(amount);
  if (!rounded) return "Zero rupees only";
  const ones = [
    "",
    "One",
    "Two",
    "Three",
    "Four",
    "Five",
    "Six",
    "Seven",
    "Eight",
    "Nine",
    "Ten",
    "Eleven",
    "Twelve",
    "Thirteen",
    "Fourteen",
    "Fifteen",
    "Sixteen",
    "Seventeen",
    "Eighteen",
    "Nineteen",
  ];
  const tens = [
    "",
    "",
    "Twenty",
    "Thirty",
    "Forty",
    "Fifty",
    "Sixty",
    "Seventy",
    "Eighty",
    "Ninety",
  ];
  const belowThousand = (n: number): string => {
    let out = "";
    if (n >= 100) {
      out += `${ones[Math.floor(n / 100)]} Hundred `;
      n %= 100;
    }
    if (n >= 20) {
      out += `${tens[Math.floor(n / 10)]} `;
      n %= 10;
    }
    if (n > 0) out += `${ones[n]} `;
    return out.trim();
  };
  let n = rounded;
  const parts: string[] = [];
  for (const [base, label] of [
    [10000000, "Crore"],
    [100000, "Lakh"],
    [1000, "Thousand"],
    [1, ""],
  ] as [number, string][]) {
    const units = Math.floor(n / base);
    n %= base;
    if (units)
      parts.push(`${belowThousand(units)}${label ? ` ${label}` : ""}`.trim());
  }
  return `${parts.join(" ")} rupees only`;
};
export async function resizeImage(
  file: File,
  max = 800,
  preserveTransparency = false,
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Photo read nahi ho payi"));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () =>
        reject(new Error("Photo format supported nahi hai"));
      image.onload = () => {
        const scale = Math.min(1, max / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(image.width * scale);
        canvas.height = Math.round(image.height * scale);
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Photo resize nahi ho payi"));
        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(
          preserveTransparency
            ? canvas.toDataURL("image/png")
            : canvas.toDataURL("image/jpeg", 0.75),
        );
      };
      image.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}
