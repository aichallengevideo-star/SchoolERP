# GitHub Actions se SchoolERP APK build karna

## Is workflow me kya hoga

Repo me app source `workspace-*.zip` me rakha jata hai. Updated ZIP me Capacitor 8, Android print, Filesystem/Share plugins, source code aur lockfile included hain. Updated workflow ZIP ko runner par unpack karega, Android project configure/sync karega, tests/build chalakar debug APK artifact upload karega. Android SDK, `node_modules` ya `dist` repo me upload karne ki zaroorat nahi.

Workflow: [`GITHUB_ANDROID_APK_WORKFLOW.yml`](GITHUB_ANDROID_APK_WORKFLOW.yml)

## GitHub par kaun-si files honi chahiye

Abhi ke repo structure ke hisaab se:

- `README.md` — rakh sakte hain.
- `workspace-*.zip` — is updated ZIP me app source, `package.json`/lockfile, Capacitor 8 native plugins, logos, tests aur Vite config hain. Purana ZIP delete/replace karein; repo root par **sirf ek** `workspace-*.zip` ho.
- `.github/workflows/build-android-apk.yml` — updated workflow. Is file ka content upar diye `GITHUB_ANDROID_APK_WORKFLOW.yml` se copy karke purane workflow ko replace karein.

`node_modules/`, `dist/`, Android SDK folders, passwords, signing keys ya asli school/student data upload **na** karein. ZIP ka naam `workspace-...zip` format me rakhein; workflow isi pattern se use dhoondhta hai.

## Step by step

1. GitHub repository kholein: `aichallengevideo-star/SchoolERP`.
2. Repo root par purana `workspace-*.zip` delete karke updated `workspace-2026-10-04-mobile-fixes.zip` upload karein. **Sirf ek** matching ZIP rehna chahiye.
3. `.github/workflows/build-android-apk.yml` kholein → pencil/**Edit** → purana content replace karke is guide ke saath wali `GITHUB_ANDROID_APK_WORKFLOW.yml` ka poora content paste karein.
4. ZIP aur workflow changes ko default branch (`main` ya `master`) par commit karein.
5. **Actions → Build SchoolERP Android APK → Run workflow** kholein, branch choose karke **Run workflow** tap karein.
6. Workflow Node.js 22, Java 21, Android SDK `platforms;android-36` aur `build-tools;36.0.0` install karega. Updated ZIP ke lockfile se `npm ci` Capacitor core/Android/CLI aur native printer/filesystem/share plugins install karega; workflow Capacitor configure karke tests/build chalata, plugins Android me sync karta, phir Gradle se APK banata hai. Capacitor 8 setup Node 22+ maangta hai. [1](https://capacitorjs.com/docs/getting-started/environment-setup)
7. Green check aane par run kholein → **Artifacts → `schoolerp-debug-apk`** download karein → ZIP extract karke `app-debug.apk` phone me bhejein.
8. Android me APK kholein. Agar prompt aaye to Files/Chrome ke liye **Install unknown apps** temporary allow karein; install ke baad permission band kar dein.

## Pehle failed runs ka status

- Shuruaati `Set up Android SDK tools` failure ka fix verified hua: baad wali screenshot me SDK step green tha. Updated workflow action versions:
  - `actions/checkout@v7.0.1`
  - `actions/setup-node@v7.0.0`
  - `actions/setup-java@v6.0.1`
  - `android-actions/setup-android@v4.0.4`
  - `actions/upload-artifact@v7.0.1`
  - `runs-on: ubuntu-24.04`
- `edgesOut` error purane temporary `npm install --no-save --package-lock=false` step par aaya tha. Uske baad aapne confirm kiya ki APK build pass hua aur artifact download ho gaya.
- **Naye mobile/print/export fixes ke liye purana APK kaafi nahi hai.** Updated source ZIP aur updated workflow dono GitHub par commit karke fresh Actions run karein. Ab Capacitor/plugins lockfile me pinned hain; `npm ci` unhe install karta hai, aur failing post-`npm ci` npm install step hata diya gaya hai.
- Setup routing fix: app IndexedDB se `setupComplete` load hone tak wait karega (loading ko galti se `false` nahi maanega); saved setup complete ho to `/setup` se `/home` par redirect hoga. Isliye setup sirf incomplete/new school par dikhega.
- Local verification: 38 tests pass, `npm run build` pass, aur Node 22 par Capacitor Android project + printer/filesystem/share plugin sync pass. Android Gradle ka final APK GitHub Actions par fresh run me verify hoga.
- Mobile backup ab desktop sample ke `school_erp.sqlite3` + photos/logos + manifest ZIP layout ko export/import karta hai. Sample archive parser test pass hai; installed desktop app ke Restore button par real end-to-end test abhi zaroori hai.

## Zaroori notes

- Yeh workflow **debug APK** banata hai, jo phone par test/install ke liye hai. Iske liye release keystore secret nahi chahiye. Yeh Play Store release ke liye ready signed production package nahi hai.
- Naya APK install/update karne se pehle app ka **Backup** Android share sheet se Files/Drive me rakh lein. Agar Android old/new debug signing mismatch ki wajah se update reject kare, purana app uninstall karke naya install karna pad sakta hai; uninstall local app data mita deta hai. Fresh install ke baad backup restore karein.
- Workflow me `APP_ID` default `com.aichallengevideo.schoolerp` hai. Pehli build se pehle apna permanent unique package ID rakhna ho to YAML me badlein. App update karte waqt wahi ID rehni chahiye.
- Capacitor wrapper web app ko APK ke andar bundle karta hai; is workflow ko alag live website URL ki zaroorat nahi. App ka Mode A data phir bhi local device storage me hi rahega.
- Debug APK aur Play Store release ke signing rules alag hain. Release ke liye keystore ko GitHub Secrets me secure rakhkar alag release workflow/config banani hogi; keystore ko repository me commit na karein.
- Is session se GitHub repo me commit/push ya Actions run nahi kiya ja sakta. Aapko updated ZIP aur workflow GitHub par replace/commit karke fresh build chalani hogi.
- Naye APK me print preview ke **Print / Save PDF** se Android print dialog khulega; export buttons Android share sheet kholenge. Files/Drive choose karke copy save karein.
- SMS batch dono—Pending Fees aur Attendance—ke liye hai, lekin drafts manually review karke SMS app me **Send** karne honge. Auto-send nahi hota; app offline-first hi rehta hai.
