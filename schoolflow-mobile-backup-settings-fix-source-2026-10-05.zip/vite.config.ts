import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: "autoUpdate",
      includeAssets: [
        "schoolflow.svg",
        "schoolflow-192.png",
        "schoolflow-512.png",
      ],
      manifest: {
        name: "SchoolFlow School ERP",
        short_name: "SchoolFlow",
        description: "Offline-first school management app",
        theme_color: "#5b5ce2",
        background_color: "#f6f7fb",
        display: "standalone",
        orientation: "portrait",
        scope: "/",
        start_url: "/",
        icons: [
          {
            src: "/schoolflow-192.png",
            sizes: "192x192",
            type: "image/png",
            purpose: "any",
          },
          {
            src: "/schoolflow-512.png",
            sizes: "512x512",
            type: "image/png",
            purpose: "any maskable",
          },
          {
            src: "/schoolflow.svg",
            sizes: "any",
            type: "image/svg+xml",
            purpose: "any",
          },
        ],
      },
      workbox: {
        globPatterns: ["**/*.{js,css,html,svg,png,woff2,wasm}"],
        navigateFallback: "/index.html",
        runtimeCaching: [],
      },
      devOptions: { enabled: false },
    }),
  ],
  build: {
    chunkSizeWarningLimit: 450,
    rollupOptions: {
      output: {
        manualChunks: {
          react: ["react", "react-dom", "react-router-dom"],
          dexie: ["dexie", "dexie-react-hooks"],
          icons: ["lucide-react"],
        },
      },
    },
  },
  server: { host: "0.0.0.0", allowedHosts: true },
});
