# SchoolFlow mobile update — 2026-10-05

## Changes

- Restore now keeps the selected backup preview open if the pre-restore safety ZIP cannot be saved. The user can retry saving it, cancel safely, or explicitly choose **Skip safety copy & restore** after reading the warning.
- First-login password screen now offers **Skip password change for now**. Skipping leaves the current password unchanged and clears the forced-change flag; the password can be changed later from **More → Settings → Change password**. Do not keep the default `admin123` password.
- Added an all-role **Settings** page with password access, Light/Dark/System theme, text size, and auto-lock preferences. Admins retain separate **School settings** for shared school profile and fee defaults.
- No desktop software/source was modified.

## Verification

- `npm run test`: 38 tests passed.
- `npm run build`: passed; the SQL.js WASM file is included in the offline PWA build.
- The supplied desktop dummy ZIP was previously checked for ZIP integrity and SQLite integrity, and its ZIP-to-mobile parser test passed.
- This source package is **not** a SchoolERP data backup and is **not** an APK. Build and install/deploy an updated mobile release before expecting an older installed app to show these changes.
