# Phone par SchoolFlow APK/PWA install aur test karne ka step-by-step guide

## Pehle yeh samjhein

- Phone par install karne ke liye **production build HTTPS URL** par hona chahiye. `npm run dev` ka URL development ke liye hai; usme PWA service worker off hota hai, isliye usse install/offline test na karein.
- Agar aapke paas pehle se live HTTPS website/preview URL hai, deployment wale steps skip karke wahi URL phone me kholein. Agar nahi, neeche diye hosting steps karein. Is session me production build ka live preview bhi chal raha hai—Arena me **SchoolFlow production phone test** preview link pehle try kar sakte hain. Agar phone par `Preview unavailable` aaye, external HTTPS host wala tareeqa use karein.
- SchoolFlow **offline-first Mode A** hai: student/fee data us browser/device ke local storage me rehta hai; cloud sync nahi hota. Test ke liye dummy data use karein.
- Agar aap GitHub Actions se bana **APK** use kar rahe hain, PWA ke HTTPS install steps skip karein. Naye APK me native Android print dialog aur export/share sheet use hoti hai; purane APK me yeh native fixes nahi honge.

## A. Production URL taiyar karein

1. Project ko apne computer par rakhein. Project folder me terminal/Command Prompt kholein.
2. Dependencies aur tests chalayein:
   ```bash
   npm ci
   npm run test
   ```
3. Production PWA build banayein:
   ```bash
   npm run build
   ```
   Build output `dist/` folder me aayega.
4. `dist/` ko kisi HTTPS static host par deploy karein (jaise Netlify, Vercel, ya Cloudflare Pages). Host settings me:
   - Build command: `npm run build`
   - Publish/output folder: `dist`
5. Deploy complete hone ke baad host ka `https://...` URL copy karein. Local `http://localhost:5173` ko phone me kholna sahi nahi hai—phone ka `localhost` phone ko hi point karta hai, computer ko nahi.

> Agar project already kisi HTTPS URL par live hai, isi guide me neeche phone steps se continue karein. Agar phone par preview URL open nahi hota, us URL ko install-ready hosting URL samajh kar rely na karein; pehle production build ko HTTPS host par deploy karein.

## B. Android par install karein

1. Phone ko internet se connect karein.
2. **Chrome** me production `https://...` URL kholein. Incognito ke bajay normal tab use karein. Page ko ek baar poori tarah load hone dein.
3. Pehli baar sign in ke liye:
   - Username: `admin`
   - Temporary password: `admin123`
4. App kahe to password badlein (minimum 8 characters). **Skip password change for now** se continue kar sakte hain; current password unchanged rahega, baad me **More → Settings → Change password** kholein. Default `admin123` ko na chhodein. Phir School Setup me test school name aur academic session bhar kar setup poora karein.
5. Chrome ke top-right `⋮` menu par tap karein.
6. **Install app** dikhe to use tap karke confirm karein. Agar **Add to Home screen** dikhe, use chunein aur **Install/Add** confirm karein.
7. Home screen par SchoolFlow icon aane ke baad Chrome tab band karke icon se app launch karein.

## C. iPhone par install karein

1. Production `https://...` URL **Safari** me kholein (normal tab; private browsing nahi).
2. **Share** button tap karein.
3. **Add to Home Screen** chunein, phir **Add** tap karein.
4. Home Screen par SchoolFlow icon se app kholein. Pehli baar login/setup ke liye upar Android section ke step 3–4 follow karein.

## D. Phone par features test karein

Saare records dummy rakhein; kisi asli guardian ko message/call na karein.

1. **Logo watermark / ID card:** Settings me original transparent PNG school logo upload/save karein. Students me dummy student add karein, uska profile kholein, **Print ID card** tap karein. Dono sides par logo halka watermark hona chahiye.
2. **Native print / PDF:** Print preview kholkar **Print / Save PDF** tap karein. APK me Android print dialog khulna chahiye; PDF banane ke liye **Save as PDF** select karein. Printer service available honi chahiye.
3. **Search:** Top search button tap karke dummy student ko naam/admission number se dhoondhein. Result tap karein; us student ka profile khulna chahiye. Search input focus par page ko auto-zoom nahi hona chahiye.
4. **Export / download:** Kisi CSV/export button ko tap karein. APK me Android share sheet khulegi; **Files/Save to Files** ya Drive choose karke file save karein. PWA/browser me file browser downloads me aani chahiye.
5. **Single SMS:** Test student ke SMS action par tap karein. Number aur professional draft SMS composer me dikhne chahiye. Review karein; test ki zaroorat na ho to Send na dabayein.
6. **Fee bulk SMS:** Pending Fees me dummy dues rakhein; filter/search sahi set karke **Review bulk SMS** tap karein. Ek guardian ke multiple visible dues ek draft me combine hone chahiye. Har draft kholkar verify karein; app auto-send nahi karti.
7. **Attendance bulk SMS:** Class/date choose karein, student absent mark karke **Save attendance** dabayein. Uske baad **Bulk SMS** kholein. Same guardian ke students ek message me group hone chahiye; number/text check karke SMS app me manually Send karein.
8. **Student exams:** Student profile → Exams me exam name/date/session, total/percentage aur subject-wise marks/grade/result table check karein.
9. **Call / WhatsApp:** Call se dialer khulna chahiye. WhatsApp reminder se recipient/message verify karein. Kisi ko actual call/message na karein bina permission.
10. **Promotion:** Dummy source class/session aur student banayein. Promotion me source, target aur next session select karein. Preview me students/class/roll check karein; phir hi confirm karein. Student profile aur promotion log me naya class/session/roll verify karein.
11. **Mobile ↔ desktop ZIP backup:** Phone ke **Backup & restore → Download ZIP backup** se `school_erp_full_backup_*.zip` banayein; APK share sheet me Files/Drive me save karein. Desktop SchoolERP me us ZIP ko restore karein. Reverse test ke liye desktop ka full-backup ZIP mobile app ke **Restore** me choose karein. Restore modal me pehle preview dekhein. Agar current-data safety ZIP save nahi hoti, **Retry safety copy** karein ya data-recovery risk samajh kar **Skip safety copy & restore** chunein. Desktop Restore ka end-to-end test abhi baaki hai: pehle desktop ki alag copy/dummy profile par test karein, phir student/photo, fees, attendance aur login verify karein. ZIP reject ho ya records galat dikhain to production data restore na karein.
12. **Offline:** App ko online ek baar launch karke load hone dein. Phir airplane mode on karke app dobara kholein. Local records/screens check karein. SMS/WhatsApp and external links ke liye phone network/app support chahiye.

## E. Agar install option nahi dikh raha

- URL `https://` se shuru ho aur address bar me secure/lock indicator ho.
- `npm run dev` wala development URL nahi, deployed production URL khola ho.
- Incognito/private tab ke bajay Chrome (Android) ya Safari (iPhone) ke normal tab me kholein.
- Site ko online poori load hone dein, phir tab close karke dobara kholein.
- iPhone par Safari ka **Share → Add to Home Screen** use karein.

## Data aur safety

- Mobile APK ka ZIP export desktop ke `school_erp.sqlite3` + photos/logos + manifest layout se match kiya gaya hai; transfer manual hai, automatic cloud sync nahi.
- Restore target device ka local data replace karta hai. Restore se pehle us device ka backup alag private jagah save karein.
- Real student information se test na karein. Test ke baad **Backup & restore** se test backup download karein; backup private rakhein.
- Browser/site storage clear karne ya app data delete karne se local test records mit sakte hain.
