import { describe, expect, it } from "vitest";
import {
  amountToWords,
  gradeFor,
  normalizeAdmission,
  nextAcademicSession,
  normalizeIndiaPhone,
  rankRows,
  roundMoney,
  setupRedirectPath,
  validAadhaar,
  validIndiaPhone,
  validMobile,
  validPastOrToday,
} from "../src/lib";

describe("school record validation", () => {
  it("normalizes admission numbers before duplicate checks", () => {
    expect(normalizeAdmission("  adm / 012- a ")).toBe("ADM012A");
    expect(normalizeAdmission("r-001/ 24")).toBe("R00124");
  });

  it("accepts only 10-digit Indian mobile numbers starting 6–9", () => {
    expect(validMobile("9876543210")).toBe(true);
    expect(validMobile("5876543210")).toBe(false);
    expect(validMobile("98765 43210")).toBe(false);
    expect(validMobile("123")).toBe(false);
  });

  it("normalizes Indian phone numbers for call and message links", () => {
    expect(normalizeIndiaPhone("9876543210")).toBe("919876543210");
    expect(normalizeIndiaPhone("09876543210")).toBe("919876543210");
    expect(normalizeIndiaPhone("+91 98765 43210")).toBe("919876543210");
    expect(validIndiaPhone("9876543210")).toBe(true);
    expect(validIndiaPhone("+91 98765 43210")).toBe(true);
    expect(validIndiaPhone("5876543210")).toBe(false);
    expect(validIndiaPhone("123")).toBe(false);
  });

  it("validates 12-digit Aadhaar and ignores optional spaces", () => {
    expect(validAadhaar("123456789012")).toBe(true);
    expect(validAadhaar("1234 5678 9012")).toBe(true);
    expect(validAadhaar("1234 5678 90")).toBe(false);
  });

  it("blocks dates in the future", () => {
    expect(validPastOrToday("")).toBe(true);
    expect(validPastOrToday("2020-01-01")).toBe(true);
    expect(validPastOrToday("9999-12-31")).toBe(false);
  });
});

describe("academic session helpers", () => {
  it("calculates the following academic session", () => {
    expect(nextAcademicSession("2026-27")).toBe("2027-28");
    expect(nextAcademicSession("2024-25")).toBe("2025-26");
  });
});

describe("academic grading and rank", () => {
  it.each([
    [100, "A1"],
    [91, "A1"],
    [90.99, "A2"],
    [81, "A2"],
    [79, "B1"],
    [61, "B2"],
    [51, "C1"],
    [41, "C2"],
    [33, "D"],
    [32.99, "E"],
    [0, "E"],
  ])("maps %s percent to grade %s", (percentage, grade) => {
    expect(gradeFor(percentage)).toBe(grade);
  });

  it("sorts by percent, then marks and name; equal percentages share a competition rank", () => {
    const ranked = rankRows([
      { name: "Riya", percentage: 90, marks: 180 },
      { name: "Aman", percentage: 95, marks: 190 },
      { name: "Zoya", percentage: 90, marks: 175 },
      { name: "Dev", percentage: 95, marks: 190 },
    ]);
    expect(ranked.map((row) => [row.name, row.rank])).toEqual([
      ["Aman", 1],
      ["Dev", 1],
      ["Riya", 3],
      ["Zoya", 3],
    ]);
  });
});

describe("Indian money display helpers", () => {
  it("rounds money to two decimal places", () => {
    expect(roundMoney(10.005)).toBe(10.01);
    expect(roundMoney(22.1)).toBe(22.1);
  });

  it("spells out rupee amounts in the Indian number system", () => {
    expect(amountToWords(0)).toBe("Zero rupees only");
    expect(amountToWords(1234567)).toBe(
      "Twelve Lakh Thirty Four Thousand Five Hundred Sixty Seven rupees only",
    );
  });
});

describe("one-time setup routing", () => {
  it.each([
    ["/home", undefined, undefined],
    ["/home", true, undefined],
    ["/setup", true, "/home"],
    ["/home", false, "/setup"],
    ["/setup", false, undefined],
    ["/change-password", false, undefined],
  ] as const)(
    "routes %s with setup status %s to %s",
    (pathname, setupComplete, expected) => {
      expect(setupRedirectPath(pathname, setupComplete)).toBe(expected);
    },
  );
});
