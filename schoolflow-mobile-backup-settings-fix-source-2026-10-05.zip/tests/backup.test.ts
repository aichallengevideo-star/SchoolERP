import { describe, expect, it } from "vitest";
import {
  createSchoolFlowBackup,
  parseSchoolFlowBackup,
  SCHOOLFLOW_BACKUP_FORMAT,
  SCHOOLFLOW_BACKUP_VERSION,
} from "../src/backup";

const tables = {
  students: [{ id: 1, name: "Asha" }],
  users: [{ id: 1, username: "admin" }],
  settings: [{ key: "schoolName", value: "River School" }],
};

describe("portable mobile/desktop backup format", () => {
  it("creates a platform-neutral .schoolerp payload", () => {
    const backup = createSchoolFlowBackup(tables, "2026-10-04T00:00:00.000Z");
    expect(backup).toEqual({
      app: "SchoolFlow",
      format: SCHOOLFLOW_BACKUP_FORMAT,
      version: SCHOOLFLOW_BACKUP_VERSION,
      createdAt: "2026-10-04T00:00:00.000Z",
      tables,
    });
    expect(JSON.parse(JSON.stringify(backup)).tables).toEqual(tables);
  });

  it("reads the current format and older version-1 files without a format label", () => {
    const current = createSchoolFlowBackup(tables, "2026-10-04T00:00:00.000Z");
    expect(parseSchoolFlowBackup(current)).toEqual(current);

    const legacy = { ...current, format: undefined };
    expect(parseSchoolFlowBackup(legacy).tables).toEqual(tables);
  });

  it("rejects a file from a different app", () => {
    expect(() => parseSchoolFlowBackup({ app: "Other", tables })).toThrow(
      "This file is not a SchoolFlow backup.",
    );
  });

  it("rejects incomplete files before they can replace local data", () => {
    expect(() =>
      parseSchoolFlowBackup({ app: "SchoolFlow", version: 1, tables: {} }),
    ).toThrow("Backup is incomplete");
  });

  it("asks for an app update before restoring a newer backup version", () => {
    expect(() =>
      parseSchoolFlowBackup({
        app: "SchoolFlow",
        version: SCHOOLFLOW_BACKUP_VERSION + 1,
        tables,
      }),
    ).toThrow("created by a newer app version");
  });
});
