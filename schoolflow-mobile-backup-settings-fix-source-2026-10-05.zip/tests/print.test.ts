// @vitest-environment jsdom
import { afterEach, describe, expect, it } from "vitest";
import { printStudentIdCards, printWallResult } from "../src/print";
import type { Student } from "../src/types";

const student: Student = {
  id: 1,
  admissionNo: "ADM-001",
  normalizedAdmissionNo: "ADM001",
  name: "Asha Kumar",
  father: "Ravi Kumar",
  mother: "Sita Kumar",
  classId: 1,
  section: "A",
  roll: 1,
  dob: "2016-04-12",
  gender: "Female",
  mobile: "9876543210",
  session: "2026-27",
  status: "Active",
  admissionDate: "2024-04-01",
  createdAt: "2024-04-01T00:00:00.000Z",
  updatedAt: "2024-04-01T00:00:00.000Z",
};

afterEach(() => {
  document
    .querySelector<HTMLButtonElement>('[aria-label="Close print preview"]')
    ?.click();
});

describe("student ID card logo watermark", () => {
  it("places the school's logo as a subtle watermark on both card sides", () => {
    const logo = "data:image/png;base64,AAABAA==";
    printStudentIdCards(
      [student],
      { name: "River School", logo },
      { 1: "Class 1" },
    );

    const preview = document.querySelector<HTMLIFrameElement>(
      "#schoolflow-print-preview iframe",
    );
    expect(preview?.srcdoc.match(/class="school-watermark"/g)).toHaveLength(2);
    expect(preview?.srcdoc).toContain(`src="${logo}"`);
    expect(preview?.srcdoc).toContain("opacity:.09");
    expect(preview?.srcdoc).toContain('aria-hidden="true"');
  });

  it("uses the school initial as a fallback when no logo is configured", () => {
    printStudentIdCards([student], { name: "River School" }, { 1: "Class 1" });

    const preview = document.querySelector<HTMLIFrameElement>(
      "#schoolflow-print-preview iframe",
    );
    expect(
      preview?.srcdoc.match(/class="school-watermark watermark-letter"/g),
    ).toHaveLength(2);
    expect(preview?.srcdoc).toContain(">R</div>");
  });
});

describe("wall result print layout", () => {
  it("uses a compact school heading and a simple tabular result", () => {
    const logo = "data:image/png;base64,AAABAA==";
    printWallResult(
      [
        {
          rank: 1,
          name: "Asha Kumar",
          admissionNo: "ADM-001",
          percentage: 95.5,
          grade: "A+",
        },
      ],
      "Annual Examination",
      { name: "River School", logo },
    );

    const preview = document.querySelector<HTMLIFrameElement>(
      "#schoolflow-print-preview iframe",
    );
    const html = preview?.srcdoc || "";
    expect(html.indexOf(`src="${logo}"`)).toBeLessThan(
      html.indexOf("River School</h2>"),
    );
    expect(html).toContain("<th>Rank</th>");
    expect(html).toContain("<th>Student name</th>");
    expect(html).toContain("#333");
    expect(html).not.toContain("<article>");
  });
});
