import { describe, expect, it } from "vitest";
import { strFromU8, unzipSync } from "fflate";
import {
  hashDesktopPassword,
  hashPassword,
  verifyStoredPassword,
} from "../src/lib";
import {
  createPremiumSchoolErpZip,
  desktopZipFilename,
  parsePremiumSchoolErpZip,
} from "../src/premiumBackup";
import type { AppUser, Student } from "../src/types";

const tinyPng =
  "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p6sAAAAASUVORK5CYII=";

async function sampleTables() {
  const salt = "test-salt";
  const user: AppUser = {
    id: 1,
    username: "admin",
    passwordHash: await hashPassword("safe-password", salt),
    salt,
    passwordAlgorithm: "sha256",
    desktopPasswordHash: await hashDesktopPassword("safe-password"),
    fullName: "Test Admin",
    role: "Admin",
    status: "Active",
    mustChange: false,
  };
  const student: Student = {
    id: 1,
    admissionNo: "DUMMY-1",
    normalizedAdmissionNo: "DUMMY-1",
    name: "Dummy Student",
    father: "Dummy Guardian",
    mother: "",
    classId: 1,
    section: "A",
    roll: 1,
    dob: "2018-01-01",
    gender: "Other",
    mobile: "9000000000",
    photo: tinyPng,
    session: "2026-27",
    status: "Active",
    admissionDate: "2026-01-01",
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z",
  };
  return {
    students: [student],
    classes: [
      {
        id: 1,
        name: "Class 1",
        section: "A",
        session: "2026-27",
        status: "Active",
        createdAt: "2026-01-01T00:00:00.000Z",
        updatedAt: "2026-01-01T00:00:00.000Z",
      },
    ],
    teachers: [],
    attendance: [],
    feeStructures: [],
    feeDues: [
      {
        id: 1,
        studentId: 1,
        session: "2026-27",
        month: "2026-04",
        tuition: 1000,
        transport: 0,
        exam: 0,
        admission: 0,
        library: 0,
        other: 0,
        discount: 0,
        fine: 0,
        total: 1000,
        paid: 250,
        balance: 750,
        status: "Partial",
        createdAt: "2026-04-01T00:00:00.000Z",
        updatedAt: "2026-04-02T00:00:00.000Z",
      },
    ],
    feePayments: [
      {
        id: 1,
        receiptNo: "RCPT-202604-0001",
        dueId: 1,
        studentId: 1,
        amount: 250,
        mode: "Cash",
        paidAt: "2026-04-02T00:00:00.000Z",
      },
    ],
    exams: [],
    examResults: [],
    transportRoutes: [],
    payroll: [],
    users: [user],
    settings: [
      { key: "schoolName", value: "Dummy School" },
      { key: "academicSession", value: "2026-27" },
      { key: "setupComplete", value: true },
      { key: "logo", value: tinyPng },
    ],
    auditLogs: [],
    notifications: [],
    promotions: [],
    familyBills: [],
    studentTimeline: [],
    documents: [],
    demandBatches: [],
    backupLogs: [],
  };
}

describe("Premium School ERP ZIP bridge", () => {
  it("creates the desktop archive layout and restores the mobile details from it", async () => {
    const tables = await sampleTables();
    const blob = await createPremiumSchoolErpZip(
      tables,
      "2026-10-04T08:13:29.000Z",
    );
    expect(blob.type).toBe("application/zip");
    const entries = unzipSync(new Uint8Array(await blob.arrayBuffer()));
    expect(entries["school_erp.sqlite3"]).toBeTruthy();
    expect(entries["manifest.txt"]).toBeTruthy();
    expect(entries["photos/student_1.png"]).toBeTruthy();
    expect(entries["logos/school_logo.png"]).toBeTruthy();
    expect(strFromU8(entries["manifest.txt"])).toContain(
      "Premium School ERP full backup",
    );

    const restored = await parsePremiumSchoolErpZip(
      new Uint8Array(await blob.arrayBuffer()),
    );
    expect(restored.exactMobileRoundTrip).toBe(true);
    expect(restored.warnings).toEqual([]);
    expect(restored.tables.students).toHaveLength(1);
    expect((restored.tables.students[0] as Student).photo).toBe(tinyPng);
    expect(restored.tables.feePayments).toEqual(tables.feePayments);
    expect(restored.tables.users).toEqual(tables.users);
    expect(restored.tables.settings).toContainEqual({
      key: "logo",
      value: tinyPng,
    });
  });

  it("requires a desktop-compatible hash for active users before creating a ZIP", async () => {
    const tables = await sampleTables();
    const user = tables.users[0] as AppUser;
    delete user.desktopPasswordHash;
    await expect(createPremiumSchoolErpZip(tables)).rejects.toThrow(
      "must sign in once",
    );
  });

  it("can sign in with a bcrypt hash imported from the desktop database", async () => {
    const passwordHash = await hashDesktopPassword("desktop-password");
    await expect(
      verifyStoredPassword("desktop-password", {
        passwordHash,
        passwordAlgorithm: "bcrypt",
      }),
    ).resolves.toBe(true);
    await expect(
      verifyStoredPassword("wrong-password", {
        passwordHash,
        passwordAlgorithm: "bcrypt",
      }),
    ).resolves.toBe(false);
  });

  it("uses the desktop backup file naming pattern", () => {
    expect(desktopZipFilename(new Date(2026, 9, 4, 8, 13, 29))).toBe(
      "school_erp_full_backup_20261004_081329.zip",
    );
  });
});
