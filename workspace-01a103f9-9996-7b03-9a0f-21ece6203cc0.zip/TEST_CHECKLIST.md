# SchoolFlow manual test checklist (60 checks)

**Throwaway data only.** Checks 54–60 include restore/offline/reset work; take a backup first and use a disposable browser profile for destructive steps. No sample school records are seeded.

## First run and sign-in

1. [ ] Open SchoolFlow in a fresh browser profile; confirm only the login screen appears (no demo students or fees).
2. [ ] Try an incorrect password; confirm a friendly error appears and the app remains on login.
3. [ ] Sign in as `admin` / `admin123`; confirm first login opens Change Password.
4. [ ] Try a password under 8 characters, then set a valid password and confirm it; verify the setup wizard opens.
5. [ ] Complete School Setup with a test school name, address, session, fee month and a theme; finish setup.
6. [ ] Refresh; verify the school name persists. Open About and confirm “Developed by Sanjaydat Kumar”.

## Classes, teachers and students

7. [ ] Create Class 1-A for session 2026-27; try creating the same class/section/session again and verify duplicate prevention.
8. [ ] Create Class 1-B; verify sections remain separate in the class list.
9. [ ] Add a teacher with a valid 10-digit mobile and salary suggestion; edit Class 1-A and assign that teacher.
10. [ ] Add a student with unique admission number, name, mobile and Class 1-A; leave roll blank and verify next available roll is assigned. Test No transport, School route and Private vehicle; create a route first, assign it in New Admission, save, reopen the profile and verify route/vehicle details.
11. [ ] Enter an invalid mobile, then an invalid Aadhaar length; verify validation blocks save. Clear Aadhaar and confirm it is optional.
12. [ ] Re-enter the same admission number with spaces, `/` or `-` differences; verify normalized duplicate detection.
13. [ ] Add another student with an already-used roll in Class 1-A; verify duplicate roll is blocked.
14. [ ] Upload a student photo; verify its thumbnail appears in the student register/profile.
15. [ ] Search students by name, admission number, parent and phone; verify matching results. Test Call, WhatsApp, SMS-composer and copy-number actions with a test contact; on desktop verify Call/SMS copy fallbacks, and on a phone verify native dialer/composer opens.
16. [ ] Filter Class 1-A then Class 1-B; verify no cross-section student leakage.
17. [ ] Open a student profile and inspect Overview, Fees, Attendance and Exams tabs; edit a detail and save.
18. [ ] Mark a student Left, filter Left records, then Restore active; verify the status updates.
19. [ ] Open Print admission slip; confirm the school-style in-app preview appears first. Print an ID card and verify the uploaded school logo appears as a subtle watermark on both sides, then choose Print / Save PDF or Close.

## Attendance

20. [ ] Open Attendance and choose Class 1-A; verify only that class/section’s students load.
21. [ ] Try a future date; verify date selection blocks it.
22. [ ] Tap All present; verify every loaded student shows Present.
23. [ ] Change one student to Absent and another to Late; save attendance. Open **Message absent guardians**; verify only absent students are listed and the SMS link opens a prefilled composer (do not send to a real guardian during testing).
24. [ ] Reopen the same class/date; verify saved states load and can be edited.
25. [ ] Save the same date again; verify existing records update rather than duplicate.
26. [ ] Open Monthly summary; check student counts/percentages and export the summary to CSV.

## Fees, family billing and demand bills

27. [ ] Create a Class 1-A fee plan with two or more fee heads; verify the monthly total.
28. [ ] Generate monthly dues; review the preview and confirm the first batch.
29. [ ] Generate the same month again; verify existing dues are reported/skipped.
30. [ ] Collect a partial payment; try an amount above balance and verify it is rejected.
31. [ ] Check the receipt number, fee month, mode, amount and remaining balance; open the in-app print preview first, then choose Print / Save PDF.
32. [ ] Pay the remaining amount and verify the fee entry changes to Paid.
33. [ ] Open Pending Fees; verify paid entries disappear and outstanding balances remain; export CSV. Check WhatsApp as the primary reminder and SMS as a separate fallback; confirm SMS opens a prefilled composer and is not auto-sent.
34. [ ] Prepare a demand bill batch; review class/month, duplicate counts and requested total before saving.
35. [ ] Confirm a demand bill batch; verify it appears in history and its print / CSV actions are available.
36. [ ] Add two siblings with the same father/guardian and mobile; select their family group, record a partial payment and verify the individual ledgers and family history update.

## Exams, promotion, payroll and transport

37. [ ] Create an exam for Class 1-A with two subjects; verify subjects and exam details appear on overview.
38. [ ] Enter marks for multiple students; enter a mark above maximum and verify the invalid value is rejected.
39. [ ] Save valid marks; verify entered count, grade, result status and rank list.
40. [ ] Search ranks by student name, admission number, rank and grade.
41. [ ] Create a normal promotion into a new session without pre-creating the destination class; review and confirm, then verify the class/section is created, session/roll changes are saved, and a promotion log is written. Also test individual promotion.
42. [ ] Add monthly payroll for a teacher; verify net salary = basic + allowance − deduction, mark Paid, and open salary slip print.
43. [ ] Create a transport route with vehicle number, driver, monthly fee and capacity; assign students from Transport and from New Admission. Verify both appear as route riders, capacity is shown, route monthly fee is used in future fee/demand calculations, and No transport/Private vehicle adds no school-route charge for new admissions.

## Reports and spreadsheet tools

44. [ ] Open all 10 report choices (Admission, Active, Left, TC, Class-wise, Fee Pending, Fee Ledger, Teacher, Transport, Audit Log); verify each loads from local data.
45. [ ] In a report, use search/class/date filters where available, then open Print / PDF preview.
46. [ ] Export Students and Fees as CSV; verify the downloaded files open as tabular data.
47. [ ] Export a selected data set as XLSX; verify the Excel file downloads.
48. [ ] Download the blank student import template; preview a test CSV with one valid row and one invalid mobile/class row. Confirm only valid rows can be imported.

## Access, integrity and settings

49. [ ] Add Teacher user, link it to an active teacher record, and assign that teacher to Class 1-A; verify class list, student search, attendance summary, exams and notices stay within Class 1-A, student fees/documents are hidden, and class/exam setup is read-only. Confirm Payroll is blocked. Test another role's allowed modules too.
50. [ ] Open Data Integrity and run checks; verify clear checks/issues display. If a supported fix is offered, apply it and re-run.
51. [ ] Change school profile, dark/light theme, text size and backup reminder in Settings; save and refresh. Upload a transparent PNG logo and verify transparency in Settings and a print preview; if replacing a previous black-backed PNG, re-upload the original PNG.

## Backup, offline/PWA and reset safety

52. [ ] As Admin/Accountant, use the Home dashboard's **Backup** shortcut or More → Backup & restore; download a dated `.schoolerp` backup and verify it appears in downloads.
53. [ ] Use the Home **Restore** shortcut to open the restore flow; choose that file, inspect record counts, cancel, and confirm no data changed.
54. [ ] On a separate throwaway profile, restore the file; verify records return and a pre-restore safety backup is offered/downloaded. Confirm roles without backup permission cannot open Backup & restore.
55. [ ] Build and serve the production version (`npm run build && npm run preview`); open it online once, then test loading saved screens in airplane mode.
56. [ ] On Android Chrome over HTTPS, install/add the production app to Home screen; launch it and check the 360px phone layout.
57. [ ] On a disposable database, try Fresh Start → Data Clear without a safety backup; verify the wipe is blocked.
58. [ ] Create the required safety backup, type `RESET`, confirm Data Clear; verify student-linked records clear while classes, staff, fee plans, settings and users remain.
59. [ ] On a separate disposable profile, test Full Factory Reset; verify first-run setup returns and `admin / admin123` is the default account.
60. [ ] Run `npm test` and `npm run build`; verify unit tests and production build pass.

> See **Current scope / important notes** in `README.md` for master-prompt requirements that are deliberately reduced in this MVP.
