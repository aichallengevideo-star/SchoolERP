# Phone par SchoolFlow install aur test karne ka step-by-step guide

## Pehle yeh samjhein

- Phone par install karne ke liye **production build HTTPS URL** par hona chahiye. `npm run dev` ka URL development ke liye hai; usme PWA service worker off hota hai, isliye usse install/offline test na karein.
- Agar aapke paas pehle se live HTTPS website/preview URL hai, deployment wale steps skip karke wahi URL phone me kholein. Agar nahi, neeche diye hosting steps karein. Is session me production build ka live preview bhi chal raha hai—Arena me **SchoolFlow production phone test** preview link pehle try kar sakte hain. Agar phone par `Preview unavailable` aaye, external HTTPS host wala tareeqa use karein.
- SchoolFlow **offline-first Mode A** hai: student/fee data us browser/device ke local storage me rehta hai; cloud sync nahi hota. Test ke liye dummy data use karein.

## A. Production URL taiyar karein

1. Project ko apne computer par rakhein. Project folder me terminal/Command Prompt kholein.
2. Dependencies aur tests chalayein:
   ```bash
   npm ci
   npm run test
   ```
3. Production PWA build banayein:
   ```bash
   npm run build
   ```
   Build output `dist/` folder me aayega.
4. `dist/` ko kisi HTTPS static host par deploy karein (jaise Netlify, Vercel, ya Cloudflare Pages). Host settings me:
   - Build command: `npm run build`
   - Publish/output folder: `dist`
5. Deploy complete hone ke baad host ka `https://...` URL copy karein. Local `http://localhost:5173` ko phone me kholna sahi nahi hai—phone ka `localhost` phone ko hi point karta hai, computer ko nahi.

> Agar project already kisi HTTPS URL par live hai, isi guide me neeche phone steps se continue karein. Agar phone par preview URL open nahi hota, us URL ko install-ready hosting URL samajh kar rely na karein; pehle production build ko HTTPS host par deploy karein.

## B. Android par install karein

1. Phone ko internet se connect karein.
2. **Chrome** me production `https://...` URL kholein. Incognito ke bajay normal tab use karein. Page ko ek baar poori tarah load hone dein.
3. Pehli baar sign in ke liye:
   - Username: `admin`
   - Temporary password: `admin123`
4. App kahe to password badlein, phir School Setup me test school name aur academic session bhar kar setup poora karein.
5. Chrome ke top-right `⋮` menu par tap karein.
6. **Install app** dikhe to use tap karke confirm karein. Agar **Add to Home screen** dikhe, use chunein aur **Install/Add** confirm karein.
7. Home screen par SchoolFlow icon aane ke baad Chrome tab band karke icon se app launch karein.

## C. iPhone par install karein

1. Production `https://...` URL **Safari** me kholein (normal tab; private browsing nahi).
2. **Share** button tap karein.
3. **Add to Home Screen** chunein, phir **Add** tap karein.
4. Home Screen par SchoolFlow icon se app kholein. Pehli baar login/setup ke liye upar Android section ke step 3–4 follow karein.

## D. Phone par features test karein

Saare records dummy rakhein; kisi asli guardian ko message/call na karein.

1. **Logo watermark / ID card:** Settings me original transparent PNG school logo upload/save karein. Students me dummy student add karein, uska profile kholein, **Print ID card** tap karein. Preview ke front aur back dono par logo halka watermark hona chahiye. Preview se **Print / Save PDF** choose karke PDF bhi check karein.
2. **Call:** Test student ke Call action par tap karein. Phone ka dialer khulna chahiye; call place karna zaroori nahi.
3. **SMS:** SMS action par tap karein. Number aur prefilled message SMS composer me dikhne chahiye. Review karein; test ki zaroorat na ho to Send na dabayein.
4. **WhatsApp / fee reminder:** Pending Fees me dummy balance wale student ko dekhein. WhatsApp primary reminder link khol kar recipient/message verify karein; SMS separate fallback hai. App koi WhatsApp/SMS automatically nahi bhejta.
5. **Absent guardian message:** Attendance me dummy student ko Absent mark karke **Message absent guardians** kholein; SMS composer me sahi test number/message verify karein.
6. **Promotion:** Dummy source class/session aur student banayein. Promotion me source, target aur next session select karein. Preview me students/class/roll check karein; phir hi confirm karein. Student profile aur promotion log me naya class/session/roll verify karein.
7. **Print preview:** Koi bhi print action khol kar pehle preview, phir **Print / Save PDF** dekhein. Android me PDF ke liye print dialog me **Save as PDF** chun sakte hain.
8. **Offline:** App ko online ek baar launch karke load hone dein. Phir airplane mode on karke Home Screen icon se app dobara kholein. Local records/screens check karein. WhatsApp, SMS, websites jaise external actions ko internet chahiye.

## E. Agar install option nahi dikh raha

- URL `https://` se shuru ho aur address bar me secure/lock indicator ho.
- `npm run dev` wala development URL nahi, deployed production URL khola ho.
- Incognito/private tab ke bajay Chrome (Android) ya Safari (iPhone) ke normal tab me kholein.
- Site ko online poori load hone dein, phir tab close karke dobara kholein.
- iPhone par Safari ka **Share → Add to Home Screen** use karein.

## Data aur safety

- App ka local data doosre phone, browser profile ya alag website URL par apne-aap sync/transfer nahi hota.
- Real student information se test na karein. Test ke baad **Backup & restore** se test backup download karein; backup private rakhein.
- Browser/site storage clear karne ya app data delete karne se local test records mit sakte hain.
