import { create } from "zustand";
import {
  createContext,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { db } from "./db";
import { hashPassword } from "./lib";
import type { AppUser } from "./types";

export interface SessionUser {
  id: number;
  username: string;
  fullName: string;
  role: AppUser["role"];
  teacherId?: number;
}
interface AuthState {
  user: SessionUser | null;
  setUser: (user: SessionUser | null) => void;
}
export const useAuth = create<AuthState>((set) => ({
  user: null,
  setUser: (user) => set({ user }),
}));

export async function loginLocal(
  username: string,
  password: string,
  remember = true,
) {
  const user = await db.users
    .where("username")
    .equals(username.trim().toLowerCase())
    .first();
  if (!user || user.status !== "Active")
    return {
      ok: false as const,
      message: "Username ya password match nahi hua.",
    };
  const hash = await hashPassword(password, user.salt);
  if (hash !== user.passwordHash)
    return {
      ok: false as const,
      message: "Username ya password match nahi hua.",
    };
  await db.users.update(user.id!, { lastLoginAt: new Date().toISOString() });
  const session: SessionUser = {
    id: user.id!,
    username: user.username,
    fullName: user.fullName,
    role: user.role,
    teacherId: user.teacherId,
  };
  const serialized = JSON.stringify(session);
  try {
    localStorage.setItem("schoolflow-last-username", user.username);
  } catch {
    // Keep login available when browser storage is restricted.
  }
  const now = String(Date.now());
  if (remember) {
    localStorage.setItem("schoolflow-session", serialized);
    localStorage.setItem("schoolflow-last-activity", now);
    sessionStorage.removeItem("schoolflow-session");
    sessionStorage.removeItem("schoolflow-last-activity");
  } else {
    sessionStorage.setItem("schoolflow-session", serialized);
    sessionStorage.setItem("schoolflow-last-activity", now);
    localStorage.removeItem("schoolflow-session");
    localStorage.removeItem("schoolflow-last-activity");
  }
  useAuth.getState().setUser(session);
  return { ok: true as const, mustChange: Boolean(user.mustChange) };
}

export async function changePasswordLocal(
  userId: number,
  currentPassword: string,
  newPassword: string,
) {
  const user = await db.users.get(userId);
  if (!user) throw new Error("User account nahi mila.");
  const currentHash = await hashPassword(currentPassword, user.salt);
  if (currentHash !== user.passwordHash)
    throw new Error("Current password sahi nahi hai.");
  const salt = crypto.randomUUID();
  await db.users.update(userId, {
    salt,
    passwordHash: await hashPassword(newPassword, salt),
    mustChange: false,
  });
}

interface Toast {
  id: number;
  message: string;
  kind: "success" | "error" | "info";
}
interface ToastApi {
  toast: (message: string, kind?: Toast["kind"]) => void;
}
const ToastContext = createContext<ToastApi>({ toast: () => undefined });
export const useToast = () => useContext(ToastContext);
export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const api = useMemo<ToastApi>(
    () => ({
      toast: (message, kind = "success") => {
        const id = Date.now() + Math.random();
        setToasts((items) => [...items, { id, message, kind }]);
        setTimeout(
          () => setToasts((items) => items.filter((t) => t.id !== id)),
          3400,
        );
      },
    }),
    [],
  );
  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="toast-stack" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.kind}`}>
            <span className="toast-dot" />
            {t.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
