import {
  useEffect,
  useMemo,
  useState,
  type FormEvent,
  type MouseEvent,
  type ReactNode,
} from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import {
  Activity,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Award,
  BadgeIndianRupee,
  BarChart3,
  Bell,
  BookOpenCheck,
  BusFront,
  CalendarCheck,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleAlert,
  ClipboardList,
  Clock3,
  CreditCard,
  Copy,
  Download,
  FileCheck2,
  FileChartColumn,
  FileSpreadsheet,
  Filter,
  GraduationCap,
  IndianRupee,
  KeyRound,
  Layers3,
  ListFilter,
  LogOut,
  Moon,
  Plus,
  Printer,
  Phone,
  MessageCircle,
  MessageSquare,
  Search,
  Settings,
  Share2,
  ShieldCheck,
  Sparkles,
  Sun,
  Trash2,
  UserPlus,
  Users,
  Wallet,
  WalletCards,
  WifiOff,
  X,
} from "lucide-react";
import {
  db,
  saveSetting,
  setting,
  audit,
  tablesForBackup,
  logStudentEvent,
} from "./db";
import { useAuth, changePasswordLocal, useToast } from "./state";
import {
  printAdmissionReceipt as printAdmissionSlip,
  printDemandBills,
  printFeeReceipt,
  printStudentIdCards,
  printTransferCertificate,
  printFamilyBill,
  printSalarySlip,
  printMarksheet,
  printClassMarksheets,
  printProgressReports,
  printWallResult,
  printDataReport,
  downloadWallResultSvg,
  type PrintSchool,
} from "./print";
import {
  Avatar,
  Badge,
  Button,
  Card,
  Divider,
  EmptyState,
  Input,
  Metric,
  Modal,
  PageTitle,
  SearchBox,
  SectionHeading,
  Select,
  TableWrap,
  Textarea,
} from "./ui";
import {
  amountToWords,
  csvString,
  displayDate,
  displayMonth,
  gradeFor,
  initials,
  maskAadhaar,
  money,
  monthISO,
  normalizeAdmission,
  normalizeIndiaPhone,
  numberIN,
  rankRows,
  resizeImage,
  roundMoney,
  saveFile,
  todayISO,
  validAadhaar,
  validIndiaPhone as isValidIndiaPhone,
  validMobile,
  validPastOrToday,
} from "./lib";
import type {
  AppUser,
  Attendance,
  AttendanceStatus,
  Exam,
  ExamResult,
  FamilyBill,
  FeeDue,
  FeeStructure,
  Payroll,
  Role,
  SchoolClass,
  Student,
  StudentDocument,
  StudentStatus,
  Teacher,
  TransportRoute,
} from "./types";

const useClasses = () => {
  const user = useAuth((state) => state.user);
  const classes =
    useLiveQuery(
      () =>
        db.classes
          .filter((c) => !c.deletedAt && c.status === "Active")
          .sortBy("name"),
      [],
      [],
    ) || [];
  return user?.role === "Teacher"
    ? user.teacherId
      ? classes.filter(
          (schoolClass) => schoolClass.teacherId === user.teacherId,
        )
      : []
    : classes;
};
const useSettings = () =>
  useLiveQuery(
    async () =>
      Object.fromEntries(
        (await db.settings.toArray()).map((x) => [x.key, x.value]),
      ),
    [],
    {} as Record<string, any>,
  ) || {};
const classLabel = (cls?: SchoolClass) =>
  cls ? `${cls.name} · ${cls.section}` : "Unassigned";
const printSchoolFromSettings = (
  settings: Record<string, any>,
): PrintSchool => ({
  name: String(settings.schoolName || "School"),
  address: String(settings.address || ""),
  phone: String(settings.phone || ""),
  email: String(settings.email || ""),
  website: String(settings.website || ""),
  logo: String(settings.logo || ""),
  principalName: String(settings.principalName || ""),
  printFooter: String(settings.printFooter || ""),
  receiptFooter: String(settings.receiptFooter || ""),
  paymentDetails: String(settings.paymentDetails || ""),
});
const feeHeadsForStudent = (
  student: Student,
  structure: FeeStructure,
  routes: TransportRoute[],
) => {
  const route = routes.find(
    (item) => item.id === student.routeId && item.status === "Active",
  );
  const transport = route
    ? route.monthlyFee
    : student.travelMode
      ? 0
      : structure.transport;
  return {
    tuition: structure.tuition,
    transport: roundMoney(transport),
    exam: structure.exam,
    admission: structure.admission,
    library: structure.library,
    other: structure.other,
  };
};
const totalFeeHeads = (heads: Record<string, number>) =>
  roundMoney(Object.values(heads).reduce((sum, amount) => sum + amount, 0));
const currentUser = () => useAuth.getState().user?.username || "admin";
const whatsappHref = (phone: string, message: string) =>
  `https://wa.me/${normalizeIndiaPhone(phone)}?text=${encodeURIComponent(message)}`;
const smsHref = (phone: string, message: string) => {
  const ios =
    typeof navigator !== "undefined" &&
    /iPhone|iPad|iPod/i.test(navigator.userAgent);
  const separator = ios ? "&" : "?";
  return `sms:+${normalizeIndiaPhone(phone)}${separator}body=${encodeURIComponent(message)}`;
};
async function copyText(value: string) {
  try {
    await navigator.clipboard.writeText(value);
    return true;
  } catch {
    const field = document.createElement("textarea");
    field.value = value;
    field.style.position = "fixed";
    field.style.opacity = "0";
    document.body.append(field);
    field.select();
    const copied = document.execCommand("copy");
    field.remove();
    return copied;
  }
}
type ToastMessage = (
  message: string,
  kind?: "success" | "error" | "info",
) => void;
const hasNativePhoneHandler = () =>
  typeof navigator !== "undefined" &&
  (/Android|iPhone|iPad|iPod|Windows Phone/i.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1));
const handlePhoneProtocol = (
  event: MouseEvent<HTMLAnchorElement>,
  action: "call" | "sms",
  phone: string,
  message: string,
  toast: ToastMessage,
) => {
  if (hasNativePhoneHandler()) return;
  event.preventDefault();
  const number = `+${normalizeIndiaPhone(phone)}`;
  const fallback = action === "call" ? number : `To: ${number}\n\n${message}`;
  void copyText(fallback).then((copied) =>
    toast(
      copied
        ? action === "call"
          ? "No phone dialer is available here. The number was copied."
          : "No SMS app is available here. The number and message were copied."
        : `This browser has no ${action === "call" ? "phone dialer" : "SMS app"}. Open this action on a phone.`,
      copied ? "info" : "error",
    ),
  );
};
const formatBytes = (bytes: number) => {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const exponent = Math.min(
    Math.floor(Math.log(bytes) / Math.log(1024)),
    units.length - 1,
  );
  return `${(bytes / 1024 ** exponent).toFixed(exponent ? 1 : 0)} ${units[exponent]}`;
};
const addDaysISO = (isoDate: string, days: number) => {
  const date = new Date(`${isoDate}T00:00:00`);
  date.setDate(date.getDate() + days);
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000)
    .toISOString()
    .slice(0, 10);
};
const monthOptions = Array.from({ length: 12 }, (_, i) => {
  const d = new Date();
  d.setMonth(d.getMonth() - i);
  return monthISO(d);
});
const makeTone = (status: string) =>
  status === "Paid" ||
  status === "Present" ||
  status === "Active" ||
  status === "Pass"
    ? "green"
    : status === "Partial" || status === "Late" || status === "Planned"
      ? "amber"
      : status === "Absent" ||
          status === "Fail" ||
          status === "Left" ||
          status === "Inactive"
        ? "rose"
        : "violet";

function FormActions({
  onCancel,
  busy,
  label = "Save changes",
}: {
  onCancel?: () => void;
  busy?: boolean;
  label?: string;
}) {
  return (
    <div className="form-actions">
      {onCancel && (
        <Button type="button" variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
      )}
      <Button type="submit" disabled={busy}>
        {busy ? "Saving…" : label}
        <ArrowRight size={16} />
      </Button>
    </div>
  );
}
function TinyEmpty({ title, text }: { title: string; text: string }) {
  return (
    <div className="mini-empty">
      <div className="mini-empty-icon">
        <Layers3 size={17} />
      </div>
      <span>
        <b>{title}</b>
        <small>{text}</small>
      </span>
    </div>
  );
}
function FilterPill({ children }: { children: ReactNode }) {
  return (
    <span className="filter-pill">
      <Filter size={13} />
      {children}
    </span>
  );
}

function DashboardBarList({
  title,
  subtitle,
  items,
  format,
  empty,
}: {
  title: string;
  subtitle: string;
  items: { label: string; value: number }[];
  format: (value: number) => string;
  empty: string;
}) {
  const max = Math.max(1, ...items.map((item) => item.value));
  return (
    <Card className="dashboard-insight-card">
      <div className="card-head">
        <div>
          <span className="card-eyebrow">ANALYTICS</span>
          <h3>{title}</h3>
        </div>
        <BarChart3 size={17} />
      </div>
      <p className="dashboard-insight-subtitle">{subtitle}</p>
      {items.length ? (
        <div className="dashboard-bar-list">
          {items.map((item) => (
            <div className="dashboard-bar-row" key={item.label}>
              <span title={item.label}>{item.label}</span>
              <div className="dashboard-bar-track">
                <i
                  style={{
                    width: `${Math.max(item.value ? 5 : 0, (item.value / max) * 100)}%`,
                  }}
                />
              </div>
              <b>{format(item.value)}</b>
            </div>
          ))}
        </div>
      ) : (
        <TinyEmpty title="Nothing to chart yet" text={empty} />
      )}
    </Card>
  );
}

export function HomePage() {
  const settings = useSettings();
  const user = useAuth((state) => state.user);
  const isTeacher = user?.role === "Teacher";
  const canViewFinance = ["Admin", "Principal", "Accountant"].includes(
    user?.role || "",
  );
  const canViewPayroll = ["Admin", "Principal", "Accountant"].includes(
    user?.role || "",
  );
  const canManageAdmissions =
    user?.role === "Admin" || user?.role === "Reception";
  const canBackup = user?.role === "Admin" || user?.role === "Accountant";
  const canViewReports = [
    "Admin",
    "Principal",
    "Accountant",
    "Reception",
  ].includes(user?.role || "");
  const today = todayISO();
  const weekDays = useMemo(
    () =>
      Array.from({ length: 7 }, (_, i) => {
        const d = new Date(`${today}T00:00:00`);
        d.setDate(d.getDate() - (6 - i));
        return {
          date: new Date(d.getTime() - d.getTimezoneOffset() * 60000)
            .toISOString()
            .slice(0, 10),
        };
      }),
    [today],
  );
  const allStudents =
    useLiveQuery(
      () => db.students.filter((s) => !s.deletedAt).toArray(),
      [],
      [],
    ) || [];
  const classes = useClasses();
  const students = isTeacher
    ? allStudents.filter((student) =>
        classes.some(
          (schoolClass) =>
            schoolClass.id === student.classId &&
            schoolClass.section === student.section &&
            schoolClass.session === student.session,
        ),
      )
    : allStudents;
  const teachers =
    useLiveQuery(
      () =>
        db.teachers
          .filter((t) => !t.deletedAt && t.status === "Active")
          .count(),
      [],
      0,
    ) || 0;
  const allAttendance =
    useLiveQuery(
      () =>
        db.attendance
          .where("date")
          .between(weekDays[0].date, today, true, true)
          .toArray(),
      [weekDays[0].date, today],
      [],
    ) || [];
  const attendance = isTeacher
    ? allAttendance.filter((row) =>
        classes.some(
          (schoolClass) =>
            schoolClass.id === row.classId &&
            schoolClass.section === row.section &&
            schoolClass.session === row.session,
        ),
      )
    : allAttendance;
  const allDues = useLiveQuery(() => db.feeDues.toArray(), [], []) || [];
  const studentIds = new Set(students.map((student) => student.id));
  const dues = isTeacher
    ? allDues.filter((due) => studentIds.has(due.studentId))
    : allDues;
  const payments = (
    useLiveQuery(() => db.feePayments.toArray(), [], []) || []
  ).filter(
    (payment) =>
      !payment.voidedAt && (!isTeacher || studentIds.has(payment.studentId)),
  );
  const payroll = useLiveQuery(() => db.payroll.toArray(), [], []) || [];
  const routes =
    useLiveQuery(
      () => db.transportRoutes.filter((r) => r.status === "Active").toArray(),
      [],
      [],
    ) || [];
  const allExamResults =
    useLiveQuery(() => db.examResults.toArray(), [], []) || [];
  const monthPaid = payments
    .filter((p) => p.paidAt.slice(0, 7) === monthISO())
    .reduce((a, p) => a + p.amount, 0);
  const pendingAmount = dues.reduce((a, d) => a + d.balance, 0);
  const activeStudents = students.filter((s) => s.status === "Active");
  const todayAttendance = attendance.filter((a) => a.date === today);
  const attendancePct = todayAttendance.length
    ? Math.round(
        (todayAttendance.filter(
          (a) => a.status === "Present" || a.status === "Late",
        ).length /
          todayAttendance.length) *
          100,
      )
    : 0;
  const birthdays = activeStudents.filter(
    (s) => s.dob?.slice(5) === todayISO().slice(5),
  );
  const allUpcoming = useLiveQuery(() => db.exams.toArray(), [], []) || [];
  const upcoming = isTeacher
    ? allUpcoming.filter((exam) =>
        classes.some(
          (schoolClass) =>
            schoolClass.id === exam.classId &&
            schoolClass.section === exam.section &&
            schoolClass.session === exam.session,
        ),
      )
    : allUpcoming;
  const visibleExamIds = new Set(upcoming.map((exam) => exam.id));
  const examResults = isTeacher
    ? allExamResults.filter((result) => visibleExamIds.has(result.examId))
    : allExamResults;
  const nextExam = upcoming
    .filter((e) => e.date >= todayISO())
    .sort((a, b) => a.date.localeCompare(b.date))[0];
  const lastSeven = weekDays.map(({ date }) => {
    const dayRows = attendance.filter((a) => a.date === date);
    const present = dayRows.filter(
      (a) => a.status === "Present" || a.status === "Late",
    ).length;
    return {
      date,
      present,
      marked: dayRows.length,
      percentage: dayRows.length
        ? Math.round((present / dayRows.length) * 100)
        : 0,
    };
  });
  const payBars = Array.from({ length: 6 }, (_, i) => {
    const d = new Date();
    d.setMonth(d.getMonth() - (5 - i));
    const m = monthISO(d);
    return {
      month: new Intl.DateTimeFormat("en", { month: "short" }).format(d),
      value: payments
        .filter((p) => p.paidAt.slice(0, 7) === m)
        .reduce((sum, p) => sum + p.amount, 0),
    };
  });
  const maxPay = Math.max(1, ...payBars.map((x) => x.value));
  const leftStudents = students.filter((s) => s.status === "Left").length;
  const tcIssued = students.filter((s) => s.status === "TC Issued").length;
  const upcomingExams = upcoming.filter(
    (e) => e.date >= today && e.status !== "Completed",
  );
  const pendingSalary = canViewPayroll
    ? payroll
        .filter((p) => p.month === monthISO() && p.status === "Unpaid")
        .reduce((sum, p) => sum + p.net, 0)
    : 0;
  const transportStudents = activeStudents.filter((s) =>
    Boolean(s.routeId),
  ).length;
  const recentCutoffDate = new Date(`${today}T00:00:00`);
  recentCutoffDate.setDate(recentCutoffDate.getDate() - 30);
  const recentCutoff = new Date(
    recentCutoffDate.getTime() - recentCutoffDate.getTimezoneOffset() * 60000,
  )
    .toISOString()
    .slice(0, 10);
  const recentAdmissions = students.filter(
    (s) => s.admissionDate >= recentCutoff && s.admissionDate <= today,
  ).length;
  const pendingByClassMap = new Map<string, number>();
  for (const d of dues) {
    if (d.balance <= 0) continue;
    const studentRow = students.find((s) => s.id === d.studentId);
    if (!studentRow) continue;
    const classRow = classes.find((c) => c.id === studentRow.classId);
    const label = `${classRow?.name || "Class"} · ${studentRow.section}`;
    pendingByClassMap.set(
      label,
      (pendingByClassMap.get(label) || 0) + d.balance,
    );
  }
  const pendingByClass = [...pendingByClassMap.entries()]
    .map(([label, value]) => ({ label, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 6);
  const classStrength = classes
    .map((c) => ({
      label: `${c.name} · ${c.section}`,
      value: activeStudents.filter(
        (s) => s.classId === c.id && s.section === c.section,
      ).length,
    }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 6);
  const currentYear = Number(today.slice(0, 4));
  const admissionTrend = Array.from({ length: 6 }, (_, i) => {
    const year = String(currentYear - 5 + i);
    return {
      label: year,
      value: students.filter((s) => s.admissionDate.slice(0, 4) === year)
        .length,
    };
  });
  const examPerformance = upcoming.concat([]).length
    ? upcoming
        .filter((e) => e.status === "Completed")
        .map((exam) => {
          const rows = examResults.filter((r) => r.examId === exam.id);
          const max = rows.reduce((sum, r) => sum + r.maxMarks, 0);
          const obtained = rows.reduce((sum, r) => sum + r.marks, 0);
          return {
            label: exam.name,
            value: max ? roundMoney((obtained / max) * 100) : 0,
          };
        })
        .filter((x) => x.value > 0)
        .sort((a, b) => b.label.localeCompare(a.label))
        .slice(0, 6)
    : [];
  const { toast } = useToast();
  return (
    <div className="page-stack dashboard-page">
      <PageTitle
        eyebrow={`${new Intl.DateTimeFormat("en-IN", { weekday: "long", day: "numeric", month: "long" }).format(new Date()).toUpperCase()} · ${settings.academicSession || "Academic session"}`}
        title={`Good ${new Date().getHours() < 12 ? "morning" : new Date().getHours() < 17 ? "afternoon" : "evening"}, ${useAuth.getState().user?.fullName.split(" ")[0] || "there"}.`}
        subtitle={`${settings.schoolName ? `${settings.schoolName} · ` : ""}${isTeacher ? "Here’s the latest from your assigned classes." : "Here’s what’s happening at your school today."}`}
        action={
          canBackup ? (
            <div className="table-actions">
              <Link to="/backup" className="btn btn-secondary">
                <Download size={16} /> Backup
              </Link>
              <Link to="/backup" className="btn btn-outline">
                <ShieldCheck size={16} /> Restore
              </Link>
            </div>
          ) : undefined
        }
      />
      <div className="welcome-banner">
        <div className="welcome-copy">
          <div className="welcome-tag">
            <span className="welcome-tag-dot" /> SCHOOL SNAPSHOT
          </div>
          <h2>
            Your school day,
            <br className="mobile-break" /> at a glance.
          </h2>
          <p>
            Small steps, smoother school days. Your local data is saved securely
            on this device.
          </p>
          <div className="welcome-quick">
            {canManageAdmissions && (
              <Link to="/students/new">
                <span>
                  <UserPlus size={16} />
                </span>{" "}
                New admission
              </Link>
            )}
            <Link to="/attendance">
              <span>
                <CalendarCheck size={16} />
              </span>{" "}
              Take attendance
            </Link>
            {canViewFinance && (
              <Link to="/fees">
                <span>
                  <BadgeIndianRupee size={16} />
                </span>{" "}
                Collect fee
              </Link>
            )}
          </div>
        </div>
        <div className="welcome-art">
          <div className="art-sun" />
          <div className="art-cloud cloud-left" />
          <div className="art-cloud cloud-right" />
          <div className="art-school">
            <div className="school-roof" />
            <div className="school-building">
              <div className="school-sign">
                {settings.schoolName
                  ? settings.schoolName.slice(0, 14)
                  : "SCHOOL"}
              </div>
              <div className="school-windows">
                <i />
                <i />
                <i />
                <i />
              </div>
              <div className="school-door" />
            </div>
            <div className="school-ground" />
          </div>
          <div className="art-leaf leaf-a" />
          <div className="art-leaf leaf-b" />
          <div className="art-flag">✦</div>
        </div>
        <div className="welcome-decoration d-one" />
        <div className="welcome-decoration d-two" />
      </div>
      <div className="metric-grid dashboard-metrics">
        <Metric
          label="Total admissions"
          value={numberIN(students.length)}
          icon={<Users size={18} />}
          accent="violet"
          note={
            isTeacher
              ? "Students in your assigned classes"
              : "All current and former students"
          }
          to="/students"
        />
        <Metric
          label="Active students"
          value={numberIN(activeStudents.length)}
          icon={<UserPlus size={18} />}
          accent="green"
          note="Enrolled and active"
          to="/students"
        />
        <Metric
          label="Left students"
          value={numberIN(leftStudents)}
          icon={<LogOut size={18} />}
          accent="amber"
          note="Left school records"
          to="/students"
        />
        <Metric
          label="TC issued"
          value={numberIN(tcIssued)}
          icon={<FileCheck2 size={18} />}
          accent="blue"
          note="Transfer certificates issued"
          to={canViewReports ? "/reports" : "/students"}
        />
        {!isTeacher && (
          <Metric
            label="Teachers"
            value={numberIN(teachers)}
            icon={<GraduationCap size={18} />}
            accent="blue"
            note="Active staff members"
            to="/teachers"
          />
        )}
        <Metric
          label="Classes"
          value={numberIN(classes.length)}
          icon={<BookOpenCheck size={18} />}
          accent="violet"
          note="Active classes and sections"
          to={isTeacher ? "/attendance" : "/classes"}
        />
        <Metric
          label="Today’s attendance"
          value={todayAttendance.length ? `${attendancePct}%` : "—"}
          icon={<CalendarDays size={18} />}
          accent="blue"
          note={
            todayAttendance.length
              ? `${todayAttendance.length} marked today`
              : "No records marked yet"
          }
          to="/attendance"
        />
        {canViewFinance && (
          <Metric
            label="Fee collection · this month"
            value={money(monthPaid)}
            icon={<IndianRupee size={18} />}
            accent="green"
            note={`${payments.filter((p) => p.paidAt.slice(0, 7) === monthISO()).length} receipts recorded`}
            to="/fees"
          />
        )}
        {canViewFinance && (
          <Metric
            label="Pending fees"
            value={money(pendingAmount)}
            icon={<WalletCards size={18} />}
            accent="amber"
            note={`${dues.filter((d) => d.balance > 0).length} dues need attention`}
            to="/fees/pending"
          />
        )}
        <Metric
          label="Upcoming exams"
          value={numberIN(upcomingExams.length)}
          icon={<ClipboardList size={18} />}
          accent="violet"
          note="Planned from today onward"
          to="/exams"
        />
        {canViewPayroll && (
          <Metric
            label="Salary pending"
            value={money(pendingSalary)}
            icon={<Wallet size={18} />}
            accent="amber"
            note="Unpaid this month"
            to="/payroll"
          />
        )}
        {!isTeacher && (
          <Metric
            label="Transport students"
            value={numberIN(transportStudents)}
            icon={<BusFront size={18} />}
            accent="blue"
            note={`${routes.length} active routes`}
            to="/transport"
          />
        )}
        <Metric
          label="Recent admissions"
          value={numberIN(recentAdmissions)}
          icon={<UserPlus size={18} />}
          accent="green"
          note="Last 30 days"
          to="/students"
        />
        <Metric
          label="Birthdays today"
          value={numberIN(birthdays.length)}
          icon={<Sparkles size={18} />}
          accent="amber"
          note={
            birthdays.length
              ? birthdays
                  .slice(0, 2)
                  .map((s) => s.name)
                  .join(", ")
              : "No birthdays today"
          }
          to="/students"
        />
      </div>
      <div className="dashboard-columns">
        <div className="dashboard-primary">
          <Card className="chart-card">
            <div className="card-head">
              <div>
                <span className="card-eyebrow">ATTENDANCE</span>
                <h3>Daily rhythm</h3>
              </div>
              <Link to="/attendance/summary" className="text-link">
                View register <ArrowUpRight size={15} />
              </Link>
            </div>
            <div className="attendance-chart">
              <div className="chart-gridlines">
                <i />
                <i />
                <i />
                <i />
              </div>
              <div className="chart-y-labels">
                <span>100%</span>
                <span>75%</span>
                <span>50%</span>
                <span>25%</span>
              </div>
              <div className="chart-bars">
                {lastSeven.map((day, i) => (
                  <div className="chart-bar-slot" key={day.date}>
                    <div
                      className="bar-value"
                      style={{
                        height: `${Math.max(day.marked ? 4 : 0, day.percentage)}%`,
                      }}
                    >
                      <span>{day.marked ? `${day.percentage}%` : ""}</span>
                    </div>
                    <small>
                      {new Intl.DateTimeFormat("en", {
                        weekday: "short",
                      }).format(new Date(`${day.date}T00:00:00`))}
                    </small>
                  </div>
                ))}
              </div>
            </div>
            <div className="chart-caption">
              <span>
                <i className="legend-dot violet-dot" /> Attendance rate (present
                + late)
              </span>
              <span>Last 7 days</span>
            </div>
          </Card>
          {canViewFinance && (
            <Card className="chart-card fee-chart-card">
              <div className="card-head">
                <div>
                  <span className="card-eyebrow">COLLECTIONS</span>
                  <h3>Fee desk, moving along</h3>
                </div>
                <Link to="/fees" className="text-link">
                  Open fee desk <ArrowUpRight size={15} />
                </Link>
              </div>
              <div className="fee-chart-summary">
                <strong>{money(monthPaid)}</strong>
                <Badge tone="green">This month</Badge>
                <span>
                  from{" "}
                  {
                    payments.filter((p) => p.paidAt.slice(0, 7) === monthISO())
                      .length
                  }{" "}
                  payments
                </span>
              </div>
              <div className="mini-bar-chart">
                {payBars.map((item) => (
                  <div key={item.month} className="mini-bar-col">
                    <span className="mini-bar-amount">
                      {item.value ? `${Math.round(item.value / 1000)}k` : "—"}
                    </span>
                    <div>
                      <i
                        style={{
                          height: `${item.value ? Math.max(8, (item.value / maxPay) * 100) : 4}%`,
                        }}
                      />
                    </div>
                    <small>{item.month}</small>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
        <div className="dashboard-secondary">
          <Card className="overview-card">
            <div className="card-head">
              <div>
                <span className="card-eyebrow">QUICK OVERVIEW</span>
                <h3>School at a glance</h3>
              </div>
              <div className="dots-menu">•••</div>
            </div>
            <div className="overview-list">
              <div>
                <span className="overview-icon lavender">
                  <Users size={16} />
                </span>
                <span>
                  <b>Students enrolled</b>
                  <small>
                    {isTeacher
                      ? "Across your assigned classes"
                      : "Across all active classes"}
                  </small>
                </span>
                <strong>{numberIN(activeStudents.length)}</strong>
              </div>
              <div>
                <span className="overview-icon mint">
                  <BookOpenCheck size={16} />
                </span>
                <span>
                  <b>Classes & sections</b>
                  <small>Ready for attendance</small>
                </span>
                <strong>{numberIN(classes.length)}</strong>
              </div>
              {!isTeacher && (
                <div>
                  <span className="overview-icon peach">
                    <GraduationCap size={16} />
                  </span>
                  <span>
                    <b>Teachers</b>
                    <small>Active staff members</small>
                  </span>
                  <strong>{numberIN(teachers)}</strong>
                </div>
              )}
            </div>
            <Divider />
            {canViewReports && (
              <Link to="/reports" className="overview-footer">
                Explore school reports <ArrowRight size={15} />
              </Link>
            )}
          </Card>
          <Card className="upcoming-card">
            <div className="card-head">
              <div>
                <span className="card-eyebrow">UP NEXT</span>
                <h3>Coming up</h3>
              </div>
              <span className="calendar-chip">
                <CalendarDays size={15} />
              </span>
            </div>
            {nextExam ? (
              <div className="upcoming-event">
                <div className="event-date">
                  <b>{new Date(`${nextExam.date}T00:00:00`).getDate()}</b>
                  <small>
                    {new Intl.DateTimeFormat("en", { month: "short" }).format(
                      new Date(`${nextExam.date}T00:00:00`),
                    )}
                  </small>
                </div>
                <div>
                  <b>{nextExam.name}</b>
                  <span>{displayDate(nextExam.date)} · exam day</span>
                  <small>
                    {classes.find((c) => c.id === nextExam.classId)?.name ||
                      "Class"}{" "}
                    · {nextExam.section}
                  </small>
                </div>
              </div>
            ) : (
              <TinyEmpty
                title="No exams on the calendar"
                text="Add an exam when your schedule is ready."
              />
            )}
            <div className="upcoming-note">
              <span className="note-spark">✦</span>
              <span>Little by little, great things get organised.</span>
            </div>
          </Card>
          <Card className="attention-card">
            <div className="attention-title">
              <span className="attention-icon">
                <Activity size={17} />
              </span>
              <div>
                <b>A gentle nudge</b>
                <small>Keep your records in good shape</small>
              </div>
            </div>
            {canViewFinance && (
              <div className="attention-item">
                <i className="attention-bullet amber-bullet" />
                <span>
                  <b>
                    {dues.filter((d) => d.balance > 0).length} pending fee
                    entries
                  </b>
                  <small>Review your fee desk</small>
                </span>
                <Link to="/fees/pending">
                  <ArrowRight size={15} />
                </Link>
              </div>
            )}
            <div className="attention-item">
              <i className="attention-bullet blue-bullet" />
              <span>
                <b>
                  {birthdays.length} birthday{birthdays.length === 1 ? "" : "s"}{" "}
                  today
                </b>
                <small>
                  {birthdays.length
                    ? birthdays
                        .slice(0, 2)
                        .map((s) => s.name)
                        .join(", ")
                    : "No birthdays today"}
                </small>
              </span>
              <span className="attention-hint">
                {birthdays.length ? "🎂" : "—"}
              </span>
            </div>
            {canBackup && (
              <div className="attention-item">
                <i className="attention-bullet green-bullet" />
                <span>
                  <b>Keep a fresh backup</b>
                  <small>Protect your school records</small>
                </span>
                <Link to="/backup">
                  <ArrowRight size={15} />
                </Link>
              </div>
            )}
          </Card>
        </div>
      </div>
      <div className="dashboard-insights-heading">
        <div>
          <span className="card-eyebrow">SCHOOL TRENDS</span>
          <h2>More insights</h2>
        </div>
        {canViewReports && (
          <Link to="/reports" className="text-link">
            Explore reports <ArrowRight size={14} />
          </Link>
        )}
      </div>
      <div className="dashboard-insight-grid">
        {canViewFinance && (
          <DashboardBarList
            title="Pending fees by class"
            subtitle="Outstanding balances"
            items={pendingByClass}
            format={(v) => money(v)}
            empty="No pending class balances."
          />
        )}
        <DashboardBarList
          title="Class strength"
          subtitle="Active students per class-section"
          items={classStrength}
          format={(v) => numberIN(v)}
          empty="Add classes and admissions to see class strength."
        />
        <DashboardBarList
          title="Admission trend"
          subtitle="New admissions by calendar year"
          items={admissionTrend}
          format={(v) => numberIN(v)}
          empty="No admission history yet."
        />
        <DashboardBarList
          title="Exam performance"
          subtitle="Average marks across completed exams"
          items={examPerformance}
          format={(v) => `${v.toFixed(1)}%`}
          empty="Complete an exam and enter marks to see performance."
        />
      </div>
      {!students.length && (
        <div className="first-start-note">
          <span className="first-start-icon">
            <Sparkles size={16} />
          </span>
          <span>
            <b>Your workspace is ready.</b> Add your first class and student to
            start making this dashboard your own.
          </span>
          {isTeacher ? (
            <small>Ask an administrator to assign your classes.</small>
          ) : (
            <Link to="/classes">
              Set up classes <ArrowRight size={14} />
            </Link>
          )}
        </div>
      )}
    </div>
  );
}

type StudentDraft = Omit<
  Student,
  "id" | "normalizedAdmissionNo" | "createdAt" | "updatedAt" | "status"
> & { id?: number; status: StudentStatus };
const suggestAdmissionNumber = (
  students: Student[],
  year = String(new Date().getFullYear()),
) => {
  const prefix = `ADM${year}`;
  const next =
    students.reduce((max, student) => {
      const normalized = normalizeAdmission(student.admissionNo);
      if (!normalized.startsWith(prefix)) return max;
      const sequence = Number(normalized.slice(prefix.length));
      return Number.isInteger(sequence) ? Math.max(max, sequence) : max;
    }, 0) + 1;
  return `ADM-${year}-${String(next).padStart(3, "0")}`;
};

const emptyStudent = (session: string): StudentDraft => ({
  admissionNo: "",
  name: "",
  father: "",
  mother: "",
  classId: 0,
  section: "A",
  roll: 0,
  dob: "",
  gender: "Female",
  religion: "",
  aadhaar: "",
  mobile: "",
  address: "",
  photo: "",
  routeId: undefined,
  travelMode: "None",
  session,
  status: "Active",
  admissionDate: todayISO(),
  bloodGroup: "",
  vehicleNumber: "",
});

export function StudentsPage() {
  const classes = useClasses();
  const user = useAuth((state) => state.user);
  const routes = useLiveQuery(() => db.transportRoutes.toArray(), [], []) || [];
  const activeRoutes = routes.filter((route) => route.status === "Active");
  const allStudents =
    useLiveQuery(
      () => db.students.filter((s) => !s.deletedAt).toArray(),
      [],
      [],
    ) || [];
  const students =
    user?.role === "Teacher"
      ? allStudents.filter((student) =>
          classes.some(
            (schoolClass) =>
              schoolClass.id === student.classId &&
              schoolClass.section === student.section &&
              schoolClass.session === student.session,
          ),
        )
      : allStudents;
  const canManageAdmissions =
    user?.role === "Admin" || user?.role === "Reception";
  const canPromoteStudents =
    user?.role === "Admin" || user?.role === "Principal";
  const canViewStudentFees = ["Admin", "Principal", "Accountant"].includes(
    user?.role || "",
  );
  const canViewStudentDocuments = ["Admin", "Principal", "Reception"].includes(
    user?.role || "",
  );
  const canManageStudentDocuments =
    user?.role === "Admin" || user?.role === "Reception";
  const profileTabs = [
    "Overview",
    ...(canViewStudentFees ? ["Fees"] : []),
    "Attendance",
    "Exams",
    ...(canViewStudentDocuments ? ["Documents"] : []),
    "Timeline",
  ];
  const settings = useSettings();
  const { toast } = useToast();
  const location = useLocation();
  const navigate = useNavigate();
  const params = useParams();
  const [query, setQuery] = useState("");
  const [classFilter, setClassFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("Active");
  const [formOpen, setFormOpen] = useState(false);
  const [profile, setProfile] = useState<Student | null>(null);
  const [editing, setEditing] = useState<Student | null>(null);
  const [tab, setTab] = useState("Overview");
  const [draft, setDraft] = useState<StudentDraft>(
    emptyStudent(String(settings.academicSession || "2026-27")),
  );
  const draftTransportMode = draft.routeId
    ? "School route"
    : draft.travelMode || "None";
  const selectedTransportRoute = routes.find(
    (route) => route.id === draft.routeId,
  );
  const availableTransportRoutes = routes.filter(
    (route) => route.status === "Active" || route.id === draft.routeId,
  );
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [sortBy, setSortBy] = useState("name");
  const [bulkIdOpen, setBulkIdOpen] = useState(false);
  const [bulkClass, setBulkClass] = useState("");
  const [statusTarget, setStatusTarget] = useState<{
    student: Student;
    status: "Left" | "TC Issued";
  } | null>(null);
  const [statusReason, setStatusReason] = useState("");
  const [tcNumber, setTcNumber] = useState("");
  const [tcDate, setTcDate] = useState(todayISO());
  const [possibleDuplicates, setPossibleDuplicates] = useState<Student[]>([]);
  const [newAdmissionSaved, setNewAdmissionSaved] = useState<Student | null>(
    null,
  );
  const [readmitTarget, setReadmitTarget] = useState<Student | null>(null);
  const [readmitClassKey, setReadmitClassKey] = useState("");
  const [readmitRoll, setReadmitRoll] = useState("");
  useEffect(() => {
    if (params.id) {
      const found = students.find((s) => s.id === Number(params.id));
      if (found) {
        setProfile(found);
        setTab("Overview");
      } else {
        setProfile(null);
      }
    }
  }, [params.id, students]);
  useEffect(() => {
    if (location.pathname === "/students/new") {
      if (!canManageAdmissions) {
        navigate("/students", { replace: true });
        return;
      }
      setEditing(null);
      setDraft((previous) => {
        if (previous.id || previous.name || previous.admissionNo)
          return previous;
        return {
          ...emptyStudent(String(settings.academicSession || "2026-27")),
          admissionNo: suggestAdmissionNumber(students),
        };
      });
      setFormOpen(true);
    }
  }, [
    location.pathname,
    settings.academicSession,
    students,
    canManageAdmissions,
    navigate,
  ]);
  const filtered = useMemo(
    () =>
      students
        .filter((s) => {
          const matchesClass =
            classFilter === "all" ||
            `${s.classId}-${s.section}` === classFilter;
          const matchesStatus =
            statusFilter === "All" || s.status === statusFilter;
          const q = query.toLowerCase().trim();
          const matchesQuery =
            !q ||
            [
              s.name,
              s.admissionNo,
              s.father,
              s.mother,
              s.mobile,
              s.aadhaar || "",
              String(s.roll),
            ].some((v) =>
              String(v || "")
                .toLowerCase()
                .includes(q),
            );
          return matchesClass && matchesStatus && matchesQuery;
        })
        .sort((a, b) =>
          sortBy === "roll"
            ? a.roll - b.roll || a.name.localeCompare(b.name)
            : sortBy === "admission"
              ? a.admissionDate.localeCompare(b.admissionDate)
              : a.name.localeCompare(b.name),
        ),
    [students, classFilter, statusFilter, query, sortBy],
  );
  const openNew = () => {
    if (!canManageAdmissions) {
      toast(
        "Your role can view student records but cannot create admissions.",
        "error",
      );
      return;
    }
    setEditing(null);
    setDraft({
      ...emptyStudent(String(settings.academicSession || "2026-27")),
      admissionNo: suggestAdmissionNumber(students),
    });
    setPossibleDuplicates([]);
    setErrors({});
    setFormOpen(true);
    navigate("/students/new");
  };
  const closeForm = () => {
    setFormOpen(false);
    setEditing(null);
    if (location.pathname === "/students/new") navigate("/students");
  };
  const openEdit = (student: Student) => {
    if (!canManageAdmissions) {
      toast("Your role has view-only access to student profiles.", "error");
      return;
    }
    setEditing(student);
    setDraft({ ...student });
    setErrors({});
    setProfile(null);
    setFormOpen(true);
  };
  const doBulkIdPrint = () => {
    const classId = Number(bulkClass);
    const selectedStudents = students.filter(
      (s) => s.status === "Active" && (!classId || s.classId === classId),
    );
    const classNames = Object.fromEntries(classes.map((c) => [c.id!, c.name]));
    if (!selectedStudents.length) {
      toast("No active students match this class.", "error");
      return;
    }
    printStudentIdCards(
      selectedStudents,
      printSchoolFromSettings(settings),
      classNames,
    );
    setBulkIdOpen(false);
  };
  const update = (key: keyof StudentDraft, value: string | number) =>
    setDraft((prev) => ({ ...prev, [key]: value }));
  const saveStudent = async (e?: FormEvent, allowSimilarDuplicate = false) => {
    e?.preventDefault();
    if (!canManageAdmissions) {
      toast("Your role cannot change student records.", "error");
      return;
    }
    const next: Record<string, string> = {};
    const normalized = normalizeAdmission(draft.admissionNo);
    if (!draft.admissionNo.trim())
      next.admissionNo = "Admission number required.";
    if (!draft.name.trim()) next.name = "Student name required.";
    if (!draft.classId) next.classId = "Please create/select a class first.";
    if (!draft.section.trim()) next.section = "Section required.";
    if (!draft.session.trim()) next.session = "Academic session required.";
    if (
      draftTransportMode === "School route" &&
      !activeRoutes.some((route) => route.id === draft.routeId)
    )
      next.routeId =
        "Choose an active school route or select another travel mode.";
    if (!validMobile(draft.mobile))
      next.mobile = "Enter a valid 10-digit Indian mobile number.";
    if (draft.aadhaar && !validAadhaar(draft.aadhaar))
      next.aadhaar = "Aadhaar must be 12 digits.";
    if (!validPastOrToday(draft.dob))
      next.dob = "Date of birth cannot be in the future.";
    if (!validPastOrToday(draft.admissionDate))
      next.admissionDate = "Admission date cannot be in the future.";
    const duplicateAdmission = await db.students
      .where("normalizedAdmissionNo")
      .equals(normalized)
      .first();
    if (duplicateAdmission && duplicateAdmission.id !== draft.id)
      next.admissionNo = "This admission number already exists.";
    const duplicateRoll = await db.students
      .filter(
        (s) =>
          !s.deletedAt &&
          s.status === "Active" &&
          s.classId === Number(draft.classId) &&
          s.section === draft.section &&
          s.session === draft.session &&
          s.roll === Number(draft.roll) &&
          s.id !== draft.id,
      )
      .first();
    if (draft.roll && duplicateRoll)
      next.roll = "This roll number is already used in the selected class.";
    const comparableName = draft.name.trim().toLowerCase().replace(/\s+/g, " ");
    const comparableMobile = draft.mobile.replace(/\D/g, "");
    const similarStudents =
      draft.dob && comparableMobile
        ? students.filter(
            (student) =>
              student.id !== draft.id &&
              !student.deletedAt &&
              student.name.trim().toLowerCase().replace(/\s+/g, " ") ===
                comparableName &&
              student.dob === draft.dob &&
              student.mobile.replace(/\D/g, "") === comparableMobile,
          )
        : [];
    setErrors(next);
    if (Object.keys(next).length) return;
    if (similarStudents.length && !allowSimilarDuplicate) {
      setPossibleDuplicates(similarStudents);
      return;
    }
    setBusy(true);
    try {
      const now = new Date().toISOString();
      const assignedRoute = activeRoutes.find(
        (route) => route.id === draft.routeId,
      );
      const data = {
        ...draft,
        admissionNo: draft.admissionNo.trim(),
        normalizedAdmissionNo: normalized,
        classId: Number(draft.classId),
        roll: Number(draft.roll),
        mobile: draft.mobile.trim(),
        aadhaar: draft.aadhaar?.replace(/\s/g, ""),
        routeId:
          draftTransportMode === "School route" ? assignedRoute?.id : undefined,
        travelMode: draftTransportMode as Student["travelMode"],
        vehicleNumber:
          draftTransportMode === "School route"
            ? assignedRoute?.vehicle || ""
            : draftTransportMode === "Private vehicle"
              ? draft.vehicleNumber?.trim() || ""
              : "",
        updatedAt: now,
      };
      if (!data.roll) {
        const activeRows = await db.students
          .filter(
            (s) =>
              !s.deletedAt &&
              s.status === "Active" &&
              s.classId === data.classId &&
              s.section === data.section &&
              s.session === data.session,
          )
          .toArray();
        data.roll = Math.max(0, ...activeRows.map((s) => s.roll)) + 1;
      }
      let id: number;
      if (draft.id) {
        id = draft.id;
        await db.students.update(id, data as Partial<Student>);
        await audit(
          currentUser(),
          "Updated",
          "Student",
          id,
          data.name,
          editing,
          data,
        );
        await logStudentEvent(
          id,
          "profile",
          "Student profile updated",
          data.name,
          currentUser(),
        );
      } else {
        id = await db.students.add({
          ...data,
          createdAt: now,
          status: data.status || "Active",
        } as Student);
        await audit(
          currentUser(),
          "Created",
          "Student",
          id,
          data.name,
          undefined,
          data,
        );
        await logStudentEvent(
          id,
          "admission",
          "Admission recorded",
          `Admitted to class ${data.classId}-${data.section} · Roll ${data.roll}`,
          currentUser(),
        );
        await db.notifications.add({
          type: "admission",
          title: "New admission saved",
          message: `${data.name} has been added to the student register.`,
          module: "/students",
          severity: "info",
          isRead: false,
          createdAt: now,
          relatedId: id,
        });
        if (allowSimilarDuplicate) {
          await audit(
            currentUser(),
            "Acknowledged possible duplicate admission",
            "Student",
            id,
            `Compared with ${similarStudents.map((student) => student.admissionNo).join(", ")}`,
          );
        }
        setNewAdmissionSaved({ ...data, id, createdAt: now } as Student);
      }
      toast(
        draft.id ? "Student profile updated." : "Admission saved successfully.",
      );
      setFormOpen(false);
      setEditing(null);
      setPossibleDuplicates([]);
      if (location.pathname === "/students/new") navigate("/students");
    } catch (err) {
      toast(
        err instanceof Error ? err.message : "Could not save the student.",
        "error",
      );
    } finally {
      setBusy(false);
    }
  };
  const handlePhoto = async (file?: File) => {
    if (!file) return;
    try {
      const photo = await resizeImage(file);
      update("photo", photo);
      toast("Photo ready for the student profile.");
    } catch {
      toast("Photo could not be processed.", "error");
    }
  };
  const changeStatus = async (student: Student, status: StudentStatus) => {
    if (status === "Left" || status === "TC Issued") {
      setStatusTarget({ student, status });
      setStatusReason("");
      setTcNumber("");
      setTcDate(todayISO());
      return;
    }
    const now = new Date().toISOString();
    await db.students.update(student.id!, {
      status,
      leavingDate: undefined,
      updatedAt: now,
    });
    await audit(
      currentUser(),
      `Changed status to ${status}`,
      "Student",
      student.id,
      student.name,
      student,
      { ...student, status },
    );
    await logStudentEvent(
      student.id!,
      "status",
      `Status changed to ${status}`,
      "Student restored to active records.",
      currentUser(),
    );
    toast(`Student status updated to ${status}.`);
    setProfile({ ...student, status, leavingDate: undefined });
  };
  const saveStatus = async () => {
    if (!statusTarget) return;
    const { student, status } = statusTarget;
    if (!statusReason.trim()) {
      toast("Please enter a reason for this status change.", "error");
      return;
    }
    if (status === "TC Issued" && !tcNumber.trim()) {
      toast("Transfer certificate number is required.", "error");
      return;
    }
    const now = new Date().toISOString();
    const patch =
      status === "TC Issued"
        ? {
            status,
            leavingDate: tcDate,
            leavingReason: statusReason.trim(),
            tcNumber: tcNumber.trim(),
            tcIssueDate: tcDate,
            lastClass: `${classes.find((c) => c.id === student.classId)?.name || student.classId}-${student.section}`,
            updatedAt: now,
          }
        : {
            status,
            leavingDate: tcDate,
            leavingReason: statusReason.trim(),
            updatedAt: now,
          };
    await db.students.update(student.id!, patch);
    await audit(
      currentUser(),
      `Changed status to ${status}`,
      "Student",
      student.id,
      statusReason.trim(),
      student,
      { ...student, ...patch },
    );
    await logStudentEvent(
      student.id!,
      "status",
      status === "TC Issued"
        ? "Transfer certificate issued"
        : "Student marked left",
      status === "TC Issued"
        ? `TC ${tcNumber.trim()} · ${statusReason.trim()}`
        : statusReason.trim(),
      currentUser(),
    );
    setProfile({ ...student, ...patch });
    setStatusTarget(null);
    toast(
      status === "TC Issued"
        ? "Transfer certificate details saved."
        : "Student marked left.",
    );
  };
  const openReadmit = (student: Student) => {
    const preferred =
      classes.find((item) => item.id === student.classId) || classes[0];
    setReadmitTarget(student);
    setReadmitClassKey(
      preferred
        ? `${preferred.id}|${preferred.section}|${preferred.session}`
        : "",
    );
    setReadmitRoll("");
  };
  const readmitClass = classes.find(
    (item) => `${item.id}|${item.section}|${item.session}` === readmitClassKey,
  );
  const readmitRollSuggestion = readmitClass
    ? Math.max(
        0,
        ...students
          .filter(
            (item) =>
              item.status === "Active" &&
              item.id !== readmitTarget?.id &&
              item.classId === readmitClass.id &&
              item.section === readmitClass.section &&
              item.session === readmitClass.session,
          )
          .map((item) => item.roll),
      ) + 1
    : 1;
  const confirmReadmit = async () => {
    if (!readmitTarget || !readmitClass) {
      toast("Choose an active class and session before re-admitting.", "error");
      return;
    }
    const roll = Number(readmitRoll || readmitRollSuggestion);
    if (!Number.isInteger(roll) || roll < 1) {
      toast("Enter a valid positive roll number.", "error");
      return;
    }
    const now = new Date().toISOString();
    const before = readmitTarget;
    const after: Student = {
      ...before,
      classId: readmitClass.id!,
      section: readmitClass.section,
      session: readmitClass.session,
      roll,
      status: "Active",
      leavingDate: undefined,
      leavingReason: undefined,
      tcNumber: undefined,
      tcIssueDate: undefined,
      lastClass: undefined,
      updatedAt: now,
    };
    try {
      await db.transaction("rw", db.students, db.studentTimeline, async () => {
        const duplicate = await db.students
          .where("[classId+section+session]")
          .equals([
            readmitClass.id!,
            readmitClass.section,
            readmitClass.session,
          ])
          .filter(
            (item) =>
              !item.deletedAt &&
              item.status === "Active" &&
              item.roll === roll &&
              item.id !== before.id,
          )
          .first();
        if (duplicate)
          throw new Error(
            `Roll ${roll} is already used in ${readmitClass.name}-${readmitClass.section}.`,
          );
        await db.students.update(before.id!, {
          classId: after.classId,
          section: after.section,
          session: after.session,
          roll: after.roll,
          status: "Active",
          leavingDate: undefined,
          leavingReason: undefined,
          tcNumber: undefined,
          tcIssueDate: undefined,
          lastClass: undefined,
          updatedAt: now,
        });
        await db.studentTimeline.add({
          studentId: before.id!,
          eventType: "readmission",
          title: "Student re-admitted",
          details: `${readmitClass.name}-${readmitClass.section} · ${readmitClass.session} · Roll ${roll}`,
          username: currentUser(),
          createdAt: now,
        });
      });
      await audit(
        currentUser(),
        "Re-admitted student",
        "Student",
        before.id,
        `${before.name} · ${readmitClass.name}-${readmitClass.section} · ${readmitClass.session} · Roll ${roll}`,
        before,
        after,
      );
      setProfile(after);
      setReadmitTarget(null);
      toast(
        `${before.name} re-admitted to ${readmitClass.name}-${readmitClass.section}.`,
      );
    } catch (error) {
      toast(
        error instanceof Error
          ? error.message
          : "Student could not be re-admitted.",
        "error",
      );
    }
  };
  const currentClass = classes.find((c) => c.id === Number(draft.classId));
  const profileTransportRoute = profile
    ? routes.find((route) => route.id === profile.routeId)
    : undefined;
  const profileContactText = profile
    ? `Student: ${profile.name} · ${profile.admissionNo} · Class ${classes.find((c) => c.id === profile.classId)?.name || profile.classId}-${profile.section} · Session ${profile.session}`
    : "";
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="SCHOOL DIRECTORY"
        title="Students"
        subtitle="A thoughtful home for every student record in your school."
        action={
          <div className="table-actions">
            {canManageAdmissions && (
              <Button
                variant="secondary"
                onClick={() => {
                  setBulkClass("");
                  setBulkIdOpen(true);
                }}
              >
                <Printer size={16} /> Bulk ID cards
              </Button>
            )}
            {canManageAdmissions && (
              <Button onClick={openNew}>
                <Plus size={17} /> New admission
              </Button>
            )}
          </div>
        }
      />
      <div className="student-kpis">
        <div className="student-kpi">
          <span className="kpi-icon lavender">
            <Users size={16} />
          </span>
          <span>
            <small>Total records</small>
            <b>{numberIN(students.length)}</b>
          </span>
        </div>
        <div className="student-kpi">
          <span className="kpi-icon mint">
            <CheckCircle2 size={16} />
          </span>
          <span>
            <small>Active students</small>
            <b>
              {numberIN(students.filter((s) => s.status === "Active").length)}
            </b>
          </span>
        </div>
        <div className="student-kpi">
          <span className="kpi-icon peach">
            <FileCheck2 size={16} />
          </span>
          <span>
            <small>TC / Left</small>
            <b>
              {numberIN(
                students.filter(
                  (s) => s.status === "TC Issued" || s.status === "Left",
                ).length,
              )}
            </b>
          </span>
        </div>
        <div className="student-kpi">
          <span className="kpi-caption">ACADEMIC SESSION</span>
          <b className="session-value">
            {settings.academicSession || "2026-27"}
          </b>
        </div>
      </div>
      <Card className="list-card">
        <div className="list-toolbar">
          <div className="list-toolbar-left">
            <SearchBox
              value={query}
              onChange={setQuery}
              placeholder="Search name, admission no, parent…"
            />
            <Select
              aria-label="Filter by class"
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
            >
              <option value="all">All classes</option>
              {classes.map((c) => (
                <option key={c.id} value={`${c.id}-${c.section}`}>
                  {c.name} · {c.section}
                </option>
              ))}
            </Select>
          </div>
          <div className="list-toolbar-right">
            <Select
              aria-label="Filter by status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option>Active</option>
              <option>Left</option>
              <option>TC Issued</option>
              <option>Passed Out</option>
              <option>Inactive</option>
              <option>All</option>
            </Select>
            <Select
              aria-label="Sort students"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="name">Sort: Name</option>
              <option value="roll">Sort: Roll</option>
              <option value="admission">Sort: Admission date</option>
            </Select>
            <span className="row-count">{filtered.length} records</span>
          </div>
        </div>
        {filtered.length ? (
          <TableWrap>
            <table className="data-table">
              <thead>
                <tr>
                  <th>STUDENT</th>
                  <th>CLASS · ROLL</th>
                  <th>ADMISSION NO.</th>
                  <th>PARENT / CONTACT</th>
                  <th>STATUS</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => {
                  const cls = classes.find((c) => c.id === s.classId);
                  const contactMessage = `Namaste ${s.father || "Parent"}, regarding ${s.name} (${s.admissionNo}).`;
                  return (
                    <tr
                      key={s.id}
                      onClick={() => {
                        setProfile(s);
                        setTab("Overview");
                        navigate(`/students/${s.id}`);
                      }}
                      className="click-row"
                    >
                      <td>
                        <div className="student-cell">
                          <Avatar name={s.name} photo={s.photo} />
                          <span>
                            <b>{s.name}</b>
                            <small>
                              {s.gender || "Student"} · {displayDate(s.dob)}
                            </small>
                          </span>
                        </div>
                      </td>
                      <td>
                        <b>
                          {cls?.name || "Class"} · {s.section}
                        </b>
                        <small className="table-secondary">
                          Roll {s.roll || "—"}
                        </small>
                      </td>
                      <td>
                        <span className="mono">{s.admissionNo}</span>
                      </td>
                      <td>
                        <b>{s.father || "—"}</b>
                        <small className="table-secondary">{s.mobile}</small>
                      </td>
                      <td>
                        <Badge tone={makeTone(s.status)}>{s.status}</Badge>
                      </td>
                      <td>
                        <div className="student-row-actions">
                          {isValidIndiaPhone(s.mobile) && (
                            <>
                              <a
                                href={`tel:+${normalizeIndiaPhone(s.mobile)}`}
                                title="Call guardian"
                                aria-label={`Call ${s.father || s.name}`}
                                onClick={(event) => {
                                  handlePhoneProtocol(
                                    event,
                                    "call",
                                    s.mobile,
                                    "",
                                    toast,
                                  );
                                  event.stopPropagation();
                                }}
                              >
                                <Phone size={14} />
                              </a>
                              <a
                                href={whatsappHref(s.mobile, contactMessage)}
                                title="Open WhatsApp message"
                                aria-label={`WhatsApp ${s.father || s.name}`}
                                onClick={(event) => event.stopPropagation()}
                              >
                                <MessageCircle size={14} />
                              </a>
                              <a
                                href={smsHref(s.mobile, contactMessage)}
                                title="Open SMS composer"
                                aria-label={`SMS ${s.father || s.name}`}
                                onClick={(event) => {
                                  handlePhoneProtocol(
                                    event,
                                    "sms",
                                    s.mobile,
                                    contactMessage,
                                    toast,
                                  );
                                  event.stopPropagation();
                                }}
                              >
                                <MessageSquare size={14} />
                              </a>
                              <button
                                className="contact-copy-button"
                                type="button"
                                title="Copy guardian phone number"
                                aria-label={`Copy phone number for ${s.father || s.name}`}
                                onClick={(event) => {
                                  event.stopPropagation();
                                  void copyText(s.mobile).then((copied) =>
                                    toast(
                                      copied
                                        ? "Phone number copied."
                                        : "Could not copy the phone number.",
                                      copied ? "success" : "error",
                                    ),
                                  );
                                }}
                              >
                                <Copy size={14} />
                              </button>
                            </>
                          )}
                          <button
                            className="row-more"
                            aria-label={`Open ${s.name}`}
                          >
                            <ArrowUpRight size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </TableWrap>
        ) : (
          <EmptyState
            title={
              query || classFilter !== "all"
                ? "No matching students"
                : "Your student register is ready"
            }
            text={
              query || classFilter !== "all"
                ? "Filters ko update karke phir try karein."
                : "Abhi koi student add nahi hua — “New admission” dabayein."
            }
            icon={<Users size={22} />}
          />
        )}
      </Card>
      <div className="privacy-note">
        <ShieldCheck size={15} />
        <span>
          Student information is stored only in this device’s browser database.
        </span>
        <Link to="/backup">
          Back up records <ArrowRight size={13} />
        </Link>
      </div>

      <Modal
        open={formOpen}
        onClose={closeForm}
        title={editing ? "Edit student profile" : "New admission"}
        subtitle="Add the essential details first — you can always complete the profile later."
        size="lg"
      >
        <form className="form-grid" onSubmit={saveStudent}>
          <div className="photo-upload">
            <div className="photo-preview">
              {draft.photo ? (
                <img src={draft.photo} alt="Student preview" />
              ) : (
                <Avatar name={draft.name || "Student"} size="lg" />
              )}
            </div>
            <div>
              <b>Student photo</b>
              <span>Optional · JPG/PNG, resized on this device</span>
              <label className="upload-link">
                {draft.photo ? "Change photo" : "Upload photo"}
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => void handlePhoto(e.target.files?.[0])}
                />
              </label>
            </div>
          </div>
          <div className="form-section-label">STUDENT DETAILS</div>
          <Input
            label="Admission number"
            value={draft.admissionNo}
            onChange={(e) => update("admissionNo", e.target.value)}
            placeholder="e.g. ADM-2026-001"
            hint={`Suggested next number: ${suggestAdmissionNumber(students)} · editable`}
            required
            error={errors.admissionNo}
          />
          <Input
            label="Student name"
            value={draft.name}
            onChange={(e) => update("name", e.target.value)}
            placeholder="Full name"
            required
            error={errors.name}
          />
          <Select
            label="Class"
            value={draft.classId || ""}
            required
            error={errors.classId}
            onChange={(e) => {
              const cls = classes.find((c) => c.id === Number(e.target.value));
              setDraft((prev) => ({
                ...prev,
                classId: Number(e.target.value),
                section: cls?.section || prev.section,
              }));
            }}
          >
            <option value="">Select class</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} · {c.section}
              </option>
            ))}
          </Select>
          <Input
            label="Section"
            value={draft.section}
            onChange={(e) => update("section", e.target.value.toUpperCase())}
            required
            error={errors.section}
          />
          <Input
            label="Roll number"
            type="number"
            min="1"
            value={draft.roll || ""}
            onChange={(e) => update("roll", Number(e.target.value))}
            hint="Leave blank to assign next available"
            error={errors.roll}
          />
          <Select
            label="Gender"
            value={draft.gender}
            onChange={(e) => update("gender", e.target.value)}
          >
            <option>Female</option>
            <option>Male</option>
            <option>Other</option>
          </Select>
          <div className="form-section-label">PARENTS & CONTACT</div>
          <Input
            label="Father’s name"
            value={draft.father}
            onChange={(e) => update("father", e.target.value)}
            placeholder="Parent / guardian"
          />
          <Input
            label="Mother’s name"
            value={draft.mother}
            onChange={(e) => update("mother", e.target.value)}
            placeholder="Parent / guardian"
          />
          <Input
            label="Mobile number"
            type="tel"
            inputMode="numeric"
            maxLength={10}
            value={draft.mobile}
            onChange={(e) =>
              update("mobile", e.target.value.replace(/\D/g, "").slice(0, 10))
            }
            placeholder="10-digit number"
            required
            error={errors.mobile}
            hint="Indian mobile number; starts 6–9"
          />
          <Input
            label="Aadhaar number"
            inputMode="numeric"
            maxLength={12}
            value={draft.aadhaar}
            onChange={(e) =>
              update("aadhaar", e.target.value.replace(/\D/g, "").slice(0, 12))
            }
            placeholder="Optional · 12 digits"
            error={errors.aadhaar}
          />
          <div className="form-section-label">ADMISSION & SESSION</div>
          <Input
            label="Date of birth"
            type="date"
            value={draft.dob}
            max={todayISO()}
            onChange={(e) => update("dob", e.target.value)}
            error={errors.dob}
          />
          <Input
            label="Admission date"
            type="date"
            value={draft.admissionDate}
            max={todayISO()}
            onChange={(e) => update("admissionDate", e.target.value)}
            error={errors.admissionDate}
          />
          <Input
            label="Blood group (optional)"
            value={draft.bloodGroup || ""}
            onChange={(e) => update("bloodGroup", e.target.value.toUpperCase())}
            placeholder="e.g. B+"
          />
          <Input
            label="Academic session"
            value={draft.session}
            onChange={(e) => update("session", e.target.value)}
            required
          />
          <div className="form-section-label">TRAVEL & TRANSPORT</div>
          <Select
            label="Travel arrangement"
            value={draftTransportMode}
            onChange={(e) => {
              const mode = e.target.value as NonNullable<
                StudentDraft["travelMode"]
              >;
              setDraft((previous) => ({
                ...previous,
                travelMode: mode,
                routeId: undefined,
                vehicleNumber:
                  mode === "Private vehicle" &&
                  previous.travelMode === "Private vehicle" &&
                  !previous.routeId
                    ? previous.vehicleNumber || ""
                    : "",
              }));
            }}
          >
            <option value="None">No school transport / self-arranged</option>
            <option value="School route">School vehicle / route</option>
            <option value="Private vehicle">Private vehicle</option>
          </Select>
          {draftTransportMode === "School route" && (
            <>
              <Select
                label="School route"
                value={draft.routeId || ""}
                error={errors.routeId}
                onChange={(e) => {
                  const routeId = Number(e.target.value) || undefined;
                  const route = routes.find((item) => item.id === routeId);
                  setDraft((previous) => ({
                    ...previous,
                    travelMode: "School route",
                    routeId,
                    vehicleNumber: route?.vehicle || "",
                  }));
                }}
              >
                <option value="">Choose an active school route</option>
                {availableTransportRoutes.map((route) => (
                  <option
                    key={route.id}
                    value={route.id}
                    disabled={route.status !== "Active"}
                  >
                    {route.name} · {route.vehicle} · {money(route.monthlyFee)}
                    /month
                    {route.status !== "Active" ? " · inactive" : ""}
                  </option>
                ))}
              </Select>
              {selectedTransportRoute ? (
                <div className="form-helper full-span">
                  Vehicle: {selectedTransportRoute.vehicle || "—"} · Driver:{" "}
                  {selectedTransportRoute.driver || "—"} · Monthly fee:{" "}
                  {money(selectedTransportRoute.monthlyFee)}
                  {selectedTransportRoute.status !== "Active"
                    ? " · This route is inactive; choose an active route to save."
                    : " · This route fee is added to future dues."}
                </div>
              ) : activeRoutes.length ? (
                <div className="form-helper full-span">
                  Choose the route used by this student. The route’s monthly
                  transport fee will be included in future dues.
                </div>
              ) : (
                <div className="form-helper full-span">
                  No active routes yet. Open Transport in another tab to add a
                  route, then return here.
                  <a href="/transport" target="_blank" rel="noreferrer">
                    {" "}
                    Open Transport <ArrowRight size={13} />
                  </a>
                </div>
              )}
            </>
          )}
          {draftTransportMode === "Private vehicle" && (
            <Input
              label="Private vehicle number / pickup note"
              value={draft.vehicleNumber || ""}
              onChange={(e) => update("vehicleNumber", e.target.value)}
              placeholder="Optional vehicle number or pickup detail"
              hint="This is a note only; no school-route fee is added."
            />
          )}
          {draftTransportMode === "None" && (
            <div className="form-helper full-span">
              No school route is assigned; school transport charges for this new
              admission are set to zero.
            </div>
          )}
          <Input
            label="Religion"
            value={draft.religion}
            onChange={(e) => update("religion", e.target.value)}
            placeholder="Optional"
          />
          <Textarea
            label="Permanent address"
            value={draft.address}
            onChange={(e) => update("address", e.target.value)}
            placeholder="House, street, area, city"
            className="full-span"
            rows={2}
          />
          {!classes.length && (
            <div className="inline-alert full-span">
              <CircleAlert size={16} />
              <span>No active classes are set up yet.</span>
              <Link to="/classes">
                Create a class first <ArrowRight size={14} />
              </Link>
            </div>
          )}
          <div className="modal-actions full-span">
            <Button type="button" variant="secondary" onClick={closeForm}>
              Cancel
            </Button>
            <Button type="submit" disabled={busy || !classes.length}>
              {busy ? "Saving…" : editing ? "Save profile" : "Save admission"}
              <ArrowRight size={16} />
            </Button>
          </div>
        </form>
      </Modal>

      <Modal
        open={!!profile}
        onClose={() => {
          setProfile(null);
          if (location.pathname.startsWith("/students/")) navigate("/students");
        }}
        title="Student profile"
        subtitle={
          profile
            ? `${profile.admissionNo} · ${classes.find((c) => c.id === profile.classId)?.name || "Class"} ${profile.section}`
            : ""
        }
        size="lg"
      >
        {profile && (
          <div className="profile-view">
            <div className="profile-overview">
              <Avatar name={profile.name} photo={profile.photo} size="lg" />
              <div className="profile-name">
                <h3>{profile.name}</h3>
                <span>
                  {profile.father ? `S/o ${profile.father}` : "Student record"}{" "}
                  · Roll {profile.roll || "—"}
                </span>
              </div>
              <Badge tone={makeTone(profile.status)}>{profile.status}</Badge>
            </div>
            <div className="profile-tabs">
              {profileTabs.map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={tab === t ? "active" : ""}
                >
                  {t}
                </button>
              ))}
            </div>
            {tab === "Overview" ? (
              <div className="profile-details">
                <div>
                  <small>DATE OF BIRTH</small>
                  <b>{displayDate(profile.dob)}</b>
                </div>
                <div>
                  <small>GENDER</small>
                  <b>{profile.gender || "—"}</b>
                </div>
                <div>
                  <small>FATHER / GUARDIAN</small>
                  <b>{profile.father || "—"}</b>
                </div>
                <div>
                  <small>MOTHER</small>
                  <b>{profile.mother || "—"}</b>
                </div>
                <div>
                  <small>MOBILE</small>
                  <b>
                    {isValidIndiaPhone(profile.mobile)
                      ? `+${normalizeIndiaPhone(profile.mobile)}`
                      : profile.mobile || "—"}
                  </b>
                </div>
                <div>
                  <small>AADHAAR</small>
                  <b>{maskAadhaar(profile.aadhaar)}</b>
                </div>
                <div>
                  <small>ACADEMIC SESSION</small>
                  <b>{profile.session}</b>
                </div>
                <div>
                  <small>ADMISSION DATE</small>
                  <b>{displayDate(profile.admissionDate)}</b>
                </div>
                <div className="full-span">
                  <small>ADDRESS</small>
                  <b>{profile.address || "—"}</b>
                </div>
                <div className="full-span">
                  <small>SCHOOL TRANSPORT</small>
                  <b>
                    {profile.routeId
                      ? profileTransportRoute
                        ? `${profileTransportRoute.name} · ${profileTransportRoute.vehicle || "Vehicle not set"}${profileTransportRoute.status !== "Active" ? " · inactive" : ""}`
                        : profile.vehicleNumber ||
                          "Previously assigned school route"
                      : profile.travelMode === "Private vehicle"
                        ? `Private vehicle · ${profile.vehicleNumber || "number not provided"}`
                        : "No school vehicle · self-arranged travel"}
                  </b>
                </div>
              </div>
            ) : (
              <ProfileTabContent
                tab={tab}
                student={profile}
                canViewFees={canViewStudentFees}
                canViewDocuments={canViewStudentDocuments}
                canManageDocuments={canManageStudentDocuments}
              />
            )}
            <div className="profile-actions">
              {canManageAdmissions && (
                <Button variant="secondary" onClick={() => openEdit(profile)}>
                  Edit profile
                </Button>
              )}
              <Button
                variant="outline"
                onClick={() =>
                  printAdmissionSlip(
                    profile,
                    printSchoolFromSettings(settings),
                    classes.find((c) => c.id === profile.classId)?.name ||
                      String(profile.classId),
                  )
                }
              >
                <Printer size={15} /> Print admission slip
              </Button>
              <Button
                variant="outline"
                onClick={() =>
                  printStudentIdCards(
                    [profile],
                    printSchoolFromSettings(settings),
                    Object.fromEntries(classes.map((c) => [c.id!, c.name])),
                  )
                }
              >
                <FileCheck2 size={15} /> Print ID card
              </Button>
              {canPromoteStudents && (
                <Link
                  className="btn btn-secondary"
                  to={`/promotion?student=${profile.id}`}
                >
                  Promote student <ArrowRight size={14} />
                </Link>
              )}
              {profile.status === "TC Issued" && (
                <Button
                  variant="outline"
                  onClick={() =>
                    printTransferCertificate(
                      profile,
                      printSchoolFromSettings(settings),
                      classes.find((c) => c.id === profile.classId)?.name ||
                        String(profile.classId),
                    )
                  }
                >
                  <Printer size={15} /> Print TC
                </Button>
              )}
              {isValidIndiaPhone(profile.mobile) && (
                <>
                  <a
                    className="btn btn-outline"
                    href={`tel:+${normalizeIndiaPhone(profile.mobile)}`}
                    onClick={(event) =>
                      handlePhoneProtocol(
                        event,
                        "call",
                        profile.mobile,
                        "",
                        toast,
                      )
                    }
                  >
                    <Phone size={14} /> Call guardian
                  </a>
                  <a
                    className="btn btn-secondary"
                    href={whatsappHref(profile.mobile, profileContactText)}
                  >
                    <MessageCircle size={14} /> WhatsApp summary
                  </a>
                  <a
                    className="btn btn-outline"
                    href={smsHref(profile.mobile, profileContactText)}
                    onClick={(event) =>
                      handlePhoneProtocol(
                        event,
                        "sms",
                        profile.mobile,
                        profileContactText,
                        toast,
                      )
                    }
                  >
                    <MessageSquare size={14} /> SMS summary
                  </a>
                </>
              )}
              {canManageAdmissions && profile.status === "Active" && (
                <Button
                  variant="soft"
                  onClick={() => void changeStatus(profile, "Left")}
                >
                  Mark left
                </Button>
              )}
              {canManageAdmissions && profile.status === "Active" && (
                <Button
                  variant="secondary"
                  onClick={() => void changeStatus(profile, "TC Issued")}
                >
                  Issue TC
                </Button>
              )}
              {canManageAdmissions && profile.status !== "Active" && (
                <Button onClick={() => openReadmit(profile)}>
                  Restore / re-admit
                </Button>
              )}
            </div>
          </div>
        )}
      </Modal>
      <Modal
        open={bulkIdOpen}
        onClose={() => setBulkIdOpen(false)}
        title="Print class ID cards"
        subtitle="Choose a class or print cards for all active students."
        size="md"
      >
        <div className="form-grid">
          <Select
            label="Class"
            value={bulkClass}
            onChange={(e) => setBulkClass(e.target.value)}
          >
            <option value="">All classes</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} · {c.section} · {c.session}
              </option>
            ))}
          </Select>
          <div className="modal-actions full-span">
            <Button variant="secondary" onClick={() => setBulkIdOpen(false)}>
              Cancel
            </Button>
            <Button onClick={doBulkIdPrint}>
              <Printer size={16} /> Print ID cards
            </Button>
          </div>
        </div>
      </Modal>
      <Modal
        open={!!statusTarget}
        onClose={() => setStatusTarget(null)}
        title={
          statusTarget?.status === "TC Issued"
            ? "Issue transfer certificate"
            : "Mark student left"
        }
        subtitle="This status change is recorded in the student timeline and audit log."
        size="md"
      >
        {statusTarget && (
          <div className="form-grid">
            {statusTarget.status === "TC Issued" && (
              <Input
                label="TC number"
                value={tcNumber}
                onChange={(e) => setTcNumber(e.target.value)}
                required
              />
            )}
            <Input
              label={
                statusTarget.status === "TC Issued"
                  ? "TC issue date"
                  : "Leaving date"
              }
              type="date"
              value={tcDate}
              max={todayISO()}
              onChange={(e) => setTcDate(e.target.value)}
              required
            />
            <Textarea
              label="Reason"
              value={statusReason}
              onChange={(e) => setStatusReason(e.target.value)}
              rows={3}
              required
            />
            <div className="modal-actions full-span">
              <Button variant="secondary" onClick={() => setStatusTarget(null)}>
                Cancel
              </Button>
              <Button onClick={() => void saveStatus()}>
                {statusTarget.status === "TC Issued"
                  ? "Save TC details"
                  : "Confirm left status"}
              </Button>
            </div>
          </div>
        )}
      </Modal>
      <Modal
        open={!!readmitTarget}
        onClose={() => setReadmitTarget(null)}
        title="Restore / re-admit student"
        subtitle={
          readmitTarget
            ? `${readmitTarget.name} · choose the new class, session and roll number.`
            : ""
        }
        size="md"
      >
        {readmitTarget && (
          <>
            <div className="restore-warning">
              <CircleAlert size={16} />
              <span>
                This action returns the student to Active status and keeps
                previous records linked. A timeline and audit entry will be
                added.
              </span>
            </div>
            <div className="form-grid">
              <Select
                label="New class / section / session"
                value={readmitClassKey}
                onChange={(event) => {
                  setReadmitClassKey(event.target.value);
                  setReadmitRoll("");
                }}
              >
                <option value="">Choose destination class</option>
                {classes.map((item) => (
                  <option
                    key={`${item.id}|${item.section}|${item.session}`}
                    value={`${item.id}|${item.section}|${item.session}`}
                  >
                    {item.name} · {item.section} · {item.session}
                  </option>
                ))}
              </Select>
              <Input
                label="New roll number"
                type="number"
                min="1"
                value={
                  readmitRoll ||
                  (readmitClass ? String(readmitRollSuggestion) : "")
                }
                onChange={(event) => setReadmitRoll(event.target.value)}
                hint="Suggested next available roll; editable."
              />
              {!classes.length && (
                <div className="inline-alert full-span">
                  <CircleAlert size={16} />
                  <span>
                    No active class is available. Create one before
                    re-admitting.
                  </span>
                  <Link to="/classes">
                    Create class <ArrowRight size={14} />
                  </Link>
                </div>
              )}
              <div className="modal-actions full-span">
                <Button
                  variant="secondary"
                  onClick={() => setReadmitTarget(null)}
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => void confirmReadmit()}
                  disabled={!readmitClass}
                >
                  Confirm re-admission
                </Button>
              </div>
            </div>
          </>
        )}
      </Modal>
      <Modal
        open={possibleDuplicates.length > 0}
        onClose={() => setPossibleDuplicates([])}
        title="Possible duplicate student"
        subtitle="A student with the same name, date of birth and mobile number already exists. Please check before continuing."
        size="md"
      >
        <div className="duplicate-student-list">
          {possibleDuplicates.map((student) => (
            <div key={student.id}>
              <Avatar name={student.name} photo={student.photo} size="sm" />
              <span>
                <b>{student.name}</b>
                <small>
                  {student.admissionNo} ·{" "}
                  {classes.find((c) => c.id === student.classId)?.name}-
                  {student.section} · {student.session}
                </small>
              </span>
            </div>
          ))}
        </div>
        <div className="restore-warning">
          <CircleAlert size={16} />
          <span>
            If this is a genuine sibling/duplicate record, you can continue. The
            acknowledgement will be saved in the audit log.
          </span>
        </div>
        <div className="modal-actions">
          <Button variant="secondary" onClick={() => setPossibleDuplicates([])}>
            Review details
          </Button>
          <Button
            onClick={() => void saveStudent(undefined, true)}
            disabled={busy}
          >
            {busy ? "Saving…" : "Save anyway"}
          </Button>
        </div>
      </Modal>
      <Modal
        open={!!newAdmissionSaved}
        onClose={() => setNewAdmissionSaved(null)}
        title="Admission saved"
        subtitle={
          newAdmissionSaved
            ? `${newAdmissionSaved.name} · ${newAdmissionSaved.admissionNo}`
            : ""
        }
        size="md"
      >
        {newAdmissionSaved && (
          <>
            <div className="restore-file-header">
              <span className="restore-file-icon">
                <CheckCircle2 size={20} />
              </span>
              <span>
                <b>Student is now in the register</b>
                <small>
                  {
                    classes.find((c) => c.id === newAdmissionSaved.classId)
                      ?.name
                  }
                  -{newAdmissionSaved.section} · Roll {newAdmissionSaved.roll} ·{" "}
                  {newAdmissionSaved.session}
                </small>
              </span>
            </div>
            <p className="form-helper">
              Print an admission acknowledgement or prepare an ID card now. Both
              can also be printed later from the student profile.
            </p>
            <div className="modal-actions">
              <Button
                variant="secondary"
                onClick={() => setNewAdmissionSaved(null)}
              >
                Done
              </Button>
              <Button
                variant="outline"
                onClick={() =>
                  printAdmissionSlip(
                    newAdmissionSaved,
                    printSchoolFromSettings(settings),
                    classes.find((c) => c.id === newAdmissionSaved.classId)
                      ?.name || String(newAdmissionSaved.classId),
                  )
                }
              >
                <Printer size={15} /> Admission receipt
              </Button>
              <Button
                onClick={() =>
                  printStudentIdCards(
                    [newAdmissionSaved],
                    printSchoolFromSettings(settings),
                    Object.fromEntries(classes.map((c) => [c.id!, c.name])),
                  )
                }
              >
                <FileCheck2 size={15} /> ID card
              </Button>
            </div>
          </>
        )}
      </Modal>
    </div>
  );
}

function ProfileTabContent({
  tab,
  student,
  canViewFees,
  canViewDocuments,
  canManageDocuments,
}: {
  tab: string;
  student: Student;
  canViewFees: boolean;
  canViewDocuments: boolean;
  canManageDocuments: boolean;
}) {
  const fees =
    useLiveQuery<FeeDue[], FeeDue[]>(
      () =>
        canViewFees
          ? db.feeDues.where("studentId").equals(student.id!).toArray()
          : Promise.resolve([] as FeeDue[]),
      [student.id, canViewFees],
      [],
    ) || [];
  const attendance =
    useLiveQuery(
      () => db.attendance.where("studentId").equals(student.id!).toArray(),
      [student.id],
      [],
    ) || [];
  const results =
    useLiveQuery(
      () => db.examResults.where("studentId").equals(student.id!).toArray(),
      [student.id],
      [],
    ) || [];
  const documents =
    useLiveQuery<StudentDocument[], StudentDocument[]>(
      () =>
        canViewDocuments
          ? db.documents
              .where("studentId")
              .equals(student.id!)
              .filter((d) => !d.deletedAt)
              .toArray()
          : Promise.resolve([] as StudentDocument[]),
      [student.id, canViewDocuments],
      [],
    ) || [];
  const timeline =
    useLiveQuery(
      () =>
        db.studentTimeline
          .where("studentId")
          .equals(student.id!)
          .reverse()
          .sortBy("createdAt"),
      [student.id],
      [],
    ) || [];
  const { toast } = useToast();
  const [calendarMonth, setCalendarMonth] = useState(monthISO());
  const uploadDocument = async (file?: File) => {
    if (!canManageDocuments) {
      toast("Your role cannot change student documents.", "error");
      return;
    }
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast("Document is too large. Choose a file up to 5 MB.", "error");
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => toast("File could not be read.", "error");
    reader.onload = async () => {
      try {
        const id = await db.documents.add({
          studentId: student.id!,
          docType: "General",
          fileName: file.name,
          mimeType: file.type || "application/octet-stream",
          dataUrl: String(reader.result),
          remarks: "",
          createdAt: new Date().toISOString(),
        });
        await audit(
          currentUser(),
          "Uploaded student document",
          "Document",
          id,
          file.name,
        );
        await logStudentEvent(
          student.id!,
          "document",
          "Document added",
          file.name,
          currentUser(),
        );
        toast("Document saved to this device.");
      } catch {
        toast("Document could not be saved.", "error");
      }
    };
    reader.readAsDataURL(file);
  };
  const deleteDocument = async (id: number) => {
    if (!canManageDocuments) {
      toast("Your role cannot change student documents.", "error");
      return;
    }
    if (!window.confirm("Remove this document from the student profile?"))
      return;
    await db.documents.update(id, { deletedAt: new Date().toISOString() });
    await audit(currentUser(), "Removed student document", "Document", id);
    await logStudentEvent(
      student.id!,
      "document",
      "Document removed",
      `Document record ${id} removed`,
      currentUser(),
    );
    toast("Document removed.");
  };
  if (tab === "Fees" && !canViewFees)
    return (
      <TinyEmpty
        title="Fees are restricted"
        text="Your role does not have access to student fee records."
      />
    );
  if (tab === "Fees")
    return (
      <div className="profile-tab-list">
        {fees.length ? (
          fees
            .sort((a, b) => b.month.localeCompare(a.month))
            .map((d) => (
              <div key={d.id}>
                <span>
                  <b>{displayMonth(d.month)}</b>
                  <small>{d.session}</small>
                </span>
                <span>{money(d.total)}</span>
                <Badge tone={makeTone(d.status)}>{d.status}</Badge>
              </div>
            ))
        ) : (
          <TinyEmpty
            title="No fee entries yet"
            text="Collected or generated dues will show here."
          />
        )}
      </div>
    );
  if (tab === "Attendance") {
    const pct = attendance.length
      ? Math.round(
          (attendance.filter((a) => a.status !== "Absent").length /
            attendance.length) *
            100,
        )
      : 0;
    const monthRows = attendance.filter((row) =>
      row.date.startsWith(calendarMonth),
    );
    const monthPct = monthRows.length
      ? Math.round(
          (monthRows.filter((row) => row.status !== "Absent").length /
            monthRows.length) *
            100,
        )
      : 0;
    const [calendarYear, calendarMonthNumber] = calendarMonth
      .split("-")
      .map(Number);
    const firstWeekday = new Date(
      calendarYear,
      calendarMonthNumber - 1,
      1,
    ).getDay();
    const daysInMonth = new Date(
      calendarYear,
      calendarMonthNumber,
      0,
    ).getDate();
    const dayStatus = new Map(
      monthRows.map((row) => [Number(row.date.slice(8, 10)), row.status]),
    );
    const moveMonth = (delta: number) => {
      const next = new Date(calendarYear, calendarMonthNumber - 1 + delta, 1);
      setCalendarMonth(monthISO(next));
    };
    return (
      <div className="profile-attendance-panel">
        <div className="profile-tab-summary">
          <strong>{pct}%</strong>
          <span>Attendance rate across {attendance.length} marked days.</span>
          <div className="attendance-summary-chips">
            <Badge tone="green">
              {attendance.filter((a) => a.status === "Present").length} present
            </Badge>
            <Badge tone="rose">
              {attendance.filter((a) => a.status === "Absent").length} absent
            </Badge>
            <Badge tone="amber">
              {attendance.filter((a) => a.status === "Late").length} late
            </Badge>
          </div>
        </div>
        <section className="student-att-calendar">
          <header>
            <button
              type="button"
              aria-label="Previous month"
              onClick={() => moveMonth(-1)}
            >
              ‹
            </button>
            <b>{displayMonth(calendarMonth)}</b>
            <button
              type="button"
              aria-label="Next month"
              onClick={() => moveMonth(1)}
            >
              ›
            </button>
          </header>
          <div className="calendar-month-summary">
            <span>{monthRows.length} marked days</span>
            <b>{monthPct}% present / late</b>
          </div>
          <div className="student-calendar-grid student-calendar-weekdays">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
              <small key={day}>{day}</small>
            ))}
          </div>
          <div className="student-calendar-grid">
            {Array.from({ length: firstWeekday }, (_, i) => (
              <span className="calendar-blank" key={`blank-${i}`} />
            ))}
            {Array.from({ length: daysInMonth }, (_, i) => {
              const day = i + 1;
              const status = dayStatus.get(day);
              return (
                <span
                  key={day}
                  title={
                    status
                      ? `${day} ${displayMonth(calendarMonth)} · ${status}`
                      : `${day} ${displayMonth(calendarMonth)} · Not marked`
                  }
                  className={`student-calendar-day ${status ? status.toLowerCase() : "unmarked"}`}
                >
                  {day}
                  {status && <i />}
                </span>
              );
            })}
          </div>
          <div className="student-calendar-legend">
            <span>
              <i className="present" />
              Present
            </span>
            <span>
              <i className="absent" />
              Absent
            </span>
            <span>
              <i className="late" />
              Late
            </span>
            <span>
              <i className="unmarked" />
              Not marked
            </span>
          </div>
        </section>
      </div>
    );
  }
  if (tab === "Exams")
    return (
      <div className="profile-tab-list">
        {results.length ? (
          results.map((r) => (
            <div key={r.id}>
              <span>
                <b>{r.subject}</b>
                <small>Max {r.maxMarks}</small>
              </span>
              <span>
                {r.marks} / {r.maxMarks}
              </span>
              <Badge tone={makeTone(r.result)}>{r.grade}</Badge>
            </div>
          ))
        ) : (
          <TinyEmpty
            title="No exam marks yet"
            text="Results will appear after marks are entered."
          />
        )}
      </div>
    );
  if (tab === "Documents" && !canViewDocuments)
    return (
      <TinyEmpty
        title="Documents are restricted"
        text="Your role does not have access to student documents."
      />
    );
  if (tab === "Documents")
    return (
      <div className="profile-tab-list">
        {canManageDocuments && (
          <label className="file-drop">
            <input
              type="file"
              accept="image/*,.pdf,.doc,.docx,.txt"
              onChange={(e) => {
                void uploadDocument(e.target.files?.[0]);
                e.currentTarget.value = "";
              }}
            />
            <span className="file-drop-icon">
              <Plus size={18} />
            </span>
            <b>Add student document</b>
            <small>PDF or image · up to 5 MB · saved locally</small>
          </label>
        )}
        {documents.length ? (
          documents.map((doc) => (
            <div key={doc.id}>
              <span>
                <b>{doc.fileName}</b>
                <small>
                  {doc.docType} · {displayDate(doc.createdAt.slice(0, 10))}
                </small>
              </span>
              <a
                className="text-link"
                href={doc.dataUrl}
                target="_blank"
                rel="noreferrer"
                download={doc.fileName}
              >
                Open / download
              </a>
              {canManageDocuments && (
                <button
                  className="row-more"
                  onClick={() => void deleteDocument(doc.id!)}
                  aria-label={`Remove ${doc.fileName}`}
                >
                  <Trash2 size={15} />
                </button>
              )}
            </div>
          ))
        ) : (
          <TinyEmpty
            title="No documents saved"
            text="Add a birth certificate, previous report or other school document."
          />
        )}
      </div>
    );
  if (tab === "Timeline")
    return (
      <div className="timeline-list">
        {timeline.length ? (
          timeline.map((event) => (
            <div className="timeline-item" key={event.id}>
              <i />
              <span>
                <b>{event.title}</b>
                <small>
                  {displayDate(event.createdAt.slice(0, 10))} ·{" "}
                  {new Date(event.createdAt).toLocaleTimeString("en-IN", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}{" "}
                  · {event.username || "SchoolFlow"}
                </small>
                {event.details && <p>{event.details}</p>}
              </span>
            </div>
          ))
        ) : (
          <TinyEmpty
            title="No timeline events yet"
            text="Admission, status changes and documents will be noted here."
          />
        )}
      </div>
    );
  return (
    <TinyEmpty
      title="No profile section"
      text="Choose a student profile tab."
    />
  );
}

export function ClassesPage() {
  const classes = useClasses();
  const user = useAuth((state) => state.user);
  const canManageClasses = user?.role === "Admin" || user?.role === "Principal";
  const teachers =
    useLiveQuery(
      () =>
        db.teachers
          .filter((t) => !t.deletedAt && t.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const settings = useSettings();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<SchoolClass | null>(null);
  const [q, setQ] = useState("");
  const [draft, setDraft] = useState({
    name: "",
    section: "A",
    session: String(settings.academicSession || "2026-27"),
    room: "",
    teacherId: 0,
  });
  const [error, setError] = useState("");
  const openForm = (item?: SchoolClass) => {
    if (!canManageClasses) return;
    setEditing(item || null);
    setDraft(
      item
        ? {
            name: item.name,
            section: item.section,
            session: item.session,
            room: item.room || "",
            teacherId: item.teacherId || 0,
          }
        : {
            name: "",
            section: "A",
            session: String(settings.academicSession || "2026-27"),
            room: "",
            teacherId: 0,
          },
    );
    setError("");
    setOpen(true);
  };
  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!canManageClasses) {
      toast("Your role has view-only access to assigned classes.", "error");
      return;
    }
    const dup = classes.find(
      (c) =>
        c.name.trim().toLowerCase() === draft.name.trim().toLowerCase() &&
        c.section.trim().toLowerCase() === draft.section.trim().toLowerCase() &&
        c.session === draft.session &&
        c.id !== editing?.id,
    );
    if (dup) {
      setError("This class, section and session already exist.");
      return;
    }
    if (!draft.name.trim()) {
      setError("Class name is required.");
      return;
    }
    const now = new Date().toISOString();
    const data = {
      ...draft,
      name: draft.name.trim(),
      section: draft.section.trim().toUpperCase(),
      teacherId: Number(draft.teacherId) || undefined,
      status: "Active" as const,
      updatedAt: now,
      createdAt: editing?.createdAt || now,
    };
    try {
      if (editing) {
        await db.classes.update(editing.id!, data);
        await audit(currentUser(), "Updated", "Class", editing.id, draft.name);
      } else {
        const id = await db.classes.add(data);
        await audit(currentUser(), "Created", "Class", id, draft.name);
      }
      setOpen(false);
      toast(editing ? "Class updated." : "Class created.");
    } catch {
      toast("Could not save. Check for a duplicate class.", "error");
    }
  };
  const visible = classes
    .filter((c) =>
      [c.name, c.section, c.session, c.room || ""].some((v) =>
        v.toLowerCase().includes(q.toLowerCase()),
      ),
    )
    .sort(
      (a, b) =>
        a.name.localeCompare(b.name) || a.section.localeCompare(b.section),
    );
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="SCHOOL SETUP"
        title="Classes & sections"
        subtitle={
          canManageClasses
            ? "Build a clear class structure for admissions and daily attendance."
            : "View the classes assigned to your teacher account."
        }
        action={
          canManageClasses ? (
            <Button onClick={() => openForm()}>
              <Plus size={17} /> Add class
            </Button>
          ) : undefined
        }
      />
      <div className="callout callout-lavender">
        <span className="callout-icon">
          <BookOpenCheck size={17} />
        </span>
        <span>
          <b>One class, one section at a time.</b>
          <small>
            Students, attendance and fee plans stay scoped to the class and
            academic session you choose.
          </small>
        </span>
        <span className="callout-meta">{classes.length} active classes</span>
      </div>
      <Card className="list-card">
        <div className="list-toolbar">
          <SearchBox
            value={q}
            onChange={setQ}
            placeholder="Search class or section…"
          />
          <span className="row-count">{visible.length} classes</span>
        </div>
        {visible.length ? (
          <div className="class-grid">
            {visible.map((c) => (
              <div className="class-card" key={c.id}>
                <div className="class-card-top">
                  <span className="class-chip">{c.name}</span>
                  {canManageClasses && (
                    <button
                      className="row-more"
                      aria-label="Edit class"
                      onClick={() => openForm(c)}
                    >
                      <ArrowUpRight size={16} />
                    </button>
                  )}
                </div>
                <h3>Section {c.section}</h3>
                <p>{c.session} academic session</p>
                <div className="class-card-bottom">
                  <div className="class-room">
                    <span className="class-room-icon">
                      <Layers3 size={14} />
                    </span>
                    Room {c.room || "—"}
                  </div>
                  <div className="class-students-count">
                    <Users size={14} />
                    {classes.length ? "Manage roster" : ""}
                  </div>
                </div>
                <div className="class-teacher">
                  <Avatar
                    name={
                      teachers.find((t) => t.id === c.teacherId)?.name ||
                      "No teacher"
                    }
                    size="sm"
                  />
                  <span>
                    <small>CLASS TEACHER</small>
                    <b>
                      {teachers.find((t) => t.id === c.teacherId)?.name ||
                        "Not assigned"}
                    </b>
                  </span>
                  {canManageClasses && (
                    <button
                      onClick={() => openForm(c)}
                      aria-label="Set class teacher"
                    >
                      <ChevronDown size={14} />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            title={
              user?.role === "Teacher"
                ? "No classes assigned yet"
                : "No classes added yet"
            }
            text={
              user?.role === "Teacher"
                ? "Ask an Admin to link your teacher account to an active class."
                : "Create your first class and section to begin adding students."
            }
            icon={<BookOpenCheck size={22} />}
          />
        )}
      </Card>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? "Edit class details" : "Create a class"}
        subtitle="Keep the class, section and academic session consistent."
      >
        <form className="form-grid" onSubmit={save}>
          <Input
            label="Class name"
            placeholder="e.g. Class 1"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            required
          />
          <Input
            label="Section"
            placeholder="A"
            value={draft.section}
            onChange={(e) =>
              setDraft({ ...draft, section: e.target.value.toUpperCase() })
            }
            required
          />
          <Input
            label="Academic session"
            value={draft.session}
            onChange={(e) => setDraft({ ...draft, session: e.target.value })}
            required
          />
          <Input
            label="Room number"
            placeholder="Optional"
            value={draft.room}
            onChange={(e) => setDraft({ ...draft, room: e.target.value })}
          />
          <Select
            label="Class teacher"
            value={draft.teacherId || ""}
            onChange={(e) =>
              setDraft({ ...draft, teacherId: Number(e.target.value) })
            }
          >
            <option value="">Not assigned</option>
            {teachers.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} · {t.subject || "Teacher"}
              </option>
            ))}
          </Select>
          {error && <div className="form-alert full-span">{error}</div>}
          <div className="modal-actions full-span">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit">
              {editing ? "Save class" : "Create class"}
              <ArrowRight size={16} />
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

export function TeachersPage() {
  const teachers =
    useLiveQuery(
      () => db.teachers.filter((t) => !t.deletedAt).toArray(),
      [],
      [],
    ) || [];
  const classes = useClasses();
  const { toast } = useToast();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Teacher | null>(null);
  type TeacherDraft = Omit<Teacher, "id" | "deletedAt">;
  const empty = (): TeacherDraft => ({
    teacherId: `T-${String(teachers.length + 1).padStart(3, "0")}`,
    name: "",
    gender: "Female",
    subject: "",
    qualification: "",
    mobile: "",
    address: "",
    joiningDate: todayISO(),
    salary: 0,
    status: "Active",
  });
  const [draft, setDraft] = useState<TeacherDraft>(empty());
  const openForm = (t?: Teacher) => {
    setEditing(t || null);
    setDraft(
      t
        ? {
            teacherId: t.teacherId,
            name: t.name,
            gender: t.gender,
            subject: t.subject,
            qualification: t.qualification || "",
            mobile: t.mobile,
            address: t.address || "",
            joiningDate: t.joiningDate || todayISO(),
            salary: t.salary,
            status: t.status,
          }
        : { ...empty() },
    );
    setOpen(true);
  };
  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!draft.name.trim() || !validMobile(draft.mobile)) {
      toast(
        !draft.name.trim()
          ? "Teacher name is required."
          : "Enter a valid 10-digit mobile number.",
        "error",
      );
      return;
    }
    const data = { ...draft, salary: Number(draft.salary) || 0 };
    if (editing) await db.teachers.update(editing.id!, data);
    else await db.teachers.add(data);
    await audit(
      currentUser(),
      editing ? "Updated" : "Created",
      "Teacher",
      editing?.id,
      draft.name,
    );
    setOpen(false);
    toast(
      editing ? "Teacher profile updated." : "Teacher added to the directory.",
    );
  };
  const visible = teachers.filter((t) =>
    [t.name, t.teacherId, t.subject, t.mobile].some((x) =>
      (x || "").toLowerCase().includes(q.toLowerCase()),
    ),
  );
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="PEOPLE & STAFF"
        title="Teachers"
        subtitle="Keep your teaching team and class assignments in one place."
        action={
          <Button onClick={() => openForm()}>
            <Plus size={17} /> Add teacher
          </Button>
        }
      />
      <div className="student-kpis">
        <div className="student-kpi">
          <span className="kpi-icon lavender">
            <GraduationCap size={17} />
          </span>
          <span>
            <small>Total teachers</small>
            <b>{teachers.length}</b>
          </span>
        </div>
        <div className="student-kpi">
          <span className="kpi-icon mint">
            <CheckCircle2 size={17} />
          </span>
          <span>
            <small>Active</small>
            <b>{teachers.filter((t) => t.status === "Active").length}</b>
          </span>
        </div>
        <div className="student-kpi">
          <span className="kpi-icon peach">
            <BookOpenCheck size={17} />
          </span>
          <span>
            <small>Classes assigned</small>
            <b>{classes.filter((c) => c.teacherId).length}</b>
          </span>
        </div>
        <div className="student-kpi">
          <span className="kpi-caption">STAFF REGISTER</span>
          <b className="session-value">On this device</b>
        </div>
      </div>
      <Card className="list-card">
        <div className="list-toolbar">
          <SearchBox
            value={q}
            onChange={setQ}
            placeholder="Search teacher, ID or subject…"
          />
          <span className="row-count">{visible.length} teachers</span>
        </div>
        {visible.length ? (
          <TableWrap>
            <table className="data-table">
              <thead>
                <tr>
                  <th>TEACHER</th>
                  <th>TEACHER ID</th>
                  <th>SUBJECT</th>
                  <th>MOBILE</th>
                  <th>SALARY SUGGESTION</th>
                  <th>STATUS</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {visible.map((t) => (
                  <tr key={t.id}>
                    <td>
                      <div className="student-cell">
                        <Avatar name={t.name} />
                        <span>
                          <b>{t.name}</b>
                          <small>{t.qualification || t.gender}</small>
                        </span>
                      </div>
                    </td>
                    <td className="mono">{t.teacherId}</td>
                    <td>{t.subject || "—"}</td>
                    <td>{t.mobile}</td>
                    <td>{money(t.salary)}</td>
                    <td>
                      <Badge tone={makeTone(t.status)}>{t.status}</Badge>
                    </td>
                    <td>
                      <button
                        className="row-more"
                        onClick={() => openForm(t)}
                        aria-label={`Edit ${t.name}`}
                      >
                        <ArrowUpRight size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        ) : (
          <EmptyState
            title="No teachers in the directory"
            text="Abhi koi teacher add nahi hua — “Add teacher” dabayein."
            icon={<GraduationCap size={22} />}
          />
        )}
      </Card>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? "Edit teacher" : "Add a teacher"}
        subtitle="Staff contact details and salary can be used for payroll later."
      >
        <form className="form-grid" onSubmit={save}>
          <Input
            label="Teacher ID"
            value={draft.teacherId}
            onChange={(e) => setDraft({ ...draft, teacherId: e.target.value })}
            required
          />
          <Input
            label="Full name"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            required
          />
          <Input
            label="Subject"
            value={draft.subject}
            onChange={(e) => setDraft({ ...draft, subject: e.target.value })}
            placeholder="e.g. Mathematics"
          />
          <Select
            label="Gender"
            value={draft.gender}
            onChange={(e) => setDraft({ ...draft, gender: e.target.value })}
          >
            <option>Female</option>
            <option>Male</option>
            <option>Other</option>
          </Select>
          <Input
            label="Qualification"
            value={draft.qualification}
            onChange={(e) =>
              setDraft({ ...draft, qualification: e.target.value })
            }
          />
          <Input
            label="Mobile"
            value={draft.mobile}
            onChange={(e) =>
              setDraft({
                ...draft,
                mobile: e.target.value.replace(/\D/g, "").slice(0, 10),
              })
            }
            inputMode="numeric"
            required
          />
          <Input
            label="Joining date"
            type="date"
            value={draft.joiningDate}
            onChange={(e) =>
              setDraft({ ...draft, joiningDate: e.target.value })
            }
          />
          <Input
            label="Monthly salary"
            type="number"
            min="0"
            value={draft.salary}
            onChange={(e) =>
              setDraft({ ...draft, salary: Number(e.target.value) })
            }
          />
          <Textarea
            label="Address"
            value={draft.address}
            onChange={(e) => setDraft({ ...draft, address: e.target.value })}
            className="full-span"
            rows={2}
          />
          <div className="modal-actions full-span">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit">
              Save teacher
              <ArrowRight size={16} />
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

export function AttendancePage() {
  const classes = useClasses();
  const settings = useSettings();
  const students =
    useLiveQuery(
      () =>
        db.students
          .filter((s) => !s.deletedAt && s.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const { toast } = useToast();
  const [classKey, setClassKey] = useState("");
  const [date, setDate] = useState(todayISO());
  const [statuses, setStatuses] = useState<Record<number, AttendanceStatus>>(
    {},
  );
  const [remarks, setRemarks] = useState<Record<number, string>>({});
  const [saving, setSaving] = useState(false);
  const [absentGuardianOpen, setAbsentGuardianOpen] = useState(false);
  useEffect(() => {
    if (!classKey && classes[0])
      setClassKey(
        `${classes[0].id}|${classes[0].section}|${classes[0].session}`,
      );
  }, [classes, classKey]);
  const [classIdStr, section, session] = classKey.split("|");
  const classId = Number(classIdStr);
  const selectedClass = classes.find(
    (c) => c.id === classId && c.section === section && c.session === session,
  );
  const classStudents = students
    .filter(
      (s) =>
        s.classId === classId && s.section === section && s.session === session,
    )
    .sort((a, b) => a.roll - b.roll || a.name.localeCompare(b.name));
  const dayEntries =
    useLiveQuery<Attendance[], Attendance[]>(
      () =>
        classId
          ? db.attendance
              .where("[classId+section+date]")
              .equals([classId, section, date])
              .toArray()
          : Promise.resolve([] as Attendance[]),
      [classId, section, date],
      [],
    ) || [];
  useEffect(() => {
    const next: Record<number, AttendanceStatus> = {};
    const note: Record<number, string> = {};
    for (const row of dayEntries) {
      next[row.studentId] = row.status;
      note[row.studentId] = row.remarks || "";
    }
    setStatuses(next);
    setRemarks(note);
  }, [classId, section, date, dayEntries]);
  const setAll = (status: AttendanceStatus) =>
    setStatuses(Object.fromEntries(classStudents.map((s) => [s.id!, status])));
  const save = async () => {
    if (!classStudents.length) {
      toast("Pehle is class mein students add karein.", "error");
      return;
    }
    setSaving(true);
    const now = new Date().toISOString();
    try {
      await db.transaction("rw", db.attendance, async () => {
        for (const s of classStudents) {
          const existing = await db.attendance
            .where("[studentId+date]")
            .equals([s.id!, date])
            .first();
          const data = {
            studentId: s.id!,
            classId,
            section,
            session,
            date,
            status: statuses[s.id!] || "Present",
            remarks: remarks[s.id!],
            updatedAt: now,
          };
          if (existing) await db.attendance.update(existing.id!, data);
          else await db.attendance.add(data);
        }
      });
      await audit(
        currentUser(),
        "Saved attendance",
        "Attendance",
        date,
        `${classStudents.length} students · ${selectedClass?.name}-${section}`,
      );
      toast(`Attendance saved for ${classStudents.length} students.`);
    } catch {
      toast("Attendance could not be saved.", "error");
    } finally {
      setSaving(false);
    }
  };
  const present = classStudents.filter(
    (s) => statuses[s.id!] && statuses[s.id!] !== "Absent",
  ).length;
  const absentStudents = classStudents.filter(
    (student) => statuses[student.id!] === "Absent",
  );
  const marked = Object.keys(statuses).length;
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="DAILY REGISTER"
        title="Attendance"
        subtitle="A quick, calm check-in for the whole class."
        action={
          <Link to="/attendance/summary" className="btn btn-secondary">
            <BarChart3 size={16} /> Monthly summary
          </Link>
        }
      />
      <Card className="attendance-control-card">
        <div className="attendance-control-top">
          <div>
            <span className="card-eyebrow">MARK ATTENDANCE</span>
            <h3>Choose your class</h3>
            <p>Students load only for the selected class and section.</p>
          </div>
          <div className="attendance-date">
            <CalendarDays size={16} />
            <span>TODAY</span>
          </div>
        </div>
        <div className="attendance-controls">
          <Select
            label="Class · section"
            value={classKey}
            onChange={(e) => setClassKey(e.target.value)}
          >
            <option value="">Select class</option>
            {classes.map((c) => (
              <option
                key={`${c.id}-${c.section}-${c.session}`}
                value={`${c.id}|${c.section}|${c.session}`}
              >
                {c.name} · {c.section} · {c.session}
              </option>
            ))}
          </Select>
          <Input
            label="Attendance date"
            type="date"
            value={date}
            max={todayISO()}
            onChange={(e) => setDate(e.target.value)}
          />
          <div className="attendance-count">
            <b>{classStudents.length}</b>
            <span>students loaded</span>
            <small>
              {selectedClass
                ? `${selectedClass.name} · ${section}`
                : "Choose a class"}
            </small>
          </div>
        </div>
      </Card>
      <Card className="attendance-list-card">
        <div className="attendance-list-head">
          <div>
            <div className="attendance-head-title">
              <h3>Class register</h3>
              {dayEntries.length > 0 && (
                <Badge tone="green">Saved · editable</Badge>
              )}
            </div>
            <p>
              {marked
                ? `${marked} marked · ${present} present / late`
                : "No attendance marked for this date yet."}
            </p>
          </div>
          <div className="bulk-actions">
            <Button size="sm" variant="soft" onClick={() => setAll("Present")}>
              <Check size={15} /> All present
            </Button>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => setAll("Absent")}
            >
              Reset / absent
            </Button>
            {absentStudents.length > 0 && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => setAbsentGuardianOpen(true)}
              >
                <MessageSquare size={14} /> Message absent guardians ·{" "}
                {absentStudents.length}
              </Button>
            )}
          </div>
        </div>
        {classStudents.length ? (
          <div className="attendance-student-list">
            {classStudents.map((s) => (
              <div className="attendance-student" key={s.id}>
                <div className="student-cell">
                  <Avatar name={s.name} photo={s.photo} />
                  <span>
                    <b>{s.name}</b>
                    <small>
                      Roll {s.roll} · {s.admissionNo}
                    </small>
                  </span>
                </div>
                <div className="attendance-mark-buttons">
                  {(["Present", "Absent", "Late"] as AttendanceStatus[]).map(
                    (st) => (
                      <button
                        key={st}
                        aria-label={`${st} for ${s.name}`}
                        onClick={() =>
                          setStatuses((prev) => ({ ...prev, [s.id!]: st }))
                        }
                        className={`mark-option mark-${st.toLowerCase()} ${statuses[s.id!] === st ? "selected" : ""}`}
                      >
                        {st === "Present" ? "P" : st === "Absent" ? "A" : "L"}
                        <span>{st}</span>
                      </button>
                    ),
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            title={
              classes.length
                ? "No students in this class yet"
                : "Set up your classes first"
            }
            text={
              classes.length
                ? "Abhi is section mein students nahi hain — Students se pehle add karein."
                : "Create a class, then add its student roster before taking attendance."
            }
            icon={<CalendarCheck size={23} />}
          />
        )}
        <div className="attendance-save-bar">
          <div className="attendance-saving-note">
            <ShieldCheck size={15} />
            <span>Saved locally on this device</span>
          </div>
          <Button
            onClick={() => void save()}
            disabled={saving || !classStudents.length}
          >
            {saving ? "Saving…" : "Save attendance"}
            <Check size={16} />
          </Button>
        </div>
      </Card>
      <div className="privacy-note">
        <CircleAlert size={15} />
        <span>
          Future dates are blocked. Re-saving a day updates existing entries
          instead of making duplicates.
        </span>
      </div>
      <Modal
        open={absentGuardianOpen}
        onClose={() => setAbsentGuardianOpen(false)}
        title="Message absent guardians"
        subtitle={`${absentStudents.length} student${absentStudents.length === 1 ? "" : "s"} marked absent · ${displayDate(date)}`}
        size="md"
      >
        {absentStudents.length ? (
          <div className="share-list">
            {absentStudents.map((student) => {
              const className = selectedClass
                ? `${selectedClass.name}-${student.section}`
                : "the selected class";
              const message = `Namaste ${student.father || "Parent"}, ${student.name} of ${className} was marked absent on ${displayDate(date)}. Please contact ${settings.schoolName || "the school"} if this is unexpected.`;
              return (
                <div key={student.id}>
                  <span>
                    <b>{student.father || "Guardian"}</b>
                    <small>
                      {student.name} · Roll {student.roll} ·{" "}
                      {student.admissionNo}
                    </small>
                  </span>
                  {isValidIndiaPhone(student.mobile) ? (
                    <a
                      className="btn btn-soft btn-sm"
                      href={smsHref(student.mobile, message)}
                      title="Open a prefilled SMS composer"
                      onClick={(event) =>
                        handlePhoneProtocol(
                          event,
                          "sms",
                          student.mobile,
                          message,
                          toast,
                        )
                      }
                    >
                      <MessageSquare size={14} /> Open SMS
                    </a>
                  ) : (
                    <Badge tone="amber">No valid mobile</Badge>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <EmptyState
            title="No absent students"
            text="Mark one or more students absent to prepare guardian messages."
            icon={<CheckCircle2 size={22} />}
          />
        )}
        <div className="privacy-note sms-composer-note">
          <CircleAlert size={15} />
          <span>
            SMS opens your device’s messaging composer. Confirm the recipient
            and message, then tap Send; nothing is sent automatically.
          </span>
        </div>
      </Modal>
    </div>
  );
}

export function AttendanceSummaryPage() {
  const classes = useClasses();
  const user = useAuth((state) => state.user);
  const allStudents =
    useLiveQuery(
      () =>
        db.students
          .filter((s) => !s.deletedAt && s.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const students =
    user?.role === "Teacher"
      ? allStudents.filter((student) =>
          classes.some(
            (schoolClass) =>
              schoolClass.id === student.classId &&
              schoolClass.section === student.section &&
              schoolClass.session === student.session,
          ),
        )
      : allStudents;
  const allRows = useLiveQuery(() => db.attendance.toArray(), [], []) || [];
  const rows =
    user?.role === "Teacher"
      ? allRows.filter((row) =>
          classes.some(
            (schoolClass) =>
              schoolClass.id === row.classId &&
              schoolClass.section === row.section &&
              schoolClass.session === row.session,
          ),
        )
      : allRows;
  const [classKey, setClassKey] = useState("all");
  const [month, setMonth] = useState(monthISO());
  const [q, setQ] = useState("");
  const [cid, sec] = classKey === "all" ? ["all", "all"] : classKey.split("|");
  const start = `${month}-01`;
  const filteredStudents = students.filter(
    (s) =>
      (cid === "all" || (s.classId === Number(cid) && s.section === sec)) &&
      s.name.toLowerCase().includes(q.toLowerCase()),
  );
  const monthRows = rows.filter((r) => r.date.startsWith(month));
  const summaries = filteredStudents.map((s) => {
    const own = monthRows.filter((r) => r.studentId === s.id);
    const present = own.filter((r) => r.status !== "Absent").length;
    const absent = own.filter((r) => r.status === "Absent").length;
    const late = own.filter((r) => r.status === "Late").length;
    const percent = own.length ? Math.round((present / own.length) * 100) : 0;
    return { student: s, present, absent, late, days: own.length, percent };
  });
  const exportCsv = () => {
    const text = csvString(
      summaries.map((r) => ({
        admission_number: r.student.admissionNo,
        student: r.student.name,
        class: r.student.classId,
        section: r.student.section,
        present: r.present,
        absent: r.absent,
        late: r.late,
        marked_days: r.days,
        attendance_percent: `${r.percent}%`,
      })),
    );
    saveFile(new Blob([text], { type: "text/csv" }), `attendance-${month}.csv`);
  };
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="ATTENDANCE INSIGHTS"
        title="Monthly summary"
        subtitle="Review marked days, spot low attendance and export a class register."
        action={
          <Button variant="secondary" onClick={exportCsv}>
            <Download size={16} /> Export CSV
          </Button>
        }
      />
      <div className="summary-hero">
        <div>
          <span className="card-eyebrow">
            CLASS ATTENDANCE · {displayMonth(month).toUpperCase()}
          </span>
          <h2>
            {monthRows.length
              ? `${Math.round((monthRows.filter((r) => r.status !== "Absent").length / monthRows.length) * 100)}%`
              : "—"}
          </h2>
          <p>Average across saved attendance entries</p>
        </div>
        <div className="summary-hero-stats">
          <div>
            <b>
              {numberIN(monthRows.filter((r) => r.status === "Present").length)}
            </b>
            <small>Present</small>
          </div>
          <div>
            <b>
              {numberIN(monthRows.filter((r) => r.status === "Absent").length)}
            </b>
            <small>Absent</small>
          </div>
          <div>
            <b>
              {numberIN(monthRows.filter((r) => r.status === "Late").length)}
            </b>
            <small>Late</small>
          </div>
        </div>
        <div className="summary-orb" />
      </div>
      <Card className="list-card">
        <div className="list-toolbar">
          <div className="list-toolbar-left">
            <SearchBox
              value={q}
              onChange={setQ}
              placeholder="Search student…"
            />
            <Select
              value={classKey}
              onChange={(e) => setClassKey(e.target.value)}
            >
              <option value="all">
                {user?.role === "Teacher"
                  ? "All assigned classes"
                  : "All classes"}
              </option>
              {classes.map((c) => (
                <option key={c.id} value={`${c.id}|${c.section}`}>
                  {c.name} · {c.section}
                </option>
              ))}
            </Select>
            <Input
              type="month"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
            />
          </div>
          <span className="row-count">{summaries.length} students</span>
        </div>
        {summaries.length ? (
          <TableWrap>
            <table className="data-table">
              <thead>
                <tr>
                  <th>STUDENT</th>
                  <th>MARKED DAYS</th>
                  <th>PRESENT</th>
                  <th>ABSENT</th>
                  <th>LATE</th>
                  <th>ATTENDANCE</th>
                </tr>
              </thead>
              <tbody>
                {summaries.map((r) => (
                  <tr key={r.student.id}>
                    <td>
                      <div className="student-cell">
                        <Avatar
                          name={r.student.name}
                          photo={r.student.photo}
                          size="sm"
                        />
                        <span>
                          <b>{r.student.name}</b>
                          <small>{r.student.admissionNo}</small>
                        </span>
                      </div>
                    </td>
                    <td>{r.days}</td>
                    <td className="text-green">{r.present}</td>
                    <td className="text-rose">{r.absent}</td>
                    <td>{r.late}</td>
                    <td>
                      <div className="percent-cell">
                        <div className="percent-track">
                          <i
                            style={{ width: `${r.percent}%` }}
                            className={r.percent < 75 ? "low" : ""}
                          />
                        </div>
                        <Badge tone={r.percent < 75 ? "rose" : "green"}>
                          {r.days ? `${r.percent}%` : "—"}
                        </Badge>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        ) : (
          <EmptyState
            title="No student records yet"
            text="Student-wise attendance will appear once records are saved."
          />
        )}
      </Card>
    </div>
  );
}

export function FeesPage() {
  const classes = useClasses();
  const students =
    useLiveQuery(
      () =>
        db.students
          .filter((s) => !s.deletedAt && s.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const dues = useLiveQuery(() => db.feeDues.toArray(), [], []) || [];
  const structures =
    useLiveQuery(() => db.feeStructures.toArray(), [], []) || [];
  const routes = useLiveQuery(() => db.transportRoutes.toArray(), [], []) || [];
  const payments = useLiveQuery(() => db.feePayments.toArray(), [], []) || [];
  const settings = useSettings();
  const { toast } = useToast();
  const [studentId, setStudentId] = useState(0);
  const [month, setMonth] = useState(
    String(settings.defaultFeeMonth || monthISO()),
  );
  const [amount, setAmount] = useState("");
  const [mode, setMode] = useState("Cash");
  const [remarks, setRemarks] = useState("");
  const [discount, setDiscount] = useState("0");
  const [fine, setFine] = useState("0");
  const [busy, setBusy] = useState(false);
  const [receipt, setReceipt] = useState<{
    due: FeeDue;
    payment: any;
    student: Student;
  } | null>(null);
  useEffect(() => {
    if (!studentId && students[0]) setStudentId(students[0].id!);
  }, [students, studentId]);
  const student = students.find((s) => s.id === studentId);
  const structure = structures.find(
    (f) =>
      f.classId === student?.classId &&
      f.section === student?.section &&
      f.session === student?.session,
  );
  const due = dues.find(
    (d) =>
      d.studentId === studentId &&
      d.session === student?.session &&
      d.month === month,
  );
  const currentFeeHeads =
    student && structure
      ? feeHeadsForStudent(student, structure, routes)
      : undefined;
  const baseTotal = due
    ? roundMoney(
        due.tuition +
          due.transport +
          due.exam +
          due.admission +
          due.library +
          due.other,
      )
    : currentFeeHeads
      ? totalFeeHeads(currentFeeHeads)
      : 0;
  const balance = roundMoney(
    Math.max(
      0,
      baseTotal -
        (Number(discount) || 0) +
        (Number(fine) || 0) -
        (due?.paid || 0),
    ),
  );
  useEffect(() => {
    setAmount(balance ? String(balance) : "");
    setDiscount(String(due?.discount || "0"));
    setFine(String(due?.fine || "0"));
  }, [studentId, month, due?.id, due?.balance, baseTotal]);
  const currentPayments = payments.filter(
    (p) => p.paidAt.slice(0, 7) === monthISO(),
  );
  const todayTotal = currentPayments.reduce((a, p) => a + p.amount, 0);
  const [search, setSearch] = useState("");
  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!student) {
      toast("Select a student first.", "error");
      return;
    }
    const pay = roundMoney(Number(amount));
    const discountValue = Number(discount || 0);
    const fineValue = Number(fine || 0);
    if (
      !Number.isFinite(discountValue) ||
      !Number.isFinite(fineValue) ||
      discountValue < 0 ||
      fineValue < 0
    ) {
      toast("Discount and fine must be valid non-negative amounts.", "error");
      return;
    }
    if (pay <= 0) {
      toast("Payment amount must be greater than zero.", "error");
      return;
    }
    const heads = due
      ? {
          tuition: due.tuition,
          transport: due.transport,
          exam: due.exam,
          admission: due.admission,
          library: due.library,
          other: due.other,
        }
      : currentFeeHeads || {
          tuition: 0,
          transport: 0,
          exam: 0,
          admission: 0,
          library: 0,
          other: 0,
        };
    const totalDue = roundMoney(
      Object.values(heads).reduce((a, b) => a + b, 0) -
        discountValue +
        fineValue,
    );
    const adjustedBalance = roundMoney(
      Math.max(0, totalDue - (due?.paid || 0)),
    );
    if (totalDue <= 0) {
      toast("Discount cannot reduce the fee to zero or below.", "error");
      return;
    }
    if (pay > adjustedBalance) {
      toast(
        "Payment cannot be more than the outstanding balance after discount and fine.",
        "error",
      );
      return;
    }
    setBusy(true);
    try {
      let dueRow = due;
      const now = new Date().toISOString();
      if (!dueRow) {
        if (!structure) {
          toast("Create a fee plan before collecting this fee.", "error");
          return;
        }
        const dueId = await db.feeDues.add({
          studentId,
          session: student.session,
          month,
          ...heads,
          discount: discountValue,
          fine: fineValue,
          total: totalDue,
          paid: 0,
          balance: totalDue,
          status: "Pending",
          createdAt: now,
          updatedAt: now,
        });
        dueRow = await db.feeDues.get(dueId);
      } else if (
        discountValue !== dueRow.discount ||
        fineValue !== dueRow.fine
      ) {
        await db.feeDues.update(dueRow.id!, {
          discount: discountValue,
          fine: fineValue,
          total: totalDue,
          balance: adjustedBalance,
          status:
            adjustedBalance === 0
              ? "Paid"
              : dueRow.paid
                ? "Partial"
                : "Pending",
          updatedAt: now,
        });
        dueRow = await db.feeDues.get(dueRow.id!);
      }
      const recent = await db.feePayments.toArray();
      const prefix = `RCPT-${now.slice(0, 4)}${now.slice(5, 7)}-`;
      const count =
        recent.filter((p) => p.receiptNo.startsWith(prefix)).length + 1;
      const receiptNo = `${prefix}${String(count).padStart(4, "0")}`;
      const payment = {
        receiptNo,
        dueId: dueRow!.id!,
        studentId,
        amount: pay,
        mode,
        paidAt: now,
        remarks,
      };
      await db.transaction("rw", db.feeDues, db.feePayments, async () => {
        await db.feePayments.add(payment);
        const paid = roundMoney(dueRow!.paid + pay);
        const newBalance = roundMoney(Math.max(0, dueRow!.total - paid));
        await db.feeDues.update(dueRow!.id!, {
          paid,
          balance: newBalance,
          status: newBalance === 0 ? "Paid" : "Partial",
          updatedAt: now,
        });
      });
      await audit(
        currentUser(),
        "Collected fee",
        "Fee",
        receiptNo,
        `${student.name} · ${money(pay)} · ${mode}`,
      );
      const latest = await db.feeDues.get(dueRow!.id!);
      setReceipt({ due: latest!, payment, student });
      toast(`Fee collected. Receipt ${receiptNo} is ready.`);
      setAmount("");
      setRemarks("");
    } catch (err) {
      toast(
        err instanceof Error ? err.message : "Fee payment could not be saved.",
        "error",
      );
    } finally {
      setBusy(false);
    }
  };
  const visibleStudents = students.filter((s) =>
    [s.name, s.admissionNo, s.father].some((v) =>
      (v || "").toLowerCase().includes(search.toLowerCase()),
    ),
  );
  const currentMonthDue = dues.filter((d) => d.month === month);
  const dueCount = dues.filter((d) => d.balance > 0).length;
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="SCHOOL FINANCE"
        title="Fee collection"
        subtitle="A clear fee desk for every student and every receipt."
        action={
          <Link to="/fees/structure" className="btn btn-secondary">
            <Layers3 size={16} /> Fee structures
          </Link>
        }
      />
      <div className="finance-summary">
        <div className="finance-summary-copy">
          <span className="card-eyebrow">COLLECTION SNAPSHOT</span>
          <h2>{money(todayTotal)}</h2>
          <p>
            Collected this month · {currentPayments.length} receipt
            {currentPayments.length === 1 ? "" : "s"}
          </p>
          <div className="finance-summary-links">
            <Link to="/fees/pending">
              View pending dues <ArrowRight size={14} />
            </Link>
            <Link to="/demand-bills">
              Generate demand bills <ArrowRight size={14} />
            </Link>
          </div>
        </div>
        <div className="finance-summary-stats">
          <div>
            <span>Due entries</span>
            <b>{currentMonthDue.length}</b>
            <small>in {displayMonth(month)}</small>
          </div>
          <div>
            <span>Need follow-up</span>
            <b>{dueCount}</b>
            <small>pending balances</small>
          </div>
          <div className="finance-wave">
            <span>₹</span>
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
            <i />
          </div>
        </div>
      </div>
      <div className="fee-workspace">
        <Card className="collect-card">
          <div className="collect-card-head">
            <div className="collect-icon">
              <BadgeIndianRupee size={21} />
            </div>
            <div>
              <h3>Record a payment</h3>
              <p>Choose a student to view the current monthly fee balance.</p>
            </div>
            <span className="offline-mini">
              <span />
              LOCAL
            </span>
          </div>
          <form className="fee-form" onSubmit={save}>
            <div className="fee-student-search">
              <SearchBox
                value={search}
                onChange={setSearch}
                placeholder="Search student by name or admission no…"
              />
              <Select
                label="Student"
                value={studentId || ""}
                required
                onChange={(e) => setStudentId(Number(e.target.value))}
              >
                <option value="">Select a student</option>
                {visibleStudents.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} · {s.admissionNo} ·{" "}
                    {classes.find((c) => c.id === s.classId)?.name || "Class"}-
                    {s.section}
                  </option>
                ))}
              </Select>
            </div>
            {student ? (
              <>
                <div className="selected-student-bar">
                  <Avatar name={student.name} photo={student.photo} />
                  <span>
                    <b>{student.name}</b>
                    <small>
                      {classes.find((c) => c.id === student.classId)?.name ||
                        "Class"}{" "}
                      · {student.section} · Roll {student.roll}
                    </small>
                  </span>
                  <Badge tone="violet">{student.admissionNo}</Badge>
                </div>
                <div className="fee-fields-row">
                  <Input
                    label="Fee month"
                    type="month"
                    value={month}
                    onChange={(e) => setMonth(e.target.value)}
                  />
                  <Select
                    label="Payment mode"
                    value={mode}
                    onChange={(e) => setMode(e.target.value)}
                  >
                    <option>Cash</option>
                    <option>UPI</option>
                    <option>Card</option>
                    <option>Cheque</option>
                    <option>Online</option>
                  </Select>
                </div>
                <div className="fee-head-breakdown">
                  <div className="breakdown-heading">
                    <b>Fee breakdown</b>
                    <span>{due ? "Existing due" : "From fee structure"}</span>
                  </div>
                  {due ? (
                    <>
                      <div>
                        <span>Original total</span>
                        <b>{money(due.total)}</b>
                      </div>
                      <div>
                        <span>Already paid</span>
                        <b className="text-green">− {money(due.paid)}</b>
                      </div>
                      <div className="breakdown-total">
                        <span>Current balance</span>
                        <b>{money(balance)}</b>
                      </div>
                    </>
                  ) : structure ? (
                    <>
                      <div>
                        <span>Tuition + other fee heads</span>
                        <b>{money(structure.total)}</b>
                      </div>
                      <div className="breakdown-total">
                        <span>Fee structure total</span>
                        <b>{money(structure.total)}</b>
                      </div>
                    </>
                  ) : (
                    <div className="breakdown-warning">
                      <CircleAlert size={15} />
                      <span>No fee plan found for this class.</span>
                      <Link to="/fees/structure">Add a fee plan</Link>
                    </div>
                  )}
                </div>
                <div className="fee-fields-row">
                  <Input
                    label="Discount (₹)"
                    type="number"
                    min="0"
                    step="0.01"
                    value={discount}
                    onChange={(e) => setDiscount(e.target.value)}
                  />
                  <Input
                    label="Fine (₹)"
                    type="number"
                    min="0"
                    step="0.01"
                    value={fine}
                    onChange={(e) => setFine(e.target.value)}
                  />
                </div>
                <Input
                  label="Amount received (₹)"
                  type="number"
                  min="0.01"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  required
                  hint={`Outstanding balance: ${money(balance)}`}
                />
                <Textarea
                  label="Remarks (optional)"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  rows={2}
                  placeholder="Add a short payment note"
                />
                <Button
                  type="submit"
                  size="lg"
                  className="collect-submit"
                  disabled={busy || !Number(amount) || (!due && !structure)}
                >
                  {busy ? (
                    "Saving payment…"
                  ) : (
                    <>
                      Collect {money(Number(amount) || 0)}{" "}
                      <ArrowRight size={17} />
                    </>
                  )}
                </Button>
              </>
            ) : (
              <div className="fee-empty-prompt">
                <div className="fee-empty-icon">
                  <Users size={24} />
                </div>
                <b>Select a student to begin</b>
                <span>Saved students will appear in the list.</span>
                {!students.length && (
                  <Link to="/students/new" className="text-link">
                    Add your first student <ArrowRight size={14} />
                  </Link>
                )}
              </div>
            )}
          </form>
        </Card>
        <div className="fee-side-stack">
          <Card className="fee-side-card">
            <div className="card-head">
              <div>
                <span className="card-eyebrow">RECENT ACTIVITY</span>
                <h3>Latest receipts</h3>
              </div>
              <span className="recent-icon">
                <Clock3 size={15} />
              </span>
            </div>
            {payments.length ? (
              payments
                .slice()
                .sort((a, b) => b.paidAt.localeCompare(a.paidAt))
                .slice(0, 5)
                .map((p) => {
                  const st = students.find((s) => s.id === p.studentId);
                  return (
                    <div className="receipt-row" key={p.id}>
                      <span className="receipt-avatar">
                        {st?.name[0] || "S"}
                      </span>
                      <span>
                        <b>{st?.name || "Student"}</b>
                        <small>
                          {p.receiptNo} · {p.mode}
                        </small>
                      </span>
                      <strong>{money(p.amount)}</strong>
                    </div>
                  );
                })
            ) : (
              <TinyEmpty
                title="No receipts yet"
                text="Your recent fee payments will appear here."
              />
            )}
            <Link to="/reports" className="overview-footer">
              Open fee ledger <ArrowRight size={15} />
            </Link>
          </Card>
          <Card className="fee-help-card">
            <span className="fee-help-icon">
              <Sparkles size={17} />
            </span>
            <div>
              <b>Good to know</b>
              <p>
                Partial payments update the outstanding balance. Every receipt
                number is unique and never reused.
              </p>
            </div>
            <Link to="/backup" aria-label="Backup">
              <ArrowUpRight size={15} />
            </Link>
          </Card>
        </div>
      </div>
      <div className="privacy-note">
        <ShieldCheck size={15} />
        <span>
          Payments save to this device first. Export a backup regularly to
          protect your records.
        </span>
        <Link to="/backup">
          Back up now <ArrowRight size={13} />
        </Link>
      </div>
      <ReceiptModal
        data={receipt}
        school={printSchoolFromSettings(settings)}
        className={
          receipt
            ? classes.find((c) => c.id === receipt.student.classId)?.name ||
              String(receipt.student.classId)
            : "Class"
        }
        onClose={() => setReceipt(null)}
      />
    </div>
  );
}
function ReceiptModal({
  data,
  school,
  className,
  onClose,
}: {
  data: { due: FeeDue; payment: any; student: Student } | null;
  school: PrintSchool;
  className: string;
  onClose: () => void;
}) {
  const { toast } = useToast();
  if (!data) return null;
  const { due, payment, student } = data;
  const heads = [
    ["Tuition", due.tuition],
    ["Transport", due.transport],
    ["Exam", due.exam],
    ["Admission", due.admission],
    ["Library", due.library],
    ["Other", due.other],
  ].filter(([, amount]) => Number(amount) > 0) as [string, number][];
  const print = (paper: "A4" | "thermal") =>
    printFeeReceipt({ due, payment, student, className }, school, paper);
  const hasPhone = isValidIndiaPhone(student.mobile);
  const whatsappText = `Namaste ${student.father || "Parent"}, fee receipt ${payment.receiptNo} for ${student.name}: received ${money(payment.amount)} by ${payment.mode}; remaining balance ${money(due.balance)}. Thank you.`;
  return (
    <Modal
      open={!!data}
      onClose={onClose}
      title="Payment received"
      subtitle={`Receipt ${payment.receiptNo} · Choose A4 or 80mm thermal print.`}
      size="md"
    >
      <div className="receipt-preview print-area">
        <div className="receipt-brand">
          {school.logo && <img src={school.logo} alt="School logo" />}
          {school.name || "School"}
        </div>
        {(school.address || school.phone) && (
          <div className="receipt-school-contact">
            {[school.address, school.phone].filter(Boolean).join(" · ")}
          </div>
        )}
        <div className="receipt-label">
          FEE RECEIPT <span>ORIGINAL</span>
        </div>
        <div className="receipt-no-row">
          <span>Receipt number</span>
          <b>{payment.receiptNo}</b>
        </div>
        <div className="receipt-no-row">
          <span>Payment date</span>
          <b>{displayDate(payment.paidAt.slice(0, 10))}</b>
        </div>
        <div className="receipt-student">
          <Avatar name={student.name} photo={student.photo} size="sm" />
          <span>
            <b>{student.name}</b>
            <small>
              {student.admissionNo} · {className}-{student.section} · Roll{" "}
              {student.roll}
            </small>
          </span>
        </div>
        <div className="receipt-no-row">
          <span>Fee month</span>
          <b>
            {displayMonth(due.month)} · {due.session}
          </b>
        </div>
        <div className="receipt-breakdown">
          <b>Fee heads</b>
          {heads.map(([label, amount]) => (
            <div key={label}>
              <span>{label}</span>
              <b>{money(amount)}</b>
            </div>
          ))}
          <div>
            <span>Discount</span>
            <b>− {money(due.discount)}</b>
          </div>
          <div>
            <span>Fine</span>
            <b>+ {money(due.fine)}</b>
          </div>
          <div className="receipt-breakdown-total">
            <span>Total due</span>
            <b>{money(due.total)}</b>
          </div>
        </div>
        <div className="receipt-no-row">
          <span>Total paid to date</span>
          <b>{money(due.paid)}</b>
        </div>
        <div className="receipt-amount">
          <span>Received · {payment.mode}</span>
          <b>{money(payment.amount)}</b>
        </div>
        <div className="receipt-words">{amountToWords(payment.amount)}</div>
        <div className="receipt-balance">
          <span>Remaining balance</span>
          <b>{money(due.balance)}</b>
        </div>
        {payment.remarks && (
          <div className="receipt-no-row">
            <span>Remarks</span>
            <b>{payment.remarks}</b>
          </div>
        )}
        <div className="receipt-footer">
          <span>{school.receiptFooter || "Thank you for your payment."}</span>
          <i>Authorised signature</i>
        </div>
      </div>
      <div className="modal-actions receipt-actions">
        <Button variant="secondary" onClick={onClose}>
          Done
        </Button>
        <Button variant="outline" onClick={() => print("A4")}>
          <Printer size={15} /> A4
        </Button>
        <Button onClick={() => print("thermal")}>
          <Printer size={15} /> 80mm thermal
        </Button>
        {hasPhone && (
          <>
            <a
              className="btn btn-soft"
              href={whatsappHref(student.mobile, whatsappText)}
            >
              <MessageCircle size={14} /> WhatsApp
            </a>
            <a
              className="btn btn-secondary"
              href={smsHref(student.mobile, whatsappText)}
              title="SMS fallback; opens a prefilled composer"
              onClick={(event) =>
                handlePhoneProtocol(
                  event,
                  "sms",
                  student.mobile,
                  whatsappText,
                  toast,
                )
              }
            >
              <MessageSquare size={14} /> SMS
            </a>
          </>
        )}
      </div>
    </Modal>
  );
}

export function FeeStructurePage() {
  const classes = useClasses();
  const structures =
    useLiveQuery(() => db.feeStructures.toArray(), [], []) || [];
  const students =
    useLiveQuery(
      () =>
        db.students
          .filter((s) => !s.deletedAt && s.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const dues = useLiveQuery(() => db.feeDues.toArray(), [], []) || [];
  const routes = useLiveQuery(() => db.transportRoutes.toArray(), [], []) || [];
  const settings = useSettings();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<FeeStructure | null>(null);
  const [draft, setDraft] = useState({
    classId: 0,
    section: "A",
    session: String(settings.academicSession || "2026-27"),
    tuition: 0,
    transport: 0,
    exam: 0,
    admission: 0,
    library: 0,
    other: 0,
  });
  const [genOpen, setGenOpen] = useState(false);
  const [genClass, setGenClass] = useState("all");
  const [genMonth, setGenMonth] = useState(monthISO());
  const [preview, setPreview] = useState(false);
  const [duplicateCount, setDuplicateCount] = useState(0);
  const total = roundMoney(
    draft.tuition +
      draft.transport +
      draft.exam +
      draft.admission +
      draft.library +
      draft.other,
  );
  const newDraft = () => ({
    classId: classes[0]?.id || 0,
    section: classes[0]?.section || "A",
    session: String(settings.academicSession || "2026-27"),
    tuition: 0,
    transport: 0,
    exam: 0,
    admission: 0,
    library: 0,
    other: 0,
  });
  const showForm = (f?: FeeStructure) => {
    setEditing(f || null);
    setDraft(
      f
        ? {
            classId: f.classId,
            section: f.section,
            session: f.session,
            tuition: f.tuition,
            transport: f.transport,
            exam: f.exam,
            admission: f.admission,
            library: f.library,
            other: f.other,
          }
        : newDraft(),
    );
    setOpen(true);
  };
  const copyForm = (f: FeeStructure) => {
    setEditing(null);
    setDraft({
      classId: 0,
      section: "A",
      session: String(settings.academicSession || f.session),
      tuition: f.tuition,
      transport: f.transport,
      exam: f.exam,
      admission: f.admission,
      library: f.library,
      other: f.other,
    });
    setOpen(true);
  };
  const save = async (e: FormEvent) => {
    e.preventDefault();
    const cls = classes.find((c) => c.id === draft.classId);
    if (!cls) {
      toast("Create a class before setting up a fee plan.", "error");
      return;
    }
    const duplicate = structures.find(
      (x) =>
        x.classId === cls.id &&
        x.section === cls.section &&
        x.session === draft.session &&
        x.id !== editing?.id,
    );
    if (duplicate) {
      toast(
        "A fee plan already exists for this class, section and session.",
        "error",
      );
      return;
    }
    const data = {
      ...draft,
      section: cls.section,
      total,
      status: "Active" as const,
    };
    if (editing) await db.feeStructures.update(editing.id!, data);
    else await db.feeStructures.add(data);
    await audit(
      currentUser(),
      editing ? "Updated" : "Created",
      "Fee structure",
      editing?.id,
      `${cls.name}-${cls.section}`,
    );
    setOpen(false);
    toast("Fee structure saved.");
  };
  const selectedStudents = students.filter(
    (s) => genClass === "all" || `${s.classId}-${s.section}` === genClass,
  );
  const previewRows = selectedStudents.map((s) => {
    const structure = structures.find(
      (f) =>
        f.classId === s.classId &&
        f.section === s.section &&
        f.session === s.session,
    );
    const heads = structure
      ? feeHeadsForStudent(s, structure, routes)
      : undefined;
    return {
      student: s,
      exists: dues.some(
        (d) =>
          d.studentId === s.id &&
          d.session === s.session &&
          d.month === genMonth,
      ),
      structure,
      heads,
      total: heads ? totalFeeHeads(heads) : 0,
    };
  });
  const prepare = () => {
    setDuplicateCount(previewRows.filter((r) => r.exists).length);
    setPreview(true);
  };
  const generate = async () => {
    const now = new Date().toISOString();
    const valid = previewRows.filter(
      (r) => !r.exists && r.structure && r.heads,
    );
    await db.transaction("rw", db.feeDues, async () => {
      for (const row of valid) {
        const { student: s } = row;
        const heads = row.heads!;
        const sum = totalFeeHeads(heads);
        await db.feeDues.add({
          studentId: s.id!,
          session: s.session,
          month: genMonth,
          ...heads,
          discount: 0,
          fine: 0,
          total: sum,
          paid: 0,
          balance: sum,
          status: "Pending",
          createdAt: now,
          updatedAt: now,
        });
      }
    });
    await audit(
      currentUser(),
      "Generated monthly dues",
      "Fee",
      genMonth,
      `${valid.length} records`,
    );
    toast(
      `${valid.length} monthly dues created. ${duplicateCount} existing records skipped.`,
    );
    setPreview(false);
    setGenOpen(false);
  };
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="FEE CONFIGURATION"
        title="Fee structures"
        subtitle="Set clear monthly fee heads for each class and academic session."
        action={
          <Button onClick={() => showForm()}>
            <Plus size={17} /> Add fee plan
          </Button>
        }
      />
      <div className="fee-structure-intro">
        <div className="intro-art">
          <WalletCards size={25} />
        </div>
        <div>
          <b>Make dues generation effortless.</b>
          <span>
            Define a fee plan once. Monthly dues will use these heads for every
            student in that class.
          </span>
        </div>
        <Button
          variant="soft"
          onClick={() => {
            setPreview(false);
            setGenOpen(true);
          }}
        >
          <CalendarDays size={15} /> Generate monthly dues
        </Button>
      </div>
      <Card className="list-card">
        <div className="card-list-head">
          <div>
            <h3>Fee plans by class</h3>
            <p>Amounts are stored in rupees and formatted for India.</p>
          </div>
          <span className="row-count">{structures.length} plans</span>
        </div>
        {structures.length ? (
          <div className="structure-grid">
            {structures.map((f) => {
              const cls = classes.find((c) => c.id === f.classId);
              return (
                <div className="structure-card" key={f.id}>
                  <div className="structure-top">
                    <span className="class-chip">
                      {cls?.name || "Class"} · {f.section}
                    </span>
                    <button
                      className="row-more"
                      onClick={() => showForm(f)}
                      aria-label="Edit fee plan"
                    >
                      <ArrowUpRight size={16} />
                    </button>
                  </div>
                  <small className="structure-session">
                    {f.session} session
                  </small>
                  <strong>
                    {money(f.total)}
                    <small> / month</small>
                  </strong>
                  <div className="structure-heads">
                    {[
                      ["Tuition", f.tuition],
                      ["Transport", f.transport],
                      ["Exam", f.exam],
                      ["Admission", f.admission],
                      ["Library", f.library],
                      ["Other", f.other],
                    ]
                      .filter(([, v]) => Number(v) > 0)
                      .map(([label, val]) => (
                        <span key={String(label)}>
                          {label}
                          <b>{money(Number(val))}</b>
                        </span>
                      ))}
                  </div>
                  <button
                    className="structure-edit"
                    onClick={() => showForm(f)}
                  >
                    Edit fee plan <ArrowRight size={14} />
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          <EmptyState
            title="No fee plans set up"
            text="Abhi fee structure nahi hai — “Add fee plan” dabayein."
            icon={<WalletCards size={22} />}
          />
        )}
      </Card>
      <div className="inline-advice">
        <span>✦</span>
        <div>
          <b>Already generated dues stay unchanged.</b>
          <small>
            Changes to a fee plan apply only to dues generated in the future.
          </small>
        </div>
      </div>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? "Edit fee plan" : "Create a fee plan"}
        subtitle="Amounts in this plan are used to generate student dues."
      >
        <form className="form-grid" onSubmit={save}>
          <Select
            label="Class and section"
            value={draft.classId || ""}
            onChange={(e) => {
              const c = classes.find((x) => x.id === Number(e.target.value));
              setDraft({
                ...draft,
                classId: Number(e.target.value),
                section: c?.section || "A",
              });
            }}
            required
          >
            <option value="">Select class</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} · {c.section}
              </option>
            ))}
          </Select>
          <Input
            label="Academic session"
            value={draft.session}
            onChange={(e) => setDraft({ ...draft, session: e.target.value })}
            required
          />
          <div className="form-section-label">MONTHLY FEE HEADS</div>
          {(
            [
              "tuition",
              "transport",
              "exam",
              "admission",
              "library",
              "other",
            ] as const
          ).map((head) => (
            <Input
              key={head}
              label={`${head[0].toUpperCase() + head.slice(1)} (₹)`}
              type="number"
              min="0"
              step="0.01"
              value={draft[head]}
              onChange={(e) =>
                setDraft({ ...draft, [head]: Number(e.target.value) })
              }
            />
          ))}
          <div className="fee-plan-total full-span">
            <span>Monthly total</span>
            <strong>{money(total)}</strong>
          </div>
          <div className="modal-actions full-span">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit">
              Save fee plan
              <ArrowRight size={16} />
            </Button>
          </div>
        </form>
      </Modal>
      <Modal
        open={genOpen}
        onClose={() => setGenOpen(false)}
        title={preview ? "Review monthly dues" : "Generate monthly dues"}
        subtitle={
          preview
            ? "Take a quick look before anything is saved."
            : "Existing dues for the same month are skipped."
        }
        size="lg"
      >
        {!preview ? (
          <div className="form-grid">
            <Select
              label="Class"
              value={genClass}
              onChange={(e) => setGenClass(e.target.value)}
            >
              <option value="all">All classes</option>
              {classes.map((c) => (
                <option key={c.id} value={`${c.id}-${c.section}`}>
                  {c.name} · {c.section}
                </option>
              ))}
            </Select>
            <Input
              label="Fee month"
              type="month"
              value={genMonth}
              onChange={(e) => setGenMonth(e.target.value)}
            />
            <div className="generation-preview-banner full-span">
              <div>
                <b>
                  {previewRows.filter((r) => !r.exists && r.structure).length}
                </b>
                <span>ready to generate</span>
              </div>
              <div>
                <b>{previewRows.filter((r) => r.exists).length}</b>
                <span>already exist</span>
              </div>
              <div>
                <b>{previewRows.filter((r) => !r.structure).length}</b>
                <span>missing fee plan</span>
              </div>
            </div>
            <p className="form-helper full-span">
              Preview includes {previewRows.length} active student records. No
              changes are made until you confirm.
            </p>
            <div className="modal-actions full-span">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setGenOpen(false)}
              >
                Cancel
              </Button>
              <Button type="button" onClick={prepare}>
                Preview dues <ArrowRight size={16} />
              </Button>
            </div>
          </div>
        ) : (
          <>
            <div className="preview-list">
              {previewRows.slice(0, 8).map((r) => (
                <div key={r.student.id}>
                  <span>
                    {r.student.name}
                    <small>
                      {classes.find((c) => c.id === r.student.classId)?.name}-
                      {r.student.section} · {r.student.admissionNo}
                    </small>
                  </span>
                  <span>
                    {r.exists ? (
                      <Badge tone="neutral">Already exists</Badge>
                    ) : r.structure ? (
                      <Badge tone="green">{money(r.total)}</Badge>
                    ) : (
                      <Badge tone="amber">Fee plan missing</Badge>
                    )}
                  </span>
                </div>
              ))}
            </div>
            <p className="form-helper">
              {duplicateCount} duplicates will be skipped.{" "}
              {previewRows.filter((r) => !r.exists && r.structure).length} dues
              will be created.
            </p>
            <div className="modal-actions">
              <Button variant="secondary" onClick={() => setPreview(false)}>
                Back
              </Button>
              <Button
                onClick={() => void generate()}
                disabled={!previewRows.some((r) => !r.exists && r.structure)}
              >
                Confirm and generate <Check size={16} />
              </Button>
            </div>
          </>
        )}
      </Modal>
    </div>
  );
}

export function PendingFeesPage() {
  const dues = useLiveQuery(() => db.feeDues.toArray(), [], []) || [];
  const students = useLiveQuery(() => db.students.toArray(), [], []) || [];
  const classes = useClasses();
  const settings = useSettings();
  const { toast } = useToast();
  const [q, setQ] = useState("");
  const [month, setMonth] = useState("all");
  const rows = dues
    .filter(
      (d) => d.balance > 0 && (!month || month === "all" || d.month === month),
    )
    .map((d) => ({
      due: d,
      student: students.find((s) => s.id === d.studentId),
    }))
    .filter(
      (r) =>
        r.student &&
        [
          r.student.name,
          r.student.admissionNo,
          r.student.father,
          r.student.mobile,
        ].some((v) => (v || "").toLowerCase().includes(q.toLowerCase())),
    )
    .sort((a, b) => b.due.balance - a.due.balance);
  const total = rows.reduce((a, r) => a + r.due.balance, 0);
  const exportRows = () =>
    saveFile(
      new Blob(
        [
          csvString(
            rows.map((r) => ({
              student: r.student?.name,
              admission_no: r.student?.admissionNo,
              class: classes.find((c) => c.id === r.student?.classId)?.name,
              section: r.student?.section,
              month: r.due.month,
              amount_due: r.due.total,
              paid: r.due.paid,
              balance: r.due.balance,
              status: r.due.status,
            })),
          ),
        ],
        { type: "text/csv" },
      ),
      `pending-fees-${todayISO()}.csv`,
    );
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="SCHOOL FINANCE"
        title="Pending fees"
        subtitle="See every outstanding balance and decide what needs a follow-up."
        action={
          <Button variant="secondary" onClick={exportRows}>
            <Download size={16} /> Export CSV
          </Button>
        }
      />
      <div className="pending-summary">
        <div>
          <span className="pending-icon">
            <Wallet size={19} />
          </span>
          <span>
            <small>OUTSTANDING BALANCE</small>
            <b>{money(total)}</b>
            <small>Across {rows.length} fee entries</small>
          </span>
        </div>
        <Link to="/fees">
          Collect a payment <ArrowRight size={15} />
        </Link>
      </div>
      <div className="privacy-note fee-reminder-note">
        <CircleAlert size={15} />
        <span>
          WhatsApp is the primary reminder. For guardians without WhatsApp, SMS
          opens a prefilled composer—review and tap Send; nothing is sent
          automatically.
        </span>
      </div>
      <Card className="list-card">
        <div className="list-toolbar">
          <div className="list-toolbar-left">
            <SearchBox
              value={q}
              onChange={setQ}
              placeholder="Search student or parent…"
            />
            <Select value={month} onChange={(e) => setMonth(e.target.value)}>
              <option value="all">All months</option>
              {Array.from(new Set(dues.map((d) => d.month)))
                .sort((a, b) => b.localeCompare(a))
                .map((m) => (
                  <option key={m} value={m}>
                    {displayMonth(m)}
                  </option>
                ))}
            </Select>
          </div>
          <span className="row-count">{rows.length} pending</span>
        </div>
        {rows.length ? (
          <TableWrap>
            <table className="data-table">
              <thead>
                <tr>
                  <th>STUDENT</th>
                  <th>CLASS</th>
                  <th>FEE MONTH</th>
                  <th>FEE TOTAL</th>
                  <th>PAID</th>
                  <th>BALANCE</th>
                  <th>STATUS</th>
                  <th>REMINDER</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(({ due, student }) => {
                  if (!student) return null;
                  const reminderMessage = `Namaste ${student.father || "Parent"}, this is a fee reminder from ${settings.schoolName || "the school"}. ${student.name} has an outstanding balance of ${money(due.balance)} for ${displayMonth(due.month)}. Please contact the school office if already paid. Thank you.`;
                  const phoneDisplay = isValidIndiaPhone(student.mobile)
                    ? `+${normalizeIndiaPhone(student.mobile)}`
                    : student.mobile || "No phone";
                  return (
                    <tr key={due.id}>
                      <td>
                        <div className="student-cell">
                          <Avatar name={student.name} size="sm" />
                          <span>
                            <b>{student.name}</b>
                            <small>
                              {student.admissionNo} · {phoneDisplay}
                            </small>
                          </span>
                        </div>
                      </td>
                      <td>
                        {classes.find((c) => c.id === student.classId)?.name ||
                          "Class"}{" "}
                        · {student.section}
                      </td>
                      <td>{displayMonth(due.month)}</td>
                      <td>{money(due.total)}</td>
                      <td className="text-green">{money(due.paid)}</td>
                      <td>
                        <b className="text-rose">{money(due.balance)}</b>
                      </td>
                      <td>
                        <Badge tone={makeTone(due.status)}>{due.status}</Badge>
                      </td>
                      <td>
                        {isValidIndiaPhone(student.mobile) ? (
                          <div className="fee-reminder-actions">
                            <a
                              className="btn btn-soft btn-sm"
                              href={whatsappHref(
                                student.mobile,
                                reminderMessage,
                              )}
                              title="Primary reminder via WhatsApp"
                            >
                              <MessageCircle size={13} /> WhatsApp
                            </a>
                            <a
                              className="btn btn-secondary btn-sm"
                              href={smsHref(student.mobile, reminderMessage)}
                              title="SMS fallback for guardians without WhatsApp; opens a prefilled composer"
                              onClick={(event) =>
                                handlePhoneProtocol(
                                  event,
                                  "sms",
                                  student.mobile,
                                  reminderMessage,
                                  toast,
                                )
                              }
                            >
                              <MessageSquare size={13} /> SMS
                            </a>
                          </div>
                        ) : (
                          <Badge tone="amber">No valid mobile</Badge>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </TableWrap>
        ) : (
          <EmptyState
            title="All caught up"
            text="No pending balances match this view. Great work!"
            icon={<CheckCircle2 size={22} />}
          />
        )}
      </Card>
    </div>
  );
}

export function FeeLedgerPage() {
  const payments =
    useLiveQuery(
      () => db.feePayments.orderBy("paidAt").reverse().toArray(),
      [],
      [],
    ) || [];
  const dues = useLiveQuery(() => db.feeDues.toArray(), [], []) || [];
  const students = useLiveQuery(() => db.students.toArray(), [], []) || [];
  const classes = useClasses();
  const settings = useSettings();
  const { toast } = useToast();
  const [query, setQuery] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [cancel, setCancel] = useState<{ id: number; reason: string } | null>(
    null,
  );
  const [receipt, setReceipt] = useState<{
    due: FeeDue;
    payment: any;
    student: Student;
  } | null>(null);
  const rows = payments
    .map((payment) => ({
      payment,
      due: dues.find((d) => d.id === payment.dueId),
      student: students.find((s) => s.id === payment.studentId),
    }))
    .filter(
      ({ payment, student }) =>
        (!from || payment.paidAt.slice(0, 10) >= from) &&
        (!to || payment.paidAt.slice(0, 10) <= to) &&
        [
          payment.receiptNo,
          student?.name,
          student?.admissionNo,
          student?.father,
          payment.mode,
        ].some((x) =>
          String(x || "")
            .toLowerCase()
            .includes(query.toLowerCase()),
        ),
    );
  const exportCsv = () =>
    saveFile(
      new Blob(
        [
          csvString(
            rows.map(({ payment, student, due }) => ({
              receipt: payment.receiptNo,
              student: student?.name,
              admission_no: student?.admissionNo,
              fee_month: due?.month,
              amount: payment.amount,
              mode: payment.mode,
              paid_at: payment.paidAt,
              status: payment.voidedAt ? "Voided" : "Paid",
              void_reason: payment.voidReason || "",
            })),
          ),
        ],
        { type: "text/csv" },
      ),
      `fee-ledger-${todayISO()}.csv`,
    );
  const reversePayment = async () => {
    if (!cancel || !cancel.reason.trim()) {
      toast("A reason is required to reverse a receipt.", "error");
      return;
    }
    const payment = payments.find((p) => p.id === cancel.id);
    const due = payment && dues.find((d) => d.id === payment.dueId);
    if (!payment || !due || payment.voidedAt) {
      toast("This receipt cannot be reversed again.", "error");
      setCancel(null);
      return;
    }
    const now = new Date().toISOString();
    try {
      await db.transaction(
        "rw",
        db.feePayments,
        db.feeDues,
        db.familyBills,
        async () => {
          const paid = roundMoney(Math.max(0, due.paid - payment.amount));
          const balance = roundMoney(Math.max(0, due.total - paid));
          await db.feePayments.update(payment.id!, {
            voidedAt: now,
            voidReason: cancel.reason.trim(),
          });
          await db.feeDues.update(due.id!, {
            paid,
            balance,
            status: balance === 0 ? "Paid" : paid > 0 ? "Partial" : "Pending",
            updatedAt: now,
          });
          if (payment.familyBillNo) {
            const bill = await db.familyBills
              .where("billNo")
              .equals(payment.familyBillNo)
              .first();
            if (bill) {
              const billPaid = roundMoney(
                Math.max(0, bill.paid - payment.amount),
              );
              await db.familyBills.update(bill.id!, {
                paid: billPaid,
                balance: roundMoney(Math.max(0, bill.total - billPaid)),
                status:
                  billPaid >= bill.total
                    ? "Paid"
                    : billPaid > 0
                      ? "Partial"
                      : "Pending",
                updatedAt: now,
              });
            }
          }
        },
      );
      await audit(
        currentUser(),
        "Reversed fee receipt",
        "Fee payment",
        payment.receiptNo,
        cancel.reason,
        payment,
        { ...payment, voidedAt: now, voidReason: cancel.reason },
      );
      toast(
        `Receipt ${payment.receiptNo} reversed. The receipt number remains in the ledger.`,
      );
      setCancel(null);
    } catch (error) {
      toast(
        error instanceof Error ? error.message : "Receipt reversal failed.",
        "error",
      );
    }
  };
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="FINANCE REGISTER"
        title="Fee ledger"
        subtitle="Every receipt stays traceable, including reversals."
        action={
          <Button variant="secondary" onClick={exportCsv}>
            <Download size={16} /> Export CSV
          </Button>
        }
      />
      <Card className="list-card">
        <div className="list-toolbar">
          <div className="list-toolbar-left">
            <SearchBox
              value={query}
              onChange={setQuery}
              placeholder="Search receipt, student or parent…"
            />
            <Input
              type="date"
              aria-label="From date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
            />
            <Input
              type="date"
              aria-label="To date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
            />
          </div>
          <span className="row-count">{rows.length} receipts</span>
        </div>
        {rows.length ? (
          <TableWrap>
            <table className="data-table">
              <thead>
                <tr>
                  <th>RECEIPT</th>
                  <th>STUDENT</th>
                  <th>FEE MONTH</th>
                  <th>AMOUNT</th>
                  <th>MODE</th>
                  <th>DATE</th>
                  <th>STATUS / ACTION</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(({ payment, due, student }) => (
                  <tr key={payment.id}>
                    <td className="mono">{payment.receiptNo}</td>
                    <td>
                      <b>{student?.name || "Student record missing"}</b>
                      <small className="table-secondary">
                        {student?.admissionNo || "—"}
                      </small>
                    </td>
                    <td>{due ? displayMonth(due.month) : "—"}</td>
                    <td>{money(payment.amount)}</td>
                    <td>{payment.mode}</td>
                    <td>{displayDate(payment.paidAt.slice(0, 10))}</td>
                    <td>
                      {payment.voidedAt ? (
                        <span>
                          <Badge tone="rose">Voided</Badge>
                          <small className="table-secondary">
                            {payment.voidReason}
                          </small>
                        </span>
                      ) : (
                        <div className="table-actions">
                          <Badge tone="green">Paid</Badge>
                          <button
                            className="row-action"
                            onClick={() => {
                              if (due && student)
                                setReceipt({ due, payment, student });
                            }}
                          >
                            <Printer size={14} />
                            <span>Receipt</span>
                          </button>
                          <button
                            className="row-action"
                            onClick={() =>
                              setCancel({ id: payment.id!, reason: "" })
                            }
                          >
                            <X size={14} />
                            <span>Reverse</span>
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        ) : (
          <EmptyState
            title="No receipts match"
            text="Collected fee payments will appear here."
            icon={<WalletCards size={22} />}
          />
        )}
      </Card>
      <ReceiptModal
        data={receipt}
        school={printSchoolFromSettings(settings)}
        className={
          receipt
            ? classes.find((c) => c.id === receipt.student.classId)?.name ||
              String(receipt.student.classId)
            : "Class"
        }
        onClose={() => setReceipt(null)}
      />
      <Modal
        open={!!cancel}
        onClose={() => setCancel(null)}
        title="Reverse this receipt?"
        subtitle="This does not delete the payment. It restores the fee balance and records your reason in the audit log."
        size="md"
      >
        {cancel && (
          <div className="form-grid">
            <Textarea
              label="Reason for reversal"
              value={cancel.reason}
              onChange={(e) => setCancel({ ...cancel, reason: e.target.value })}
              rows={3}
              required
            />
            <div className="modal-actions full-span">
              <Button variant="secondary" onClick={() => setCancel(null)}>
                Keep receipt
              </Button>
              <Button variant="danger" onClick={() => void reversePayment()}>
                Reverse payment
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

interface DemandBatch {
  id: string;
  month: string;
  months?: string[];
  classKey: string;
  session?: string;
  count: number;
  total: number;
  skipped: number;
  createdAt: string;
  payBy?: string;
  remarks?: string;
  saveCurrentDues?: boolean;
  students: {
    studentId?: number;
    studentName: string;
    parent?: string;
    mobile?: string;
    admissionNo: string;
    className: string;
    section: string;
    heads?: Record<string, number>;
    backDues?: number;
    periods?: {
      month: string;
      heads: Record<string, number>;
      backDues: number;
      current: number;
      total: number;
    }[];
    total: number;
  }[];
}
export function DemandBillsPage() {
  const classes = useClasses();
  const students =
    useLiveQuery(
      () =>
        db.students
          .filter((s) => !s.deletedAt && s.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const dues = useLiveQuery(() => db.feeDues.toArray(), [], []) || [];
  const structures =
    useLiveQuery(() => db.feeStructures.toArray(), [], []) || [];
  const routes = useLiveQuery(() => db.transportRoutes.toArray(), [], []) || [];
  const settings = useSettings();
  const { toast } = useToast();
  const [selectedMonths, setSelectedMonths] = useState<string[]>([monthISO()]);
  const [classKey, setClassKey] = useState("all");
  const [includeBack, setIncludeBack] = useState(false);
  const [includeHeads, setIncludeHeads] = useState<Record<string, boolean>>({
    tuition: true,
    transport: true,
    exam: true,
    admission: true,
    library: true,
    other: true,
  });
  const [saveCurrentDues, setSaveCurrentDues] = useState(true);
  const [payBy, setPayBy] = useState("");
  const [batchRemarks, setBatchRemarks] = useState("");
  const [shareBatch, setShareBatch] = useState<DemandBatch | null>(null);
  const [preview, setPreview] = useState(false);
  const [history, setHistory] = useState<DemandBatch[]>([]);
  useEffect(() => {
    setHistory(
      Array.isArray(settings.demandBatches) ? settings.demandBatches : [],
    );
  }, [settings.demandBatches]);
  const selectedPeriods = [...new Set(selectedMonths)].sort();
  const primaryMonth = selectedPeriods[0] || monthISO();
  const chosen = students.filter(
    (s) => classKey === "all" || `${s.classId}-${s.section}` === classKey,
  );
  const rows = chosen.map((s) => {
    const structure = structures.find(
      (f) =>
        f.classId === s.classId &&
        f.section === s.section &&
        f.session === s.session,
    );
    const fullHeads = structure
      ? feeHeadsForStudent(s, structure, routes)
      : undefined;
    const heads = fullHeads
      ? Object.fromEntries(
          Object.entries(fullHeads).map(([key, value]) => [
            key,
            includeHeads[key] ? value : 0,
          ]),
        )
      : undefined;
    const current = heads ? totalFeeHeads(heads) : 0;
    const periods = selectedPeriods
      .map((periodMonth) => {
        const hasDue = dues.some(
          (d) =>
            d.studentId === s.id &&
            d.session === s.session &&
            d.month === periodMonth,
        );
        const priorBatch = history.some(
          (batch) =>
            (batch.months?.includes(periodMonth) ||
              batch.month === periodMonth) &&
            (!batch.session || batch.session.split(", ").includes(s.session)) &&
            batch.students.some((item) => item.studentId === s.id),
        );
        return {
          month: periodMonth,
          heads: heads || {},
          current,
          exists: hasDue || priorBatch,
        };
      })
      .filter((period) => !period.exists && structure);
    const back = includeBack
      ? dues
          .filter(
            (d) =>
              d.studentId === s.id &&
              d.balance > 0 &&
              d.month < primaryMonth &&
              !selectedPeriods.includes(d.month),
          )
          .reduce((a, d) => a + d.balance, 0)
      : 0;
    const billPeriods = periods
      .map((period, index) => ({
        ...period,
        backDues: index === 0 ? back : 0,
        total: roundMoney(period.current + (index === 0 ? back : 0)),
      }))
      .filter((period) => period.total > 0);
    return {
      student: s,
      structure,
      periods: billPeriods,
      skippedPeriods: selectedPeriods.length - billPeriods.length,
      total: roundMoney(
        billPeriods.reduce((sum, period) => sum + period.total, 0),
      ),
    };
  });
  const payable = rows.filter((r) => r.periods.length > 0);
  const payableMonthCount = payable.reduce(
    (sum, row) => sum + row.periods.length,
    0,
  );
  const total = payable.reduce((a, r) => a + r.total, 0);
  const skippedCount = Math.max(
    0,
    chosen.length * selectedPeriods.length - payableMonthCount,
  );
  const dueDay = Math.max(
    1,
    Math.min(31, Number(settings.defaultFeeDay || 10)),
  );
  const payByDefault = (() => {
    const dueMonth =
      selectedPeriods[selectedPeriods.length - 1] || primaryMonth;
    const [year, monthNum] = dueMonth.split("-").map(Number);
    const lastDay = new Date(year, monthNum, 0).getDate();
    return `${dueMonth}-${String(Math.min(dueDay, lastDay)).padStart(2, "0")}`;
  })();
  const generate = async () => {
    const now = new Date().toISOString();
    if (!selectedPeriods.length) {
      toast("Choose at least one fee month.", "error");
      return;
    }
    if (saveCurrentDues) {
      await db.transaction("rw", db.feeDues, async () => {
        for (const row of payable) {
          for (const period of row.periods) {
            if (!period.current) continue;
            await db.feeDues.add({
              studentId: row.student.id!,
              session: row.student.session,
              month: period.month,
              tuition: period.heads.tuition || 0,
              transport: period.heads.transport || 0,
              exam: period.heads.exam || 0,
              admission: period.heads.admission || 0,
              library: period.heads.library || 0,
              other: period.heads.other || 0,
              discount: 0,
              fine: 0,
              total: period.current,
              paid: 0,
              balance: period.current,
              status: "Pending",
              createdAt: now,
              updatedAt: now,
            });
          }
        }
      });
    }
    const batch: DemandBatch = {
      id: `DB-${now.slice(0, 10).replace(/-/g, "")}-${String(history.length + 1).padStart(3, "0")}`,
      month: primaryMonth,
      months: selectedPeriods,
      classKey,
      count: payable.length,
      total,
      skipped: skippedCount,
      session: [...new Set(payable.map((r) => r.student.session))].join(", "),
      payBy: payBy || payByDefault,
      remarks: batchRemarks.trim() || undefined,
      saveCurrentDues,
      createdAt: now,
      students: payable.map((row) => ({
        studentId: row.student.id,
        studentName: row.student.name,
        parent: row.student.father,
        mobile: row.student.mobile,
        admissionNo: row.student.admissionNo,
        className:
          classes.find((c) => c.id === row.student.classId)?.name || "Class",
        section: row.student.section,
        periods: row.periods.map(
          ({
            month: feeMonth,
            heads: periodHeads,
            backDues,
            current,
            total: periodTotal,
          }) => ({
            month: feeMonth,
            heads: periodHeads,
            backDues,
            current,
            total: periodTotal,
          }),
        ),
        heads: row.periods[0]?.heads,
        backDues: row.periods.reduce((sum, period) => sum + period.backDues, 0),
        total: row.total,
      })),
    };
    const next = [batch, ...history];
    await saveSetting("demandBatches", next);
    await audit(
      currentUser(),
      "Generated demand bills",
      "Demand bills",
      batch.id,
      `${payable.length} slips · ${selectedPeriods.length} month(s) · ${money(total)}`,
    );
    setHistory(next);
    setPreview(false);
    toast(
      `${payable.length} demand slips prepared. ${skippedCount} student-month entries skipped.`,
    );
  };
  const printBatch = (b: DemandBatch) => {
    printDemandBills(b, printSchoolFromSettings(settings));
  };
  const exportBatch = (b: DemandBatch) =>
    saveFile(
      new Blob(
        [
          csvString(
            b.students.flatMap((student) =>
              student.periods?.length
                ? student.periods.map((period) => ({
                    student: student.studentName,
                    admission_number: student.admissionNo,
                    class: student.className,
                    section: student.section,
                    month: period.month,
                    tuition: period.heads.tuition || 0,
                    transport: period.heads.transport || 0,
                    exam: period.heads.exam || 0,
                    admission: period.heads.admission || 0,
                    library: period.heads.library || 0,
                    other: period.heads.other || 0,
                    back_dues: period.backDues,
                    amount: period.total,
                  }))
                : [
                    {
                      student: student.studentName,
                      admission_number: student.admissionNo,
                      class: student.className,
                      section: student.section,
                      month: b.month,
                      amount: student.total,
                    },
                  ],
            ),
          ),
        ],
        { type: "text/csv" },
      ),
      `demand-${b.id}.csv`,
    );
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="BULK FEE WORKFLOW"
        title="Demand bills"
        subtitle="Prepare monthly slips in bulk, check duplicates and print a tidy batch."
        action={
          <Button
            onClick={() => {
              setPreview(false);
              setPreview(true);
            }}
          >
            <Plus size={17} /> Prepare new batch
          </Button>
        }
      />
      <div className="demand-banner">
        <span className="demand-banner-icon">
          <ClipboardList size={20} />
        </span>
        <div>
          <b>One batch. Clear expectations.</b>
          <p>
            Preview student counts, skip existing dues, then print 2-up A4 slips
            for families.
          </p>
        </div>
        <div className="demand-banner-count">
          <small>ACTIVE STUDENTS</small>
          <b>{students.length}</b>
        </div>
      </div>
      <Card className="list-card">
        <div className="card-list-head">
          <div>
            <h3>Batch history</h3>
            <p>Your most recent demand bill runs are saved on this device.</p>
          </div>
          <span className="row-count">{history.length} batches</span>
        </div>
        {history.length ? (
          <div className="batch-list">
            {history.map((b) => (
              <div className="batch-row" key={b.id}>
                <span className="batch-icon">
                  <FileCheck2 size={18} />
                </span>
                <span className="batch-main">
                  <b>{b.id}</b>
                  <small>
                    {(b.months?.length ? b.months : [b.month])
                      .map(displayMonth)
                      .join(", ")}{" "}
                    · {b.count} slips · {displayDate(b.createdAt.slice(0, 10))}
                  </small>
                </span>
                <span className="batch-total">
                  <b>{money(b.total)}</b>
                  <small>{b.skipped} skipped</small>
                </span>
                <div className="batch-actions">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => printBatch(b)}
                  >
                    <Printer size={14} /> Print
                  </Button>
                  <Button
                    size="sm"
                    variant="soft"
                    onClick={() => setShareBatch(b)}
                  >
                    WhatsApp
                  </Button>
                  <button
                    className="icon-button"
                    onClick={() => exportBatch(b)}
                    aria-label="Export batch"
                  >
                    <Download size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            title="No demand bill batches yet"
            text="Prepare a monthly batch when you’re ready to send fee reminders home."
            icon={<ClipboardList size={22} />}
          />
        )}
      </Card>
      <Modal
        open={preview}
        onClose={() => setPreview(false)}
        title="Preview demand bills"
        subtitle="Nothing is saved until you confirm this batch."
        size="lg"
      >
        <div className="form-grid">
          <Select
            label="Class"
            value={classKey}
            onChange={(e) => setClassKey(e.target.value)}
          >
            <option value="all">All classes</option>
            {classes.map((c) => (
              <option key={c.id} value={`${c.id}-${c.section}`}>
                {c.name} · {c.section}
              </option>
            ))}
          </Select>
          <div className="field full-span">
            <span className="field-label">
              Fee month(s) · select one or more
            </span>
            <div className="demand-month-options">
              {monthOptions.map((periodMonth) => (
                <label key={periodMonth}>
                  <input
                    type="checkbox"
                    checked={selectedMonths.includes(periodMonth)}
                    onChange={(e) =>
                      setSelectedMonths((prev) =>
                        e.target.checked
                          ? [...prev, periodMonth]
                          : prev.filter((value) => value !== periodMonth),
                      )
                    }
                  />
                  <span>{displayMonth(periodMonth)}</span>
                </label>
              ))}
            </div>
          </div>
          <Input
            label="Pay by"
            type="date"
            value={payBy || payByDefault}
            onChange={(e) => setPayBy(e.target.value)}
          />
          <div className="form-section-label full-span">
            FEE HEADS TO INCLUDE
          </div>
          <div className="demand-head-options full-span">
            {(
              [
                "tuition",
                "transport",
                "exam",
                "admission",
                "library",
                "other",
              ] as const
            ).map((head) => (
              <label key={head}>
                <input
                  type="checkbox"
                  checked={includeHeads[head]}
                  onChange={(e) =>
                    setIncludeHeads({
                      ...includeHeads,
                      [head]: e.target.checked,
                    })
                  }
                />
                <span>{head[0].toUpperCase() + head.slice(1)}</span>
              </label>
            ))}
          </div>
          <label className="toggle-row full-span">
            <input
              type="checkbox"
              checked={saveCurrentDues}
              onChange={(e) => setSaveCurrentDues(e.target.checked)}
            />
            <span>
              <b>Save current dues to the fee ledger</b>
              <small>
                Turn off to prepare demand slips without creating fee due
                records.
              </small>
            </span>
          </label>
          <Textarea
            label="Batch remarks"
            className="full-span"
            rows={2}
            value={batchRemarks}
            onChange={(e) => setBatchRemarks(e.target.value)}
            placeholder="Optional note for this batch"
          />
          <label className="toggle-row full-span">
            <input
              type="checkbox"
              checked={includeBack}
              onChange={(e) => setIncludeBack(e.target.checked)}
            />
            <span>
              <b>Include previous outstanding balance</b>
              <small>
                Add any unpaid earlier dues to the printed amount. Existing dues
                remain unchanged.
              </small>
            </span>
          </label>
          <div className="generation-preview-banner full-span">
            <div>
              <b>{payable.length}</b>
              <span>slips to generate</span>
            </div>
            <div>
              <b>{skippedCount}</b>
              <span>existing / no fee plan month entries</span>
            </div>
            <div>
              <b>{money(total)}</b>
              <span>total requested</span>
            </div>
          </div>
          <div className="preview-list full-span">
            {rows.slice(0, 8).map((r) => (
              <div key={r.student.id}>
                <span>
                  {r.student.name}
                  <small>
                    {classes.find((c) => c.id === r.student.classId)?.name}-
                    {r.student.section} · {r.student.admissionNo} ·{" "}
                    {r.periods.length} month(s)
                  </small>
                </span>
                <span>
                  {r.periods.length ? (
                    <b>{money(r.total)}</b>
                  ) : (
                    <Badge tone="neutral">All selected months skipped</Badge>
                  )}
                </span>
              </div>
            ))}
          </div>
          <p className="form-helper full-span">
            Existing dues and prior demand slips are skipped month by month.
            Current dues are saved only when that option is selected.
          </p>
          <div className="modal-actions full-span">
            <Button variant="secondary" onClick={() => setPreview(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => void generate()}
              disabled={!payable.length || !selectedPeriods.length}
            >
              Create {payable.length} demand slips <Check size={16} />
            </Button>
          </div>
        </div>
      </Modal>
      <Modal
        open={!!shareBatch}
        onClose={() => setShareBatch(null)}
        title="Send fee demand reminders"
        subtitle={
          shareBatch
            ? `${shareBatch.id} · ${shareBatch.students.length} students · WhatsApp first; SMS opens a composer`
            : ""
        }
        size="lg"
      >
        {shareBatch && (
          <div className="share-list">
            {shareBatch.students.map((student) => {
              const monthsLabel = (
                shareBatch.months?.length
                  ? shareBatch.months
                  : [shareBatch.month]
              )
                .map(displayMonth)
                .join(", ");
              const text = `Namaste ${student.parent || "Parent"}, fee demand for ${monthsLabel} at ${settings.schoolName || "school"} is ${money(student.total)}. Pay by ${shareBatch.payBy ? displayDate(shareBatch.payBy) : "at the earliest"}. Please contact the school office for details.`;
              const phone = String(student.mobile || "");
              return (
                <div
                  key={`${student.studentId || student.admissionNo}-${student.admissionNo}`}
                >
                  <span>
                    <b>{student.parent || student.studentName}</b>
                    <small>
                      {student.studentName} · {student.admissionNo} ·{" "}
                      {money(student.total)}
                    </small>
                  </span>
                  {isValidIndiaPhone(phone) ? (
                    <div className="share-contact-actions">
                      <a
                        className="btn btn-soft btn-sm"
                        href={whatsappHref(phone, text)}
                      >
                        <MessageCircle size={14} /> Open WhatsApp
                      </a>
                      <a
                        className="btn btn-secondary btn-sm"
                        href={smsHref(phone, text)}
                        title="SMS fallback; opens a prefilled composer"
                        onClick={(event) =>
                          handlePhoneProtocol(event, "sms", phone, text, toast)
                        }
                      >
                        <MessageSquare size={14} /> SMS
                      </a>
                    </div>
                  ) : (
                    <Badge tone="amber">No valid mobile</Badge>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </Modal>
    </div>
  );
}

export function FamilyBillingPage() {
  const students =
    useLiveQuery(
      () =>
        db.students
          .filter((s) => !s.deletedAt && s.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const dues = useLiveQuery(() => db.feeDues.toArray(), [], []) || [];
  const history =
    useLiveQuery(
      () => db.familyBills.orderBy("createdAt").reverse().toArray(),
      [],
      [],
    ) || [];
  const classes = useClasses();
  const settings = useSettings();
  const { toast } = useToast();
  const families = useMemo(() => {
    const map = new Map<string, Student[]>();
    for (const s of students) {
      const key = `${(s.father || "").trim().toLowerCase()}|${s.mobile}`;
      map.set(key, [...(map.get(key) || []), s]);
    }
    return [...map.entries()]
      .filter(([, members]) => members.length > 1)
      .map(([key, members]) => ({
        key,
        parent: members[0].father || "Parent / guardian",
        mobile: members[0].mobile,
        members,
        dues: dues.filter(
          (d) => members.some((s) => s.id === d.studentId) && d.balance > 0,
        ),
      }))
      .sort((a, b) => a.parent.localeCompare(b.parent));
  }, [students, dues]);
  const [selected, setSelected] = useState("");
  const [discount, setDiscount] = useState("0");
  const [fine, setFine] = useState("0");
  const [pay, setPay] = useState("");
  const [month, setMonth] = useState("all");
  const [paymentMode, setPaymentMode] = useState("Cash");
  const [lastBill, setLastBill] = useState<FamilyBill | null>(null);
  const [q, setQ] = useState("");
  const active = families.find((f) => f.key === selected);
  const activeDues =
    active?.dues.filter((d) => month === "all" || d.month === month) || [];
  const amountDue = activeDues.reduce((a, d) => a + d.balance, 0);
  const familyTotal = Math.max(0, amountDue - Number(discount) + Number(fine));
  const activeReminderText = active
    ? `Namaste ${active.parent}, combined pending school fee is ${money(familyTotal)}. Please contact the school office for details.`
    : "";
  const collect = async (e: FormEvent) => {
    e.preventDefault();
    if (!active || familyTotal <= 0) {
      toast("Select a family with pending dues.", "error");
      return;
    }
    const paid = roundMoney(Number(pay) || familyTotal);
    if (paid <= 0 || paid > familyTotal) {
      toast("Enter a valid payment amount for this family bill.", "error");
      return;
    }
    const now = new Date().toISOString();
    const billNo = `FAM-${now.slice(0, 4)}${now.slice(5, 7)}-${String(history.length + 1).padStart(4, "0")}`;
    const appliedDiscount = Math.min(Number(discount) || 0, amountDue);
    const appliedFine = Math.max(0, Number(fine) || 0);
    const bill: FamilyBill = {
      billNo,
      familyKey: active.key,
      parent: active.parent,
      mobile: active.mobile,
      studentIds: active.members.map((s) => s.id!),
      total: roundMoney(familyTotal),
      discount: appliedDiscount,
      fine: appliedFine,
      paid,
      balance: roundMoney(Math.max(0, familyTotal - paid)),
      status: paid >= familyTotal ? "Paid" : "Partial",
      paymentMode,
      months: [...new Set(activeDues.map((d) => d.month))],
      items: [
        ...activeDues.map((d) => ({
          studentId: d.studentId,
          studentName:
            active.members.find((s) => s.id === d.studentId)?.name || "Student",
          className:
            classes.find(
              (c) =>
                c.id ===
                active.members.find((s) => s.id === d.studentId)?.classId,
            )?.name || "Class",
          section:
            active.members.find((s) => s.id === d.studentId)?.section || "",
          feeMonth: d.month,
          feeHead: "Outstanding fee balance",
          amount: d.balance,
          source: "Due" as const,
        })),
        ...(appliedDiscount
          ? [
              {
                studentId: active.members[0].id!,
                studentName: active.parent,
                className: "Family",
                section: "",
                feeMonth: activeDues[0]?.month || monthISO(),
                feeHead: "Sibling discount",
                amount: appliedDiscount,
                source: "Discount" as const,
              },
            ]
          : []),
        ...(appliedFine
          ? [
              {
                studentId: active.members[0].id!,
                studentName: active.parent,
                className: "Family",
                section: "",
                feeMonth: activeDues[0]?.month || monthISO(),
                feeHead: "Fine",
                amount: appliedFine,
                source: "Fine" as const,
              },
            ]
          : []),
        ...(paid
          ? [
              {
                studentId: active.members[0].id!,
                studentName: active.parent,
                className: "Family",
                section: "",
                feeMonth: activeDues[0]?.month || monthISO(),
                feeHead: "Payment received",
                amount: paid,
                source: "Payment" as const,
              },
            ]
          : []),
      ],
      createdAt: now,
      updatedAt: now,
    };
    let remaining = paid;
    await db.transaction(
      "rw",
      db.feeDues,
      db.feePayments,
      db.familyBills,
      async () => {
        for (const d of activeDues) {
          const shareBase = amountDue ? d.balance / amountDue : 0;
          const discountShare = roundMoney(appliedDiscount * shareBase);
          const fineShare = roundMoney(appliedFine * shareBase);
          const adjustedBalance = roundMoney(
            Math.max(0, d.balance - discountShare + fineShare),
          );
          const allocation = roundMoney(Math.min(adjustedBalance, remaining));
          remaining = roundMoney(Math.max(0, remaining - allocation));
          const nextPaid = roundMoney(d.paid + allocation);
          const nextBalance = roundMoney(
            Math.max(0, adjustedBalance - allocation),
          );
          const nextTotal = roundMoney(nextPaid + nextBalance);
          await db.feeDues.update(d.id!, {
            paid: nextPaid,
            total: nextTotal,
            discount: roundMoney(d.discount + discountShare),
            fine: roundMoney(d.fine + fineShare),
            balance: nextBalance,
            status:
              nextBalance === 0 ? "Paid" : nextPaid ? "Partial" : "Pending",
            updatedAt: now,
          });
          if (allocation > 0) {
            const recent = await db.feePayments.toArray();
            const monthKey = now.slice(0, 4) + now.slice(5, 7);
            const prefix = `RCPT-${monthKey}-`;
            const n =
              recent.filter((p) => p.receiptNo.startsWith(prefix)).length + 1;
            const rcpt = `${prefix}${String(n).padStart(4, "0")}`;
            await db.feePayments.add({
              receiptNo: rcpt,
              dueId: d.id!,
              studentId: d.studentId,
              amount: allocation,
              mode: paymentMode,
              paidAt: now,
              remarks: billNo,
              familyBillNo: billNo,
            });
          }
        }
        bill.paid = paid - remaining;
        bill.balance = roundMoney(Math.max(0, bill.total - bill.paid));
        bill.status =
          bill.balance === 0 ? "Paid" : bill.paid ? "Partial" : "Pending";
        await db.familyBills.add(bill);
      },
    );
    await audit(
      currentUser(),
      "Created family bill",
      "Family billing",
      billNo,
      active.parent,
    );
    await audit(
      currentUser(),
      "Recorded family payment",
      "Family billing",
      billNo,
      `${active.parent} · ${money(paid - remaining)} · ${paymentMode}`,
      undefined,
      bill,
    );
    setLastBill(bill);
    toast(
      `Family bill ${billNo} recorded. You can print/share it from history.`,
    );
    setSelected("");
    setPay("");
  };
  const filtered = families.filter((f) =>
    [f.parent, f.mobile, ...f.members.map((s) => s.name)].some((v) =>
      v.toLowerCase().includes(q.toLowerCase()),
    ),
  );
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="SIBLING ACCOUNTS"
        title="Family billing"
        subtitle="Bring siblings together for a clearer, combined fee conversation."
        action={
          <span className="row-count">{families.length} family groups</span>
        }
      />
      <div className="family-layout">
        <Card className="family-directory">
          <div className="card-head">
            <div>
              <span className="card-eyebrow">FAMILY DIRECTORY</span>
              <h3>Sibling groups</h3>
            </div>
            <span className="family-count-icon">
              <Users size={16} />
            </span>
          </div>
          <SearchBox
            value={q}
            onChange={setQ}
            placeholder="Search parent or sibling…"
          />
          {filtered.length ? (
            <div className="family-list">
              {filtered.map((f) => (
                <button
                  key={f.key}
                  onClick={() => {
                    setSelected(f.key);
                    setPay("");
                    setDiscount("0");
                    setFine("0");
                  }}
                  className={`family-item ${selected === f.key ? "selected" : ""}`}
                >
                  <span className="family-avatars">
                    {f.members.slice(0, 2).map((s) => (
                      <Avatar key={s.id} name={s.name} size="sm" />
                    ))}
                  </span>
                  <span className="family-main">
                    <b>{f.parent}</b>
                    <small>
                      {f.members.length} children · {f.mobile}
                    </small>
                  </span>
                  <span className="family-balance">
                    <b>{money(f.dues.reduce((a, d) => a + d.balance, 0))}</b>
                    <small>due</small>
                  </span>
                </button>
              ))}
            </div>
          ) : (
            <EmptyState
              title="No sibling groups found"
              text="Families are grouped by father / guardian name and mobile number."
              icon={<Users size={22} />}
            />
          )}
        </Card>
        <Card className="family-bill-card">
          <div className="card-head">
            <div>
              <span className="card-eyebrow">COMBINED ACCOUNT</span>
              <h3>{active ? active.parent : "Choose a family"}</h3>
            </div>
            {active && (
              <Badge tone="violet">{active.members.length} siblings</Badge>
            )}
          </div>
          {active ? (
            <form onSubmit={collect}>
              <div className="family-children">
                {active.members.map((s) => (
                  <div key={s.id}>
                    <Avatar name={s.name} photo={s.photo} size="sm" />
                    <span>
                      <b>{s.name}</b>
                      <small>
                        {classes.find((c) => c.id === s.classId)?.name}-
                        {s.section} · {s.admissionNo}
                      </small>
                    </span>
                    <strong>
                      {money(
                        activeDues
                          .filter((d) => d.studentId === s.id)
                          .reduce((a, d) => a + d.balance, 0),
                      )}
                    </strong>
                  </div>
                ))}
              </div>
              <div className="family-filters">
                <Select
                  label="Fee period"
                  value={month}
                  onChange={(e) => setMonth(e.target.value)}
                >
                  <option value="all">All pending months</option>
                  {Array.from(new Set(active.dues.map((d) => d.month))).map(
                    (m) => (
                      <option key={m} value={m}>
                        {displayMonth(m)}
                      </option>
                    ),
                  )}
                </Select>
                <div className="family-base-total">
                  <span>Selected dues balance</span>
                  <b>{money(amountDue)}</b>
                </div>
              </div>
              <Select
                label="Payment mode"
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value)}
              >
                <option>Cash</option>
                <option>UPI</option>
                <option>Card</option>
                <option>Cheque</option>
                <option>Online</option>
              </Select>
              <div className="fee-fields-row">
                <Input
                  label="Sibling discount (₹)"
                  type="number"
                  min="0"
                  value={discount}
                  onChange={(e) => setDiscount(e.target.value)}
                />
                <Input
                  label="Fine (₹)"
                  type="number"
                  min="0"
                  value={fine}
                  onChange={(e) => setFine(e.target.value)}
                />
              </div>
              <div className="family-total-row">
                <span>Combined family bill</span>
                <b>{money(familyTotal)}</b>
              </div>
              <Input
                label="Payment received (₹)"
                type="number"
                min="0"
                max={familyTotal}
                value={pay}
                onChange={(e) => setPay(e.target.value)}
                hint="Payment is allocated to the oldest outstanding dues first."
              />
              <Button
                type="submit"
                size="lg"
                className="collect-submit"
                disabled={!amountDue}
              >
                Record family payment <ArrowRight size={17} />
              </Button>
              <div className="family-contact">
                <span>
                  <ShieldCheck size={15} /> Fee allocations update the
                  individual student ledgers.
                </span>
                {isValidIndiaPhone(active.mobile) && (
                  <div className="family-contact-actions">
                    <a href={whatsappHref(active.mobile, activeReminderText)}>
                      WhatsApp reminder ↗
                    </a>
                    <a
                      href={smsHref(active.mobile, activeReminderText)}
                      title="SMS fallback; opens a prefilled composer"
                      onClick={(event) =>
                        handlePhoneProtocol(
                          event,
                          "sms",
                          active.mobile,
                          activeReminderText,
                          toast,
                        )
                      }
                    >
                      SMS ↗
                    </a>
                  </div>
                )}
              </div>
            </form>
          ) : (
            <div className="fee-empty-prompt">
              <div className="fee-empty-icon">
                <Users size={24} />
              </div>
              <b>Select a sibling group</b>
              <span>
                Children are grouped by parent name and mobile number.
              </span>
            </div>
          )}
        </Card>
      </div>
      <Card className="list-card">
        <div className="card-list-head">
          <div>
            <h3>Family bill history</h3>
            <p>Recent combined payment records.</p>
          </div>
          <span className="row-count">{history.length} bills</span>
        </div>
        {history.length ? (
          <TableWrap>
            <table className="data-table">
              <thead>
                <tr>
                  <th>BILL NO.</th>
                  <th>PARENT</th>
                  <th>CHILDREN</th>
                  <th>TOTAL</th>
                  <th>PAID</th>
                  <th>DATE</th>
                  <th>ACTIONS</th>
                </tr>
              </thead>
              <tbody>
                {history.map((b) => (
                  <tr key={b.id}>
                    <td className="mono">{b.billNo}</td>
                    <td>{b.parent}</td>
                    <td>{b.studentIds.length}</td>
                    <td>{money(b.total)}</td>
                    <td className="text-green">{money(b.paid)}</td>
                    <td>{displayDate(b.createdAt.slice(0, 10))}</td>
                    <td>
                      <div className="table-actions">
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() =>
                            printFamilyBill(
                              b,
                              printSchoolFromSettings(settings),
                            )
                          }
                        >
                          <Printer size={14} /> Print
                        </Button>
                        {isValidIndiaPhone(b.mobile) && (
                          <>
                            <a
                              className="row-action"
                              href={whatsappHref(
                                b.mobile,
                                `Namaste ${b.parent}, family fee bill ${b.billNo}: total ${money(b.total)}, paid ${money(b.paid)}, balance ${money(b.balance ?? b.total - b.paid)}. Please contact school office for details.`,
                              )}
                            >
                              WhatsApp
                            </a>
                            <a
                              className="row-action"
                              href={smsHref(
                                b.mobile,
                                `Namaste ${b.parent}, family fee bill ${b.billNo}: total ${money(b.total)}, paid ${money(b.paid)}, balance ${money(b.balance ?? b.total - b.paid)}. Please contact school office for details.`,
                              )}
                              title="SMS fallback; opens a prefilled composer"
                              onClick={(event) =>
                                handlePhoneProtocol(
                                  event,
                                  "sms",
                                  b.mobile,
                                  `Namaste ${b.parent}, family fee bill ${b.billNo}: total ${money(b.total)}, paid ${money(b.paid)}, balance ${money(b.balance ?? b.total - b.paid)}. Please contact school office for details.`,
                                  toast,
                                )
                              }
                            >
                              SMS
                            </a>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        ) : (
          <EmptyState
            title="No family bills yet"
            text="Combined payments will be listed here."
          />
        )}
      </Card>
      <Modal
        open={!!lastBill}
        onClose={() => setLastBill(null)}
        title="Family bill saved"
        subtitle={lastBill ? `${lastBill.billNo} · ${lastBill.parent}` : ""}
        size="md"
      >
        {lastBill && (
          <>
            <div className="receipt-amount">
              <span>Balance due</span>
              <b>{money(lastBill.balance ?? 0)}</b>
            </div>
            <div className="modal-actions">
              <Button variant="secondary" onClick={() => setLastBill(null)}>
                Done
              </Button>
              <Button
                onClick={() =>
                  printFamilyBill(lastBill, printSchoolFromSettings(settings))
                }
              >
                <Printer size={15} /> Print family bill
              </Button>
              {isValidIndiaPhone(lastBill.mobile) && (
                <>
                  <a
                    className="btn btn-outline"
                    href={whatsappHref(
                      lastBill.mobile,
                      `Namaste ${lastBill.parent}, family fee bill ${lastBill.billNo}: total ${money(lastBill.total)}, paid ${money(lastBill.paid)}, balance ${money(lastBill.balance ?? 0)}.`,
                    )}
                  >
                    Share on WhatsApp
                  </a>
                  <a
                    className="btn btn-secondary"
                    href={smsHref(
                      lastBill.mobile,
                      `Namaste ${lastBill.parent}, family fee bill ${lastBill.billNo}: total ${money(lastBill.total)}, paid ${money(lastBill.paid)}, balance ${money(lastBill.balance ?? 0)}.`,
                    )}
                    title="SMS fallback; opens a prefilled composer"
                    onClick={(event) =>
                      handlePhoneProtocol(
                        event,
                        "sms",
                        lastBill.mobile,
                        `Namaste ${lastBill.parent}, family fee bill ${lastBill.billNo}: total ${money(lastBill.total)}, paid ${money(lastBill.paid)}, balance ${money(lastBill.balance ?? 0)}.`,
                        toast,
                      )
                    }
                  >
                    SMS
                  </a>
                </>
              )}
            </div>
          </>
        )}
      </Modal>
    </div>
  );
}

export function ExamsPage() {
  const classes = useClasses();
  const user = useAuth((state) => state.user);
  const canManageExams = user?.role !== "Teacher";
  const settings = useSettings();
  const allExams = useLiveQuery(() => db.exams.toArray(), [], []) || [];
  const exams =
    user?.role === "Teacher"
      ? allExams.filter((exam) =>
          classes.some(
            (schoolClass) =>
              schoolClass.id === exam.classId &&
              schoolClass.section === exam.section &&
              schoolClass.session === exam.session,
          ),
        )
      : allExams;
  const students =
    useLiveQuery(
      () =>
        db.students
          .filter((s) => !s.deletedAt && s.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const { toast } = useToast();
  const location = useLocation();
  const navigate = useNavigate();
  const params = useParams();
  const [open, setOpen] = useState(false);
  const [selectedId, setSelectedId] = useState(Number(params.id) || 0);
  const [draft, setDraft] = useState({
    name: "",
    classId: 0,
    section: "A",
    session: "2026-27",
    date: todayISO(),
    subjects: "English:100, Mathematics:100, Science:100, Social Studies:100",
  });
  const [subject, setSubject] = useState("");
  const [marks, setMarks] = useState<Record<number, string>>({});
  const [q, setQ] = useState("");
  const selected =
    exams.find((e) => e.id === selectedId) ||
    exams.find((e) => e.id === Number(params.id));
  const results =
    useLiveQuery<ExamResult[], ExamResult[]>(
      () =>
        selected
          ? db.examResults.where("examId").equals(selected.id!).toArray()
          : Promise.resolve([] as ExamResult[]),
      [selected?.id],
      [],
    ) || [];
  const studentList = students
    .filter(
      (s) =>
        s.classId === selected?.classId &&
        s.section === selected?.section &&
        s.session === selected?.session,
    )
    .sort((a, b) => a.roll - b.roll);
  useEffect(() => {
    if (params.id && Number(params.id) !== selectedId)
      setSelectedId(Number(params.id));
  }, [params.id, selectedId]);
  useEffect(() => {
    if (selected && !subject) setSubject(selected.subjects[0] || "");
  }, [selected, subject]);
  useEffect(() => {
    const map: Record<number, string> = {};
    for (const r of results.filter((r) => r.subject === subject))
      map[r.studentId] = String(r.marks);
    setMarks(map);
  }, [results, subject]);
  const saveExam = async (e: FormEvent) => {
    e.preventDefault();
    if (!canManageExams) {
      toast(
        "Teachers can enter marks for assigned exams but cannot create exams.",
        "error",
      );
      return;
    }
    const cls = classes.find((c) => c.id === draft.classId);
    if (!cls || !draft.name.trim()) {
      toast("Exam name and class are required.", "error");
      return;
    }
    const specs = draft.subjects
      .split(",")
      .map((part) => {
        const [namePart, maxPart] = part.split(":");
        return {
          name: namePart.trim(),
          max: maxPart ? Number(maxPart.trim()) : 100,
        };
      })
      .filter((x) => x.name);
    const subjects = specs.map((x) => x.name);
    if (
      !subjects.length ||
      specs.some((x) => !Number.isFinite(x.max) || x.max <= 0) ||
      new Set(subjects.map((x) => x.toLowerCase())).size !== subjects.length
    ) {
      toast(
        "Add unique subjects with valid maximum marks (for example English:100, Maths:50).",
        "error",
      );
      return;
    }
    const exam: Exam = {
      name: draft.name.trim(),
      classId: cls.id!,
      section: cls.section,
      session: draft.session,
      date: draft.date,
      subjects,
      subjectMaxMarks: Object.fromEntries(specs.map((x) => [x.name, x.max])),
      maxMarks: Math.max(...specs.map((x) => x.max)),
      status: "Planned",
    };
    try {
      const id = await db.exams.add(exam);
      await audit(currentUser(), "Created", "Exam", id, exam.name);
      setSelectedId(id);
      setOpen(false);
      setSubject(subjects[0]);
      toast("Exam created. Enter marks when you are ready.");
    } catch {
      toast(
        "An exam with this name already exists for that class and session.",
        "error",
      );
    }
  };
  const saveMarks = async () => {
    if (!selected || !studentList.length) return;
    const subjectMax = selected.subjectMaxMarks?.[subject] || selected.maxMarks;
    const invalid = studentList.find(
      (s) =>
        marks[s.id!] !== undefined &&
        marks[s.id!] !== "" &&
        (Number.isNaN(Number(marks[s.id!])) ||
          Number(marks[s.id!]) < 0 ||
          Number(marks[s.id!]) > subjectMax),
    );
    if (invalid) {
      toast(
        `Marks for ${invalid.name} must be between 0 and ${subjectMax}.`,
        "error",
      );
      return;
    }
    let saved = 0;
    await db.transaction("rw", db.examResults, async () => {
      for (const student of studentList) {
        const raw = marks[student.id!];
        if (raw === "" || raw === undefined) continue;
        const value = Number(raw);
        const percentage = (value / subjectMax) * 100;
        const old = await db.examResults
          .where("[examId+studentId+subject]")
          .equals([selected.id!, student.id!, subject])
          .first();
        const row = {
          examId: selected.id!,
          studentId: student.id!,
          subject,
          maxMarks: subjectMax,
          marks: value,
          grade: gradeFor(percentage),
          result:
            value / subjectMax >= 0.33 ? ("Pass" as const) : ("Fail" as const),
        };
        if (old) await db.examResults.update(old.id!, row);
        else await db.examResults.add(row);
        saved++;
      }
    });
    await audit(
      currentUser(),
      "Saved exam marks",
      "Exam",
      selected.id,
      `${saved} marks · ${subject}`,
    );
    toast(`Marks saved for ${saved} students.`);
  };
  const rankList = studentList
    .map((s) => {
      const own = results.filter((r) => r.studentId === s.id);
      const total = own.reduce((a, r) => a + r.marks, 0);
      const max = own.reduce((a, r) => a + r.maxMarks, 0);
      const pct = max ? roundMoney((total / max) * 100) : 0;
      return {
        student: s,
        own,
        total,
        max,
        percentage: pct,
        grade: gradeFor(pct),
        pass:
          own.length >= selected?.subjects.length! &&
          own.every((r) => r.result === "Pass"),
      };
    })
    .filter((r) => r.max > 0);
  const rankedAll = rankRows(
    rankList.map((r) => ({
      name: r.student.name,
      percentage: r.percentage,
      marks: r.total,
      student: r.student,
      own: r.own,
      max: r.max,
      grade: r.grade,
      pass: r.pass,
    })),
  );
  const ranked = rankedAll.filter((r) =>
    [r.name, r.student.admissionNo, String(r.rank), r.grade].some((v) =>
      String(v).toLowerCase().includes(q.toLowerCase()),
    ),
  );
  const marksheetData = (r: (typeof rankedAll)[number]) => ({
    examName: selected?.name || "Exam",
    student: r.student,
    className: classes.find((c) => c.id === r.student.classId)?.name || "Class",
    section: r.student.section,
    rows: r.own.map((x) => ({
      subject: x.subject,
      marks: x.marks,
      maxMarks: x.maxMarks,
    })),
    rank: r.rank,
    percentage: r.percentage,
    grade: r.grade,
    pass: r.pass,
  });
  const printProgress = async () => {
    if (!selected) return;
    const sameClass = exams
      .filter(
        (e) =>
          e.classId === selected.classId &&
          e.section === selected.section &&
          e.session === selected.session,
      )
      .sort((a, b) => a.date.localeCompare(b.date));
    const pick = (pattern: RegExp, fallback?: Exam) =>
      sameClass.find((e) => pattern.test(e.name)) || fallback;
    const first = pick(/1st|first|term\s*1/i, sameClass[0]);
    const second = pick(/2nd|second|term\s*2/i, sameClass[1]);
    const final = pick(/final|annual/i, sameClass[sameClass.length - 1]);
    const chosen = [first, second, final].filter(
      (e, i, a): e is Exam =>
        Boolean(e) && a.findIndex((x) => x?.id === e?.id) === i,
    );
    const allResults = chosen.length
      ? await db.examResults
          .where("examId")
          .anyOf(chosen.map((e) => e.id!))
          .toArray()
      : [];
    const subjects = [...new Set(chosen.flatMap((e) => e.subjects))];
    const reports = studentList.map((student) => ({
      student,
      className: classes.find((c) => c.id === student.classId)?.name || "Class",
      section: student.section,
      session: student.session,
      terms: chosen.map((exam) => ({
        label:
          exam === first ? "1st term" : exam === second ? "2nd term" : "Final",
        examName: exam.name,
        subjects: Object.fromEntries(
          subjects.map((name) => {
            const r = allResults.find(
              (x) =>
                x.examId === exam.id &&
                x.studentId === student.id &&
                x.subject === name,
            );
            return [
              name,
              r ? { marks: r.marks, maxMarks: r.maxMarks } : undefined,
            ];
          }),
        ),
      })),
    }));
    printProgressReports(reports, subjects, printSchoolFromSettings(settings));
  };
  const exportResults = () => {
    const text = csvString(
      ranked.map((r) => ({
        rank: r.rank,
        student: r.name,
        admission_no: r.student.admissionNo,
        total: r.marks,
        max: r.max,
        percentage: r.percentage,
        grade: r.grade,
        result: r.pass ? "Pass" : "Incomplete / Fail",
      })),
    );
    saveFile(
      new Blob([text], { type: "text/csv" }),
      `exam-results-${selected?.id || "all"}.csv`,
    );
  };
  const view = location.pathname.endsWith("/ranks")
    ? "ranks"
    : location.pathname.endsWith("/marks")
      ? "marks"
      : "overview";
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="ACADEMIC RECORDS"
        title="Exams & results"
        subtitle="Plan assessments, enter marks and make results easy to understand."
        action={
          canManageExams ? (
            <Button
              onClick={() => {
                setDraft({
                  name: "",
                  classId: classes[0]?.id || 0,
                  section: classes[0]?.section || "A",
                  session: "2026-27",
                  date: todayISO(),
                  subjects:
                    "English:100, Mathematics:100, Science:100, Social Studies:100",
                });
                setOpen(true);
              }}
            >
              <Plus size={17} /> Create exam
            </Button>
          ) : undefined
        }
      />
      {exams.length > 0 && (
        <div className="exam-selector-row">
          <div className="exam-select-wrap">
            <span className="exam-select-icon">
              <Award size={17} />
            </span>
            <Select
              aria-label="Select exam"
              value={selected?.id || ""}
              onChange={(e) => {
                setSelectedId(Number(e.target.value));
                setSubject("");
              }}
            >
              <option value="">Select exam</option>
              {exams.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name} · {classes.find((c) => c.id === e.classId)?.name}-
                  {e.section}
                </option>
              ))}
            </Select>
          </div>
          {selected && (
            <div className="exam-tabs">
              <button
                onClick={() => {
                  setSelectedId(selected.id!);
                  navigate("/exams");
                }}
                className={view === "overview" ? "active" : ""}
              >
                Overview
              </button>
              <Link
                to={`/exams/${selected.id}/marks`}
                className={view === "marks" ? "active" : ""}
              >
                Enter marks
              </Link>
              <Link
                to={`/exams/${selected.id}/ranks`}
                className={view === "ranks" ? "active" : ""}
              >
                Rank list
              </Link>
            </div>
          )}
        </div>
      )}
      {!exams.length ? (
        <Card className="exam-empty-card">
          <div className="exam-empty-illustration">
            <div className="paper">
              <span />
              <span />
              <span />
              <i>✦</i>
            </div>
          </div>
          <h3>Your results start here.</h3>
          <p>
            {canManageExams
              ? "No exams have been planned yet. Add one to set up subjects, enter marks and explore class performance."
              : "No exams are planned for your assigned classes yet. Ask an Admin or Principal to create one."}
          </p>
          {canManageExams && (
            <Button onClick={() => setOpen(true)}>
              <Plus size={16} /> Create your first exam
            </Button>
          )}
        </Card>
      ) : (
        selected && (
          <>
            {view === "marks" ? (
              <Card className="marks-card">
                <div className="marks-toolbar">
                  <div>
                    <span className="card-eyebrow">MARKS ENTRY</span>
                    <h3>{selected.name}</h3>
                    <p>
                      {classes.find((c) => c.id === selected.classId)?.name} ·
                      Section {selected.section} · {subject || "Subject"}:{" "}
                      {selected.subjectMaxMarks?.[subject] || selected.maxMarks}{" "}
                      marks
                    </p>
                  </div>
                  <div className="marks-subject-select">
                    <Select
                      label="Subject"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                    >
                      {selected.subjects.map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </Select>
                  </div>
                </div>
                <div className="marks-progress">
                  <div>
                    <b>
                      {
                        Object.keys(marks).filter(
                          (id) =>
                            marks[Number(id)] !== "" &&
                            marks[Number(id)] !== undefined,
                        ).length
                      }
                    </b>{" "}
                    of {studentList.length} students entered
                  </div>
                  <div className="progress-track">
                    <i
                      style={{
                        width: `${studentList.length ? (Object.keys(marks).filter((id) => marks[Number(id)] !== "" && marks[Number(id)] !== undefined).length / studentList.length) * 100 : 0}%`,
                      }}
                    />
                  </div>
                </div>
                {studentList.length ? (
                  <TableWrap>
                    <table className="data-table marks-table">
                      <thead>
                        <tr>
                          <th>STUDENT</th>
                          <th>ADMISSION NO.</th>
                          <th>
                            MARKS /{" "}
                            {selected.subjectMaxMarks?.[subject] ||
                              selected.maxMarks}
                          </th>
                          <th>GRADE</th>
                        </tr>
                      </thead>
                      <tbody>
                        {studentList.map((s) => {
                          const value = marks[s.id!] || "";
                          const grade =
                            value !== ""
                              ? gradeFor(
                                  (Number(value) /
                                    (selected.subjectMaxMarks?.[subject] ||
                                      selected.maxMarks)) *
                                    100,
                                )
                              : "—";
                          return (
                            <tr key={s.id}>
                              <td>
                                <div className="student-cell">
                                  <Avatar
                                    name={s.name}
                                    photo={s.photo}
                                    size="sm"
                                  />
                                  <span>
                                    <b>{s.name}</b>
                                    <small>Roll {s.roll}</small>
                                  </span>
                                </div>
                              </td>
                              <td className="mono">{s.admissionNo}</td>
                              <td>
                                <input
                                  className="marks-input"
                                  type="number"
                                  min="0"
                                  max={
                                    selected.subjectMaxMarks?.[subject] ||
                                    selected.maxMarks
                                  }
                                  inputMode="decimal"
                                  value={value}
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter") {
                                      e.preventDefault();
                                      const inputs = Array.from(
                                        document.querySelectorAll<HTMLInputElement>(
                                          ".marks-input",
                                        ),
                                      );
                                      inputs[
                                        inputs.indexOf(e.currentTarget) + 1
                                      ]?.focus();
                                    }
                                  }}
                                  onChange={(e) =>
                                    setMarks((prev) => ({
                                      ...prev,
                                      [s.id!]: e.target.value,
                                    }))
                                  }
                                  placeholder="—"
                                  aria-label={`Marks for ${s.name}`}
                                />
                              </td>
                              <td>
                                <Badge
                                  tone={
                                    grade === "—"
                                      ? "neutral"
                                      : grade === "E"
                                        ? "rose"
                                        : "green"
                                  }
                                >
                                  {grade}
                                </Badge>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </TableWrap>
                ) : (
                  <EmptyState
                    title="No students in this exam class"
                    text="Add students to the selected class and session before entering marks."
                  />
                )}
                <div className="attendance-save-bar">
                  <span className="attendance-saving-note">
                    <ShieldCheck size={15} />
                    Marks are stored on this device.
                  </span>
                  <div className="table-actions">
                    <Button
                      variant="secondary"
                      onClick={async () => {
                        await saveMarks();
                        const i = selected.subjects.indexOf(subject);
                        if (i >= 0 && selected.subjects[i + 1])
                          setSubject(selected.subjects[i + 1]);
                      }}
                      disabled={!studentList.length}
                    >
                      Save & next subject <ArrowRight size={16} />
                    </Button>
                    <Button
                      onClick={() => void saveMarks()}
                      disabled={!studentList.length}
                    >
                      Save marks <Check size={16} />
                    </Button>
                  </div>
                </div>
              </Card>
            ) : view === "ranks" ? (
              <Card className="list-card">
                <div className="rank-heading">
                  <div>
                    <span className="card-eyebrow">CLASS PERFORMANCE</span>
                    <h3>{selected.name} · Rank list</h3>
                    <p>Rank uses percentage, total marks, then student name.</p>
                  </div>
                  <div className="table-actions">
                    <Button variant="secondary" onClick={exportResults}>
                      <Download size={15} /> Export results
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() =>
                        printClassMarksheets(
                          rankedAll.map(marksheetData),
                          printSchoolFromSettings(settings),
                        )
                      }
                    >
                      <Printer size={15} /> Bulk marksheets
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() =>
                        printWallResult(
                          rankedAll.slice(0, 10).map((r) => ({
                            rank: r.rank,
                            name: r.name,
                            admissionNo: r.student.admissionNo,
                            percentage: r.percentage,
                            grade: r.grade,
                          })),
                          selected.name,
                          printSchoolFromSettings(settings),
                        )
                      }
                    >
                      <Award size={15} /> Wall result
                    </Button>
                    <Button
                      variant="secondary"
                      disabled={!rankedAll.length}
                      onClick={() => {
                        const filename = downloadWallResultSvg(
                          rankedAll.slice(0, 10).map((r) => ({
                            rank: r.rank,
                            name: r.name,
                            admissionNo: r.student.admissionNo,
                            percentage: r.percentage,
                            grade: r.grade,
                          })),
                          selected.name,
                          printSchoolFromSettings(settings),
                        );
                        toast(
                          `${filename} downloaded as a shareable SVG poster.`,
                        );
                      }}
                    >
                      <Download size={15} /> Save poster image
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => void printProgress()}
                    >
                      <FileCheck2 size={15} /> Progress reports
                    </Button>
                  </div>
                </div>
                <div className="list-toolbar">
                  <SearchBox
                    value={q}
                    onChange={setQ}
                    placeholder="Search name, admission no, rank or grade…"
                  />
                  <span className="row-count">{ranked.length} ranked</span>
                </div>
                {ranked.length ? (
                  <TableWrap>
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th>RANK</th>
                          <th>STUDENT</th>
                          <th>SUBJECTS ENTERED</th>
                          <th>TOTAL</th>
                          <th>PERCENTAGE</th>
                          <th>GRADE</th>
                          <th>RESULT</th>
                          <th>ACTIONS</th>
                        </tr>
                      </thead>
                      <tbody>
                        {ranked.map((r) => (
                          <tr key={r.student.id}>
                            <td>
                              <span
                                className={`rank-number ${r.rank <= 3 ? "top-rank" : ""}`}
                              >
                                {String(r.rank).padStart(2, "0")}
                              </span>
                            </td>
                            <td>
                              <div className="student-cell">
                                <Avatar name={r.name} size="sm" />
                                <span>
                                  <b>{r.name}</b>
                                  <small>{r.student.admissionNo}</small>
                                </span>
                              </div>
                            </td>
                            <td>
                              {r.own.length} / {selected.subjects.length}
                            </td>
                            <td>
                              <b>
                                {r.marks} / {r.max}
                              </b>
                            </td>
                            <td>
                              <b>{r.percentage.toFixed(2)}%</b>
                            </td>
                            <td>
                              <Badge tone={r.grade === "E" ? "rose" : "violet"}>
                                {r.grade}
                              </Badge>
                            </td>
                            <td>
                              <Badge tone={r.pass ? "green" : "amber"}>
                                {r.pass ? "Pass" : "Incomplete"}
                              </Badge>
                            </td>
                            <td>
                              <button
                                className="row-action"
                                onClick={() =>
                                  printMarksheet(
                                    marksheetData(r),
                                    printSchoolFromSettings(settings),
                                  )
                                }
                              >
                                <Printer size={14} />
                                <span>Marksheet</span>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </TableWrap>
                ) : (
                  <EmptyState
                    title="Marks are not in yet"
                    text="Enter marks for one or more subjects to build the rank list."
                  />
                )}
              </Card>
            ) : (
              <div className="exam-overview-grid">
                <Card className="exam-detail-card">
                  <span className="exam-detail-icon">
                    <ClipboardList size={20} />
                  </span>
                  <span className="card-eyebrow">ASSESSMENT DETAILS</span>
                  <h2>{selected.name}</h2>
                  <div className="exam-meta-grid">
                    <div>
                      <small>CLASS</small>
                      <b>
                        {classes.find((c) => c.id === selected.classId)?.name} ·{" "}
                        {selected.section}
                      </b>
                    </div>
                    <div>
                      <small>DATE</small>
                      <b>{displayDate(selected.date)}</b>
                    </div>
                    <div>
                      <small>SESSION</small>
                      <b>{selected.session}</b>
                    </div>
                    <div>
                      <small>SUBJECTS</small>
                      <b>{selected.subjects.length}</b>
                    </div>
                  </div>
                  <div className="subject-chip-list">
                    {selected.subjects.map((s) => (
                      <span key={s}>
                        {s} ·{" "}
                        {selected.subjectMaxMarks?.[s] || selected.maxMarks}
                      </span>
                    ))}
                  </div>
                  <div className="exam-detail-actions">
                    <Link
                      to={`/exams/${selected.id}/marks`}
                      className="btn btn-primary"
                    >
                      <FileSpreadsheet size={16} /> Enter marks
                    </Link>
                    <Link
                      to={`/exams/${selected.id}/ranks`}
                      className="btn btn-secondary"
                    >
                      <Award size={16} /> View rank list
                    </Link>
                  </div>
                </Card>
                <Card className="exam-stat-card">
                  <div className="card-head">
                    <div>
                      <span className="card-eyebrow">MARKS PROGRESS</span>
                      <h3>Ready when you are</h3>
                    </div>
                    <span className="exam-progress-icon">
                      <BarChart3 size={17} />
                    </span>
                  </div>
                  <div className="exam-big-stat">
                    {results.length}
                    <small>marks entered</small>
                  </div>
                  <div className="progress-track">
                    <i
                      style={{
                        width: `${selected.subjects.length && studentList.length ? Math.min(100, (results.length / (selected.subjects.length * studentList.length)) * 100) : 0}%`,
                      }}
                    />
                  </div>
                  <p>
                    {studentList.length} enrolled · {selected.subjects.length}{" "}
                    subjects · individual subject maximums.
                  </p>
                </Card>
              </div>
            )}
          </>
        )
      )}
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Plan a new exam"
        subtitle="Choose the class and subjects. You can enter marks later."
      >
        <form className="form-grid" onSubmit={saveExam}>
          <Input
            label="Exam name"
            placeholder="e.g. Unit test 1"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            required
          />
          <Input
            label="Exam date"
            type="date"
            value={draft.date}
            onChange={(e) => setDraft({ ...draft, date: e.target.value })}
            max="9999-12-31"
            required
          />
          <Select
            label="Class and section"
            value={draft.classId || ""}
            onChange={(e) => {
              const c = classes.find((x) => x.id === Number(e.target.value));
              setDraft({
                ...draft,
                classId: Number(e.target.value),
                section: c?.section || "A",
              });
            }}
            required
          >
            <option value="">Select class</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} · {c.section}
              </option>
            ))}
          </Select>
          <Input
            label="Academic session"
            value={draft.session}
            onChange={(e) => setDraft({ ...draft, session: e.target.value })}
          />
          <div className="form-helper">
            Each subject can have its own maximum marks. Example: English:100,
            Maths:50.
          </div>
          <Textarea
            label="Subjects with maximum marks"
            className="full-span"
            rows={2}
            value={draft.subjects}
            onChange={(e) => setDraft({ ...draft, subjects: e.target.value })}
            hint="Format: English:100, Mathematics:80. Omit :marks to use 100."
          />
          <div className="modal-actions full-span">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit">
              Create exam <ArrowRight size={16} />
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

export function PayrollPage() {
  const payroll =
    useLiveQuery(
      () => db.payroll.orderBy("month").reverse().toArray(),
      [],
      [],
    ) || [];
  const teachers =
    useLiveQuery(
      () =>
        db.teachers
          .filter((t) => !t.deletedAt && t.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const settings = useSettings();
  const { toast } = useToast();
  const readOnly = useAuth.getState().user?.role === "Principal";
  const [open, setOpen] = useState(false);
  const [month, setMonth] = useState(monthISO());
  const [staff, setStaff] = useState(teachers[0]?.name || "");
  const [basic, setBasic] = useState("");
  const [allowance, setAllowance] = useState("0");
  const [deduction, setDeduction] = useState("0");
  const [role, setRole] = useState("Teacher");
  const [q, setQ] = useState("");
  const [slip, setSlip] = useState<Payroll | null>(null);
  const [copyPreview, setCopyPreview] = useState<{
    sourceMonth: string;
    rows: Payroll[];
    existing: number;
  } | null>(null);
  useEffect(() => {
    if (!staff && teachers[0]) setStaff(teachers[0].name);
  }, [teachers, staff]);
  const net = roundMoney(Number(basic) + Number(allowance) - Number(deduction));
  const totalPayable = payroll
    .filter((p) => p.month === month)
    .reduce((a, p) => a + p.net, 0);
  const unpaid = payroll
    .filter((p) => p.month === month && p.status === "Unpaid")
    .reduce((a, p) => a + p.net, 0);
  const prepareCopy = async () => {
    if (readOnly) return;
    const prevDate = new Date(`${month}-01T00:00:00`);
    prevDate.setMonth(prevDate.getMonth() - 1);
    const sourceMonth = monthISO(prevDate);
    const source = payroll.filter((p) => p.month === sourceMonth);
    const currentNames = new Set(
      payroll.filter((p) => p.month === month).map((p) => p.name.toLowerCase()),
    );
    if (!source.length) {
      toast(
        `No payroll records found for ${displayMonth(sourceMonth)}.`,
        "info",
      );
      return;
    }
    setCopyPreview({
      sourceMonth,
      rows: source,
      existing: source.filter((p) => currentNames.has(p.name.toLowerCase()))
        .length,
    });
  };
  const confirmCopy = async () => {
    if (readOnly || !copyPreview) return;
    const currentNames = new Set(
      payroll.filter((p) => p.month === month).map((p) => p.name.toLowerCase()),
    );
    const toCopy = copyPreview.rows.filter(
      (p) => !currentNames.has(p.name.toLowerCase()),
    );
    const now = new Date().toISOString();
    await db.transaction("rw", db.payroll, async () => {
      for (const p of toCopy)
        await db.payroll.add({
          name: p.name,
          role: p.role,
          month,
          basic: p.basic,
          allowance: p.allowance,
          deduction: p.deduction,
          net: roundMoney(p.basic + p.allowance - p.deduction),
          status: "Unpaid",
          updatedAt: now,
        });
    });
    await audit(
      currentUser(),
      "Copied prior month payroll",
      "Payroll",
      month,
      `${toCopy.length} copied from ${copyPreview.sourceMonth}; ${copyPreview.existing} existing skipped`,
    );
    toast(
      `${toCopy.length} payroll entries copied. Existing entries were left unchanged.`,
    );
    setCopyPreview(null);
  };
  const openForm = () => {
    if (readOnly) return;
    const t = teachers.find((x) => x.name === staff);
    setBasic(String(t?.salary || ""));
    setOpen(true);
  };
  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (readOnly) {
      toast("Principal access is view-only for payroll.", "error");
      return;
    }
    if (!staff || net < 0) {
      toast("Choose an employee and check the salary values.", "error");
      return;
    }
    const existing = await db.payroll
      .where("[name+month]")
      .equals([staff, month])
      .first();
    const data = {
      name: staff,
      role,
      month,
      basic: Number(basic),
      allowance: Number(allowance),
      deduction: Number(deduction),
      net,
      status: "Unpaid" as const,
      updatedAt: new Date().toISOString(),
    };
    if (existing) await db.payroll.update(existing.id!, data);
    else await db.payroll.add(data);
    await audit(
      currentUser(),
      existing ? "Updated payroll" : "Created payroll",
      "Payroll",
      staff,
      month,
    );
    setOpen(false);
    toast(existing ? "Payroll entry updated." : "Salary entry created.");
  };
  const markPaid = async (p: Payroll) => {
    if (readOnly) {
      toast("Principal access is view-only for payroll.", "error");
      return;
    }
    await db.payroll.update(p.id!, {
      status: "Paid",
      paymentDate: todayISO(),
      updatedAt: new Date().toISOString(),
    });
    await audit(currentUser(), "Marked salary paid", "Payroll", p.id, p.name);
    toast(`${p.name} marked as paid.`);
  };
  const visible = payroll.filter(
    (p) =>
      p.month === month &&
      [p.name, p.role].some((v) => v.toLowerCase().includes(q.toLowerCase())),
  );
  const printSlip = (p: Payroll) => {
    printSalarySlip(p, printSchoolFromSettings(settings));
  };
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="STAFF FINANCE"
        title="Payroll"
        subtitle="Keep monthly salary entries clear, reviewed and ready to print."
        action={
          !readOnly ? (
            <div className="table-actions">
              <Button variant="secondary" onClick={() => void prepareCopy()}>
                <FileCheck2 size={16} /> Copy last month
              </Button>
              <Button onClick={openForm}>
                <Plus size={17} /> Add payroll
              </Button>
            </div>
          ) : undefined
        }
      />
      <div className="payroll-overview">
        <div className="payroll-month-select">
          <span className="payroll-month-icon">
            <CalendarDays size={18} />
          </span>
          <span>
            <small>PAYROLL PERIOD</small>
            <Input
              type="month"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
            />
          </span>
        </div>
        <div className="payroll-stat">
          <span>
            <WalletCards size={15} /> Total payable
          </span>
          <b>{money(totalPayable)}</b>
        </div>
        <div className="payroll-stat">
          <span>
            <Clock3 size={15} /> Still pending
          </span>
          <b className={unpaid ? "text-amber" : "text-green"}>
            {money(unpaid)}
          </b>
        </div>
        <div className="payroll-stat">
          <span>
            <CheckCircle2 size={15} /> Paid staff
          </span>
          <b>
            {
              payroll.filter((p) => p.month === month && p.status === "Paid")
                .length
            }
          </b>
        </div>
      </div>
      <Card className="list-card">
        <div className="list-toolbar">
          <SearchBox
            value={q}
            onChange={setQ}
            placeholder="Search employee or role…"
          />
          <span className="row-count">{visible.length} entries</span>
        </div>
        {visible.length ? (
          <TableWrap>
            <table className="data-table">
              <thead>
                <tr>
                  <th>EMPLOYEE</th>
                  <th>MONTH</th>
                  <th>BASIC</th>
                  <th>ALLOWANCE</th>
                  <th>DEDUCTION</th>
                  <th>NET PAY</th>
                  <th>STATUS</th>
                  <th>ACTIONS</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <div className="student-cell">
                        <Avatar name={p.name} />
                        <span>
                          <b>{p.name}</b>
                          <small>{p.role}</small>
                        </span>
                      </div>
                    </td>
                    <td>{displayMonth(p.month)}</td>
                    <td>{money(p.basic)}</td>
                    <td>{money(p.allowance)}</td>
                    <td>{money(p.deduction)}</td>
                    <td>
                      <b>{money(p.net)}</b>
                    </td>
                    <td>
                      <Badge tone={makeTone(p.status)}>{p.status}</Badge>
                    </td>
                    <td>
                      <div className="table-actions">
                        <button
                          className="row-action"
                          onClick={() => setSlip(p)}
                        >
                          <Printer size={15} />
                          <span>Slip</span>
                        </button>
                        {!readOnly && p.status === "Unpaid" && (
                          <button
                            className="row-action green-action"
                            onClick={() => void markPaid(p)}
                          >
                            <Check size={15} />
                            <span>Mark paid</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        ) : (
          <EmptyState
            title="No payroll entries for this month"
            text="Add a monthly salary entry to start the payroll register."
            icon={<WalletCards size={22} />}
          />
        )}
      </Card>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title="Create payroll entry"
        subtitle="The net amount is calculated automatically from earnings and deductions."
      >
        <form className="form-grid" onSubmit={save}>
          <Select
            label="Employee"
            value={staff}
            onChange={(e) => {
              setStaff(e.target.value);
              const t = teachers.find((x) => x.name === e.target.value);
              if (t) setBasic(String(t.salary));
            }}
            required
          >
            <option value="">Select employee</option>
            {teachers.map((t) => (
              <option key={t.id} value={t.name}>
                {t.name} · {t.subject || "Teacher"}
              </option>
            ))}
          </Select>
          <Input
            label="Month"
            type="month"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            required
          />
          <Select
            label="Role"
            value={role}
            onChange={(e) => setRole(e.target.value)}
          >
            <option>Teacher</option>
            <option>Principal</option>
            <option>Accountant</option>
            <option>Reception</option>
            <option>Support staff</option>
          </Select>
          <Input
            label="Basic salary (₹)"
            type="number"
            min="0"
            step="0.01"
            value={basic}
            onChange={(e) => setBasic(e.target.value)}
            required
          />
          <Input
            label="Allowance (₹)"
            type="number"
            min="0"
            step="0.01"
            value={allowance}
            onChange={(e) => setAllowance(e.target.value)}
          />
          <Input
            label="Deduction (₹)"
            type="number"
            min="0"
            step="0.01"
            value={deduction}
            onChange={(e) => setDeduction(e.target.value)}
          />
          <div className="fee-plan-total full-span">
            <span>Net salary</span>
            <strong>{money(net)}</strong>
          </div>
          <div className="modal-actions full-span">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit">
              Save payroll entry <ArrowRight size={16} />
            </Button>
          </div>
        </form>
      </Modal>
      <Modal
        open={!!copyPreview}
        onClose={() => setCopyPreview(null)}
        title="Copy previous month payroll"
        subtitle={
          copyPreview
            ? `${displayMonth(copyPreview.sourceMonth)} → ${displayMonth(month)}`
            : ""
        }
        size="lg"
      >
        {copyPreview && (
          <>
            <div className="restore-warning">
              <CircleAlert size={16} />
              <span>
                {copyPreview.rows.length - copyPreview.existing} new entries
                will be copied; {copyPreview.existing} staff already have a
                current-month entry and will be skipped.
              </span>
            </div>
            <div className="preview-list">
              {copyPreview.rows.slice(0, 10).map((p) => (
                <div key={p.id}>
                  <span>
                    {p.name}
                    <small>
                      {p.role} · Basic {money(p.basic)} · Net {money(p.net)}
                    </small>
                  </span>
                  <Badge
                    tone={
                      payroll.some(
                        (x) =>
                          x.month === month &&
                          x.name.toLowerCase() === p.name.toLowerCase(),
                      )
                        ? "neutral"
                        : "green"
                    }
                  >
                    {payroll.some(
                      (x) =>
                        x.month === month &&
                        x.name.toLowerCase() === p.name.toLowerCase(),
                    )
                      ? "Existing · skip"
                      : "Will copy"}
                  </Badge>
                </div>
              ))}
            </div>
            <div className="modal-actions">
              <Button variant="secondary" onClick={() => setCopyPreview(null)}>
                Cancel
              </Button>
              <Button
                onClick={() => void confirmCopy()}
                disabled={copyPreview.rows.length === copyPreview.existing}
              >
                Copy entries
              </Button>
            </div>
          </>
        )}
      </Modal>
      <Modal
        open={!!slip}
        onClose={() => setSlip(null)}
        title="Salary slip preview"
        subtitle="This slip includes earnings, deductions and signature lines."
      >
        {slip && (
          <div className="salary-preview">
            <div className="receipt-brand">
              {settings.schoolName || "School"}
            </div>
            <div className="receipt-label">
              SALARY SLIP <span>{displayMonth(slip.month)}</span>
            </div>
            <div className="receipt-no-row">
              <span>Employee</span>
              <b>{slip.name}</b>
            </div>
            <div className="receipt-no-row">
              <span>Role</span>
              <b>{slip.role}</b>
            </div>
            <div className="receipt-no-row">
              <span>Basic + allowance</span>
              <b>{money(slip.basic + slip.allowance)}</b>
            </div>
            <div className="receipt-no-row">
              <span>Deduction</span>
              <b>− {money(slip.deduction)}</b>
            </div>
            <div className="receipt-amount">
              <span>Net salary</span>
              <b>{money(slip.net)}</b>
            </div>
            <div className="receipt-words">{amountToWords(slip.net)}</div>
          </div>
        )}
        <div className="modal-actions">
          <Button variant="secondary" onClick={() => setSlip(null)}>
            Close
          </Button>
          {slip && (
            <Button onClick={() => printSlip(slip)}>
              <Printer size={15} /> Print salary slip
            </Button>
          )}
        </div>
      </Modal>
    </div>
  );
}

export function TransportPage() {
  const routes = useLiveQuery(() => db.transportRoutes.toArray(), [], []) || [];
  const students =
    useLiveQuery(
      () =>
        db.students
          .filter((s) => !s.deletedAt && s.status === "Active")
          .toArray(),
      [],
      [],
    ) || [];
  const classes = useClasses();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [assignRoute, setAssignRoute] = useState<number | null>(null);
  const [editing, setEditing] = useState<number | null>(null);
  const [q, setQ] = useState("");
  type RouteDraft = Omit<TransportRoute, "id">;
  const [draft, setDraft] = useState<RouteDraft>({
    name: "",
    vehicle: "",
    driver: "",
    phone: "",
    monthlyFee: 0,
    capacity: 40,
    remarks: "",
    status: "Active",
  });
  const [selectedRiders, setSelectedRiders] = useState<number[]>([]);
  const show = (id?: number) => {
    const r = routes.find((x) => x.id === id);
    setEditing(id || null);
    setDraft(
      r
        ? {
            name: r.name,
            vehicle: r.vehicle,
            driver: r.driver,
            phone: r.phone,
            monthlyFee: r.monthlyFee,
            capacity: r.capacity,
            remarks: r.remarks || "",
            status: r.status,
          }
        : {
            name: "",
            vehicle: "",
            driver: "",
            phone: "",
            monthlyFee: 0,
            capacity: 40,
            remarks: "",
            status: "Active",
          },
    );
    setOpen(true);
  };
  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!draft.name.trim() || !draft.vehicle.trim()) {
      toast("Route name and vehicle number are required.", "error");
      return;
    }
    const data = {
      ...draft,
      name: draft.name.trim(),
      vehicle: draft.vehicle.trim().toUpperCase(),
      phone: draft.phone.replace(/\D/g, ""),
    };
    try {
      if (editing) await db.transportRoutes.update(editing, data);
      else await db.transportRoutes.add(data);
      await audit(
        currentUser(),
        editing ? "Updated" : "Created",
        "Transport route",
        editing ?? undefined,
        draft.name,
      );
      setOpen(false);
      toast("Transport route saved.");
    } catch {
      toast("Route name already exists. Please choose another.", "error");
    }
  };
  const manage = (routeId: number) => {
    setAssignRoute(routeId);
    setSelectedRiders(
      students.filter((s) => s.routeId === routeId).map((s) => s.id!),
    );
  };
  const saveRiders = async () => {
    if (assignRoute === null) return;
    const route = routes.find((r) => r.id === assignRoute);
    if (route && selectedRiders.length > route.capacity) {
      toast(
        `This route capacity is ${route.capacity}. Please review the selected riders.`,
        "error",
      );
      return;
    }
    await db.transaction("rw", db.students, async () => {
      for (const s of students) {
        if (s.routeId === assignRoute && !selectedRiders.includes(s.id!))
          await db.students.update(s.id!, {
            routeId: undefined,
            travelMode: "None",
            vehicleNumber: "",
            updatedAt: new Date().toISOString(),
          });
        else if (selectedRiders.includes(s.id!) && s.routeId !== assignRoute)
          await db.students.update(s.id!, {
            routeId: assignRoute,
            travelMode: "School route",
            vehicleNumber: route?.vehicle || "",
            updatedAt: new Date().toISOString(),
          });
      }
    });
    await audit(
      currentUser(),
      "Updated transport assignments",
      "Transport route",
      assignRoute,
      `${selectedRiders.length} students`,
    );
    toast(`${selectedRiders.length} students assigned to ${route?.name}.`);
    setAssignRoute(null);
  };
  const list = routes.filter((r) =>
    [r.name, r.vehicle, r.driver].some((v) =>
      v.toLowerCase().includes(q.toLowerCase()),
    ),
  );
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="SCHOOL OPERATIONS"
        title="Transport"
        subtitle="Manage routes, vehicle details and student assignments."
        action={
          <Button onClick={() => show()}>
            <Plus size={17} /> Add route
          </Button>
        }
      />
      <div className="transport-kpis">
        <div>
          <span className="transport-kpi-icon lavender">
            <BusFront size={17} />
          </span>
          <span>
            <small>Active routes</small>
            <b>{routes.filter((r) => r.status === "Active").length}</b>
          </span>
        </div>
        <div>
          <span className="transport-kpi-icon mint">
            <Users size={17} />
          </span>
          <span>
            <small>Students using transport</small>
            <b>{students.filter((s) => s.routeId).length}</b>
          </span>
        </div>
        <div>
          <span className="transport-kpi-icon peach">
            <IndianRupee size={17} />
          </span>
          <span>
            <small>Monthly route value</small>
            <b>
              {money(
                routes.reduce(
                  (a, r) =>
                    a +
                    r.monthlyFee *
                      students.filter((s) => s.routeId === r.id).length,
                  0,
                ),
              )}
            </b>
          </span>
        </div>
      </div>
      <Card className="list-card">
        <div className="list-toolbar">
          <SearchBox
            value={q}
            onChange={setQ}
            placeholder="Search route, vehicle or driver…"
          />
          <span className="row-count">{list.length} routes</span>
        </div>
        {list.length ? (
          <div className="route-grid">
            {list.map((r) => {
              const riders = students.filter((s) => s.routeId === r.id);
              return (
                <div className="route-card" key={r.id}>
                  <div className="route-card-head">
                    <span className="route-bus">
                      <BusFront size={19} />
                    </span>
                    <Badge tone={makeTone(r.status)}>{r.status}</Badge>
                    <button
                      className="row-more"
                      onClick={() => show(r.id)}
                      aria-label="Edit route"
                    >
                      <ArrowUpRight size={16} />
                    </button>
                  </div>
                  <h3>{r.name}</h3>
                  <div className="route-vehicle">
                    {r.vehicle} <span>·</span>{" "}
                    {r.driver || "Driver not assigned"}
                  </div>
                  <div className="route-info-grid">
                    <div>
                      <small>DRIVER PHONE</small>
                      <b>{r.phone || "—"}</b>
                    </div>
                    <div>
                      <small>MONTHLY FEE</small>
                      <b>{money(r.monthlyFee)}</b>
                    </div>
                  </div>
                  <div
                    className={`route-capacity ${riders.length >= r.capacity ? "capacity-full" : ""}`}
                  >
                    <div className="route-capacity-text">
                      <span>
                        <Users size={14} /> {riders.length} / {r.capacity}{" "}
                        students
                      </span>
                      <b>
                        {r.capacity
                          ? Math.round((riders.length / r.capacity) * 100)
                          : 0}
                        %
                      </b>
                    </div>
                    <div className="progress-track">
                      <i
                        style={{
                          width: `${Math.min(100, r.capacity ? (riders.length / r.capacity) * 100 : 0)}%`,
                        }}
                      />
                    </div>
                  </div>
                  <button
                    className="route-manage"
                    onClick={() => manage(r.id!)}
                  >
                    Manage students <ArrowRight size={15} />
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          <EmptyState
            title="No transport routes yet"
            text="Create your first route and assign students from the roster."
            icon={<BusFront size={22} />}
          />
        )}
      </Card>
      <div className="inline-advice">
        <span>✦</span>
        <div>
          <b>Route fee flows into student dues.</b>
          <small>
            Set the monthly route fee here, then add it to the matching class
            fee structure.
          </small>
        </div>
        <Link to="/fees/structure">
          Review fee plans <ArrowRight size={14} />
        </Link>
      </div>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? "Edit transport route" : "Add a transport route"}
        subtitle="Route details are stored offline with the student assignments."
      >
        <form className="form-grid" onSubmit={save}>
          <Input
            label="Route name"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            placeholder="e.g. North route"
            required
          />
          <Input
            label="Vehicle number"
            value={draft.vehicle}
            onChange={(e) => setDraft({ ...draft, vehicle: e.target.value })}
            placeholder="MH 01 AB 1234"
            required
          />
          <Input
            label="Driver name"
            value={draft.driver}
            onChange={(e) => setDraft({ ...draft, driver: e.target.value })}
          />
          <Input
            label="Driver phone"
            value={draft.phone}
            onChange={(e) =>
              setDraft({
                ...draft,
                phone: e.target.value.replace(/\D/g, "").slice(0, 10),
              })
            }
            inputMode="numeric"
          />
          <Input
            label="Monthly fee (₹)"
            type="number"
            min="0"
            value={draft.monthlyFee}
            onChange={(e) =>
              setDraft({ ...draft, monthlyFee: Number(e.target.value) })
            }
          />
          <Input
            label="Capacity"
            type="number"
            min="1"
            value={draft.capacity}
            onChange={(e) =>
              setDraft({ ...draft, capacity: Number(e.target.value) })
            }
          />
          <Textarea
            label="Route notes"
            className="full-span"
            value={draft.remarks}
            onChange={(e) => setDraft({ ...draft, remarks: e.target.value })}
            rows={2}
          />
          <div className="modal-actions full-span">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit">
              Save route <ArrowRight size={16} />
            </Button>
          </div>
        </form>
      </Modal>
      <Modal
        open={assignRoute !== null}
        onClose={() => setAssignRoute(null)}
        title="Manage route students"
        subtitle={routes.find((r) => r.id === assignRoute)?.name || ""}
        size="lg"
      >
        <div className="rider-toolbar">
          <SearchBox
            value={q}
            onChange={setQ}
            placeholder="Search student or class…"
          />
          <span className="row-count">{selectedRiders.length} selected</span>
        </div>
        <div className="rider-list">
          {students
            .filter((s) =>
              [s.name, s.admissionNo].some((v) =>
                v.toLowerCase().includes(q.toLowerCase()),
              ),
            )
            .map((s) => (
              <label className="rider-row" key={s.id}>
                <input
                  type="checkbox"
                  checked={selectedRiders.includes(s.id!)}
                  onChange={(e) =>
                    setSelectedRiders((prev) =>
                      e.target.checked
                        ? [...prev, s.id!]
                        : prev.filter((id) => id !== s.id),
                    )
                  }
                />
                <Avatar name={s.name} photo={s.photo} size="sm" />
                <span>
                  <b>{s.name}</b>
                  <small>
                    {classes.find((c) => c.id === s.classId)?.name}-{s.section}{" "}
                    · {s.admissionNo}
                  </small>
                </span>
                {s.routeId && s.routeId !== assignRoute && (
                  <Badge tone="amber">Other route</Badge>
                )}
              </label>
            ))}
        </div>
        <div className="modal-actions">
          <Button variant="secondary" onClick={() => setAssignRoute(null)}>
            Cancel
          </Button>
          <Button onClick={() => void saveRiders()}>
            Save assignments <Check size={16} />
          </Button>
        </div>
      </Modal>
    </div>
  );
}

const reportTypes = [
  "Admission Register",
  "Active Students",
  "Left Students",
  "TC Register",
  "Class-wise Student List",
  "Fee Pending",
  "Fee Ledger",
  "Teacher List",
  "Transport Report",
  "Audit Log",
];
export function ReportsPage() {
  const settings = useSettings();
  const students =
    useLiveQuery(
      () => db.students.filter((s) => !s.deletedAt).toArray(),
      [],
      [],
    ) || [];
  const classes = useLiveQuery(() => db.classes.toArray(), [], []) || [];
  const teachers = useLiveQuery(() => db.teachers.toArray(), [], []) || [];
  const dues = useLiveQuery(() => db.feeDues.toArray(), [], []) || [];
  const payments = useLiveQuery(() => db.feePayments.toArray(), [], []) || [];
  const routes = useLiveQuery(() => db.transportRoutes.toArray(), [], []) || [];
  const logs =
    useLiveQuery(
      () => db.auditLogs.orderBy("createdAt").reverse().toArray(),
      [],
      [],
    ) || [];
  const [report, setReport] = useState(reportTypes[0]);
  const [q, setQ] = useState("");
  const [classFilter, setClassFilter] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [columns, setColumns] = useState<string[]>([]);
  const rows = useMemo(() => {
    let data: Record<string, unknown>[] = [];
    if (
      report === "Admission Register" ||
      report === "Active Students" ||
      report === "Left Students" ||
      report === "TC Register" ||
      report === "Class-wise Student List"
    )
      data = students
        .filter((s) =>
          report === "Admission Register"
            ? true
            : report === "Active Students"
              ? s.status === "Active"
              : report === "Left Students"
                ? s.status === "Left"
                : report === "TC Register"
                  ? s.status === "TC Issued"
                  : true,
        )
        .map((s) => ({
          admission_number: s.admissionNo,
          student: s.name,
          father_or_guardian: s.father,
          mother: s.mother,
          class: classes.find((c) => c.id === s.classId)?.name || "Class",
          section: s.section,
          roll: s.roll,
          mobile: s.mobile,
          status: s.status,
          admission_date: s.admissionDate,
          session: s.session,
        }));
    else if (report === "Fee Pending")
      data = dues
        .filter((d) => d.balance > 0)
        .map((d) => {
          const student = students.find((s) => s.id === d.studentId);
          return {
            student: student?.name || "Student",
            admission_number: student?.admissionNo,
            class:
              classes.find((c) => c.id === student?.classId)?.name || "Class",
            section: student?.section,
            month: d.month,
            total: d.total,
            paid: d.paid,
            balance: d.balance,
            status: d.status,
          };
        });
    else if (report === "Fee Ledger") {
      for (const d of dues) {
        const student = students.find((s) => s.id === d.studentId);
        const pays = payments.filter((p) => p.dueId === d.id);
        if (pays.length)
          for (const p of pays)
            data.push({
              receipt_number: p.receiptNo,
              student: student?.name || "Student",
              admission_number: student?.admissionNo,
              month: d.month,
              amount: p.amount,
              payment_mode: p.mode,
              paid_date: p.paidAt.slice(0, 10),
            });
        else
          data.push({
            receipt_number: "—",
            student: student?.name || "Student",
            admission_number: student?.admissionNo,
            month: d.month,
            amount: 0,
            payment_mode: "—",
            paid_date: "—",
          });
      }
    } else if (report === "Teacher List")
      data = teachers.map((t) => ({
        teacher_id: t.teacherId,
        name: t.name,
        subject: t.subject,
        mobile: t.mobile,
        qualification: t.qualification,
        joining_date: t.joiningDate,
        status: t.status,
        salary_suggestion: t.salary,
      }));
    else if (report === "Transport Report")
      data = routes.map((r) => ({
        route: r.name,
        vehicle: r.vehicle,
        driver: r.driver,
        driver_phone: r.phone,
        students: students.filter((s) => s.routeId === r.id).length,
        monthly_total:
          r.monthlyFee * students.filter((s) => s.routeId === r.id).length,
        status: r.status,
      }));
    else if (report === "Audit Log")
      data = logs.map((l) => ({
        date: l.createdAt.slice(0, 10),
        time: new Date(l.createdAt).toLocaleTimeString("en-IN"),
        user: l.username,
        action: l.action,
        entity: l.entity,
        record: l.entityId,
        details: l.details,
      }));
    return data.filter((r) => {
      const text = Object.values(r).join(" ").toLowerCase();
      const classOk = classFilter === "all" || String(r.class) === classFilter;
      const fromOk =
        !from ||
        String(r.admission_date || r.paid_date || r.date || "") >= from;
      const toOk =
        !to || String(r.admission_date || r.paid_date || r.date || "") <= to;
      return classOk && fromOk && toOk && text.includes(q.toLowerCase());
    });
  }, [
    report,
    students,
    classes,
    teachers,
    dues,
    payments,
    routes,
    logs,
    classFilter,
    from,
    to,
    q,
  ]);
  const keys = rows.length ? Object.keys(rows[0]) : [];
  const shownColumns = columns.length
    ? columns.filter((c) => keys.includes(c))
    : keys;
  useEffect(() => {
    setColumns([]);
  }, [report]);
  const exportCsv = () => {
    if (!rows.length) return;
    const normalized = rows.map((r) =>
      Object.fromEntries(shownColumns.map((k) => [k, r[k]])),
    );
    saveFile(
      new Blob([csvString(normalized)], { type: "text/csv;charset=utf-8" }),
      `${report.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${todayISO()}.csv`,
    );
  };
  const print = () => {
    const printableRows = rows.map((row) =>
      Object.fromEntries(
        shownColumns.map((column) => {
          const value = row[column];
          const key = String(column).toLowerCase();
          const formatAsMoney =
            (typeof value === "number" && key.includes("amount")) ||
            key.includes("balance") ||
            key.includes("total");
          return [
            column,
            formatAsMoney ? money(Number(value)) : String(value ?? "—"),
          ];
        }),
      ),
    );
    const filterSummary = [
      classFilter !== "all" ? `Class: ${classFilter}` : "All classes",
      from ? `From ${displayDate(from)}` : "",
      to ? `To ${displayDate(to)}` : "",
      q ? `Search: ${q}` : "",
    ]
      .filter(Boolean)
      .join(" · ");
    printDataReport(
      {
        title: report,
        columns: shownColumns,
        rows: printableRows,
        subtitle: filterSummary,
      },
      printSchoolFromSettings(settings),
    );
  };
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="SCHOOL INSIGHTS"
        title="Reports"
        subtitle="Find your school’s story, apply filters and take a clean copy with you."
        action={
          <div className="report-actions">
            <Button
              variant="secondary"
              onClick={exportCsv}
              disabled={!rows.length}
            >
              <Download size={15} /> Export CSV
            </Button>
            <Button onClick={print} disabled={!rows.length}>
              <Printer size={15} /> Print / PDF
            </Button>
          </div>
        }
      />
      <div className="report-type-strip">
        {reportTypes.map((r, i) => (
          <button
            key={r}
            onClick={() => setReport(r)}
            className={report === r ? "active" : ""}
          >
            <span>{String(i + 1).padStart(2, "0")}</span>
            {r}
          </button>
        ))}
      </div>
      <Card className="report-card">
        <div className="report-heading">
          <div>
            <span className="card-eyebrow">
              {settings.schoolName || "SCHOOL REPORT"}
            </span>
            <h2>{report}</h2>
            <p>
              Report prepared on {displayDate(todayISO())} · {rows.length}{" "}
              records
            </p>
          </div>
          <div className="report-icon">
            <FileChartColumnIcon />
          </div>
        </div>
        <div className="report-filters">
          <SearchBox
            value={q}
            onChange={setQ}
            placeholder="Search inside report…"
          />
          {[
            "Admission Register",
            "Active Students",
            "Left Students",
            "TC Register",
            "Class-wise Student List",
            "Fee Pending",
            "Fee Ledger",
          ].includes(report) && (
            <Select
              aria-label="Filter by class"
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
            >
              <option value="all">All classes</option>
              {classes.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name} · {c.section}
                </option>
              ))}
            </Select>
          )}
          <Input
            aria-label="From date"
            type="date"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
          />
          <Input
            aria-label="To date"
            type="date"
            value={to}
            onChange={(e) => setTo(e.target.value)}
          />
          <button
            className="column-chooser"
            onClick={() => {
              if (!keys.length) return;
              const visible = columns.length ? columns : keys;
              setColumns(
                visible.length === keys.length
                  ? keys.slice(0, Math.max(1, keys.length - 1))
                  : keys,
              );
            }}
          >
            <ListFilter size={15} /> Columns
          </button>
        </div>
        {rows.length ? (
          <TableWrap>
            <table className="data-table report-table">
              <thead>
                <tr>
                  {shownColumns.map((k) => (
                    <th key={k}>{k.replace(/_/g, " ").toUpperCase()}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={i}>
                    {shownColumns.map((k) => (
                      <td key={k}>
                        {(typeof r[k] === "number" &&
                          String(k).toLowerCase().includes("amount")) ||
                        String(k).includes("balance") ||
                        String(k).includes("total")
                          ? money(Number(r[k]))
                          : String(r[k] ?? "—")}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        ) : (
          <EmptyState
            title="No report rows match"
            text="Aapke filters ke hisaab se records nahi mile. Filters update karke dekhein."
            icon={<FileChartColumn size={22} />}
          />
        )}
        <div className="report-footer">
          <span>
            <ShieldCheck size={14} /> Data generated from this device’s local
            records.
          </span>
          <span>
            {settings.printFooter || "SchoolFlow · Private school records"}
          </span>
        </div>
      </Card>
    </div>
  );
}
function FileChartColumnIcon() {
  return <FileChartColumn size={19} />;
}

export function NotificationsPage() {
  const user = useAuth((state) => state.user);
  const classes = useClasses();
  const isTeacher = user?.role === "Teacher";
  const canViewFees = ["Admin", "Principal", "Accountant"].includes(
    user?.role || "",
  );
  const canViewExams = ["Admin", "Principal", "Teacher"].includes(
    user?.role || "",
  );
  const canViewAttendance = ["Admin", "Principal", "Teacher"].includes(
    user?.role || "",
  );
  const canBackup = user?.role === "Admin" || user?.role === "Accountant";
  const canViewPayroll = ["Admin", "Principal", "Accountant"].includes(
    user?.role || "",
  );
  const canViewIntegrity =
    user?.role === "Admin" || user?.role === "Accountant";
  const stored =
    useLiveQuery(
      () => db.notifications.orderBy("createdAt").reverse().toArray(),
      [],
      [],
    ) || [];
  const dues =
    useLiveQuery<FeeDue[], FeeDue[]>(
      () =>
        canViewFees ? db.feeDues.toArray() : Promise.resolve([] as FeeDue[]),
      [canViewFees],
      [],
    ) || [];
  const allExams =
    useLiveQuery<Exam[], Exam[]>(
      () => (canViewExams ? db.exams.toArray() : Promise.resolve([] as Exam[])),
      [canViewExams],
      [],
    ) || [];
  const exams = isTeacher
    ? allExams.filter((exam) =>
        classes.some(
          (schoolClass) =>
            schoolClass.id === exam.classId &&
            schoolClass.section === exam.section &&
            schoolClass.session === exam.session,
        ),
      )
    : allExams;
  const allStudents =
    useLiveQuery(
      () =>
        db.students
          .filter(
            (student) => !student.deletedAt && student.status === "Active",
          )
          .toArray(),
      [],
      [],
    ) || [];
  const students = isTeacher
    ? allStudents.filter((student) =>
        classes.some(
          (schoolClass) =>
            schoolClass.id === student.classId &&
            schoolClass.section === student.section &&
            schoolClass.session === student.session,
        ),
      )
    : allStudents;
  const structures =
    useLiveQuery<FeeStructure[], FeeStructure[]>(
      () =>
        canViewIntegrity
          ? db.feeStructures.toArray()
          : Promise.resolve([] as FeeStructure[]),
      [canViewIntegrity],
      [],
    ) || [];
  const settings = useSettings();
  const currentMonth = monthISO();
  const today = todayISO();
  const allAttendance =
    useLiveQuery<Attendance[], Attendance[]>(
      () =>
        canViewAttendance
          ? db.attendance
              .filter((row) => row.date.startsWith(currentMonth))
              .toArray()
          : Promise.resolve([] as Attendance[]),
      [currentMonth, canViewAttendance],
      [],
    ) || [];
  const attendance = isTeacher
    ? allAttendance.filter((row) =>
        classes.some(
          (schoolClass) =>
            schoolClass.id === row.classId &&
            schoolClass.section === row.section &&
            schoolClass.session === row.session,
        ),
      )
    : allAttendance;
  const payroll =
    useLiveQuery<Payroll[], Payroll[]>(
      () =>
        canViewPayroll
          ? db.payroll.toArray()
          : Promise.resolve([] as Payroll[]),
      [canViewPayroll],
      [],
    ) || [];
  const { toast } = useToast();
  const [filter, setFilter] = useState("All");
  const [severityFilter, setSeverityFilter] = useState("all");
  useEffect(() => {
    if (!user) return;
    let active = true;
    const createdAt = new Date().toISOString();
    const candidates: {
      type: string;
      title: string;
      message: string;
      module: string;
      severity: "info" | "warning" | "danger";
      fingerprint: string;
      relatedId?: number | string;
      createdAt: string;
      isRead: boolean;
    }[] = [];
    const add = (
      notice: Omit<(typeof candidates)[number], "createdAt" | "isRead">,
    ) => candidates.push({ ...notice, createdAt, isRead: false });
    const pending = dues.filter((due) => due.balance > 0);
    if (canViewFees && pending.length) {
      add({
        type: "fees",
        title: "Pending fees need a look",
        message: `${pending.length} fee entries have a balance of ${money(pending.reduce((sum, due) => sum + due.balance, 0))}.`,
        module: "/fees/pending",
        severity: "warning",
        fingerprint: `fees-${currentMonth}`,
      });
    }
    exams
      .filter(
        (exam) =>
          exam.status !== "Completed" &&
          exam.date >= today &&
          exam.date <= addDaysISO(today, 30),
      )
      .slice(0, 10)
      .forEach((exam) => {
        add({
          type: "exam",
          title: `${exam.name} is coming up`,
          message: `${displayDate(exam.date)} · ${exam.subjects.length} subjects planned.`,
          module: "/exams",
          severity: "info",
          fingerprint: `exam-${exam.id}-${exam.date}`,
          relatedId: exam.id,
        });
      });
    students
      .filter((student) => student.dob?.slice(5) === today.slice(5))
      .forEach((student) => {
        add({
          type: "birthday",
          title: `Birthday today: ${student.name}`,
          message: `Remember to wish ${student.name} a happy birthday.`,
          module: "/students",
          severity: "info",
          fingerprint: `birthday-${today}-${student.id}`,
          relatedId: student.id,
        });
      });
    const dueFrequency = String(
      settings.autoBackupFrequency || settings.autoBackup || "weekly",
    );
    const backupInterval =
      dueFrequency === "daily"
        ? 24 * 60 * 60 * 1000
        : dueFrequency === "monthly"
          ? 30 * 24 * 60 * 60 * 1000
          : 7 * 24 * 60 * 60 * 1000;
    const lastBackupAt = settings.lastBackup
      ? new Date(settings.lastBackup).getTime()
      : 0;
    const isBackupDue =
      canBackup &&
      dueFrequency !== "off" &&
      (!lastBackupAt || Date.now() - lastBackupAt >= backupInterval);
    if (isBackupDue) {
      const overdueBucket = lastBackupAt
        ? Math.floor((Date.now() - lastBackupAt) / backupInterval)
        : "never";
      add({
        type: "backup",
        title: "Keep a fresh backup",
        message: lastBackupAt
          ? `Your last backup was ${displayDate(new Date(lastBackupAt).toISOString().slice(0, 10))}. Download a new .schoolerp file now.`
          : "School data lives in this device’s browser storage. Make your first backup file to keep it safe.",
        module: "/backup",
        severity: "warning",
        fingerprint: `backup-${dueFrequency}-${overdueBucket}`,
      });
    }
    const pendingSalary = payroll.filter(
      (row) => row.month === currentMonth && row.status === "Unpaid",
    );
    if (canViewPayroll && pendingSalary.length) {
      add({
        type: "salary",
        title: "Salary payments are pending",
        message: `${pendingSalary.length} payroll entries total ${money(pendingSalary.reduce((sum, row) => sum + row.net, 0))} for ${displayMonth(currentMonth)}.`,
        module: "/payroll",
        severity: "warning",
        fingerprint: `salary-${currentMonth}`,
      });
    }
    const byStudent = new Map<
      number,
      { name: string; present: number; marked: number }
    >();
    for (const row of attendance) {
      const current = byStudent.get(row.studentId) || {
        name:
          students.find((student) => student.id === row.studentId)?.name ||
          "Student",
        present: 0,
        marked: 0,
      };
      current.marked += 1;
      if (row.status !== "Absent") current.present += 1;
      byStudent.set(row.studentId, current);
    }
    for (const [studentId, summary] of byStudent) {
      const percent = summary.marked
        ? Math.round((summary.present / summary.marked) * 100)
        : 100;
      if (summary.marked >= 5 && percent < 75)
        add({
          type: "attendance",
          title: `Low attendance: ${summary.name}`,
          message: `${summary.name} has ${percent}% attendance in ${displayMonth(currentMonth)}. Review and contact the family if needed.`,
          module: "/attendance/summary",
          severity: "warning",
          fingerprint: `attendance-${currentMonth}-${studentId}`,
          relatedId: studentId,
        });
    }
    if (canViewIntegrity) {
      const missingPlans = students.filter(
        (student) =>
          !structures.some(
            (structure) =>
              structure.classId === student.classId &&
              structure.section === student.section &&
              structure.session === student.session,
          ),
      ).length;
      if (missingPlans)
        add({
          type: "integrity",
          title: "Fee structures are missing",
          message: `${missingPlans} active students do not have a matching fee plan for their class and session.`,
          module: "/data-integrity",
          severity: "danger",
          fingerprint: `integrity-fees-${currentMonth}`,
        });
    }
    void (async () => {
      const existing = await db.notifications.toArray();
      if (!active) return;
      const fingerprints = new Set(
        existing.map((notice) => notice.fingerprint).filter(Boolean),
      );
      const fresh = candidates.filter(
        (notice) => !fingerprints.has(notice.fingerprint),
      );
      if (fresh.length) await db.notifications.bulkAdd(fresh);
    })().catch(() => undefined);
    return () => {
      active = false;
    };
  }, [
    user?.id,
    user?.role,
    classes,
    dues,
    exams,
    students,
    structures,
    settings.lastBackup,
    settings.autoBackup,
    settings.autoBackupFrequency,
    attendance,
    payroll,
    canViewFees,
    canBackup,
    canViewPayroll,
    canViewIntegrity,
    currentMonth,
    today,
  ]);
  const visibleModulesByRole: Record<Role, string[]> = {
    Admin: [
      "/fees/pending",
      "/exams",
      "/students",
      "/backup",
      "/payroll",
      "/attendance/summary",
      "/data-integrity",
    ],
    Principal: [
      "/fees/pending",
      "/exams",
      "/students",
      "/payroll",
      "/attendance/summary",
    ],
    Teacher: ["/exams", "/students", "/attendance/summary"],
    Accountant: [
      "/fees/pending",
      "/backup",
      "/payroll",
      "/data-integrity",
      "/students",
    ],
    Reception: ["/students"],
  };
  const allowedModules = new Set(user ? visibleModulesByRole[user.role] : []);
  const visibleStudentIds = new Set(students.map((student) => student.id));
  const visibleExamIds = new Set(exams.map((exam) => exam.id));
  const visibleStored = stored.filter((notice) => {
    if (!allowedModules.has(notice.module)) return false;
    if (
      (notice.type === "birthday" || notice.type === "attendance") &&
      isTeacher
    )
      return visibleStudentIds.has(Number(notice.relatedId));
    if (notice.type === "exam")
      return (
        notice.relatedId === undefined ||
        visibleExamIds.has(Number(notice.relatedId))
      );
    if (notice.type === "birthday" || notice.type === "attendance")
      return (
        notice.relatedId === undefined ||
        visibleStudentIds.has(Number(notice.relatedId))
      );
    return true;
  });
  const visibleTypes = [...new Set(visibleStored.map((notice) => notice.type))];
  const list = visibleStored
    .filter(
      (notice) =>
        filter === "All" ||
        (filter === "Unread" ? !notice.isRead : notice.type === filter),
    )
    .filter(
      (notice) =>
        severityFilter === "all" || notice.severity === severityFilter,
    )
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const markRead = async (id: number | undefined) => {
    if (typeof id === "number")
      await db.notifications.update(id, { isRead: true });
  };
  const markAll = async () => {
    await Promise.all(
      visibleStored
        .filter((notice) => !notice.isRead && typeof notice.id === "number")
        .map((notice) => db.notifications.update(notice.id!, { isRead: true })),
    );
    toast("Notifications marked as read.");
  };
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="YOUR SCHOOL PULSE"
        title="Notifications"
        subtitle={
          isTeacher
            ? "Reminders and notices for your assigned classes."
            : "Fee, attendance, backup, exam, birthday and payroll reminders for this device."
        }
        action={
          <Button
            variant="secondary"
            onClick={() => void markAll()}
            disabled={!visibleStored.some((notice) => !notice.isRead)}
          >
            <Check size={15} /> Mark all as read
          </Button>
        }
      />
      <div className="notification-summary">
        <div className="notification-summary-icon">
          <Bell size={18} />
        </div>
        <span>
          <b>
            {visibleStored.filter((notice) => !notice.isRead).length} unread
            items
          </b>
          <small>Reminders are generated locally when the app is open.</small>
        </span>
        <div className="notification-tabs">
          {["All", "Unread", ...visibleTypes].map((value) => (
            <button
              key={value}
              onClick={() => setFilter(value)}
              className={filter === value ? "active" : ""}
            >
              {value === "All" || value === "Unread"
                ? value
                : value[0].toUpperCase() + value.slice(1)}
            </button>
          ))}
          <Select
            aria-label="Filter notifications by severity"
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
          >
            <option value="all">All severity</option>
            <option value="info">Info</option>
            <option value="warning">Warning</option>
            <option value="danger">Urgent</option>
          </Select>
        </div>
      </div>
      <div className="notification-list">
        {list.length ? (
          list.map((notice) => (
            <Link
              to={notice.module}
              key={notice.id}
              onClick={() => void markRead(notice.id)}
              className={`notification-item ${notice.isRead ? "read" : ""}`}
            >
              <span className={`notification-icon severity-${notice.severity}`}>
                {notice.type === "fees" || notice.type === "salary" ? (
                  <WalletCards size={17} />
                ) : notice.type === "exam" ? (
                  <ClipboardList size={17} />
                ) : notice.type === "birthday" ? (
                  <Sparkles size={17} />
                ) : notice.type === "attendance" ? (
                  <CalendarCheck size={17} />
                ) : (
                  <ShieldCheck size={17} />
                )}
              </span>
              <span className="notification-copy">
                <span className="notification-type">
                  {notice.type.toUpperCase()} ·{" "}
                  {displayDate(notice.createdAt.slice(0, 10))}
                </span>
                <b>{notice.title}</b>
                <small>{notice.message}</small>
              </span>
              {!notice.isRead && <i className="unread-indicator" />}
              <ArrowUpRight size={16} className="notification-arrow" />
            </Link>
          ))
        ) : (
          <Card>
            <EmptyState
              title="All caught up"
              text="No notifications match these filters."
              icon={<CheckCircle2 size={22} />}
            />
          </Card>
        )}
      </div>
    </div>
  );
}

function readLocalBackupHistory(): any[] {
  try {
    const parsed = JSON.parse(
      localStorage.getItem("schoolflow-backup-log") || "[]",
    );
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function pruneBackupHistory(limit: number) {
  const keepCount = Math.min(100, Math.max(1, Math.trunc(Number(limit) || 12)));
  try {
    localStorage.setItem(
      "schoolflow-backup-log",
      JSON.stringify(readLocalBackupHistory().slice(0, keepCount)),
    );
  } catch {
    // The durable Dexie log below remains the source of truth if localStorage is unavailable.
  }
  const saved = await db.backupLogs.orderBy("createdAt").reverse().toArray();
  const expiredIds = saved
    .slice(keepCount)
    .map((row) => row.id)
    .filter((id): id is number => typeof id === "number");
  if (expiredIds.length) await db.backupLogs.bulkDelete(expiredIds);
}

async function createBackupBlob() {
  const tables: Record<string, unknown[]> = {};
  for (const name of tablesForBackup) {
    tables[name] = await db.table(name).toArray();
  }
  const payload = {
    app: "SchoolFlow",
    version: 1,
    createdAt: new Date().toISOString(),
    tables,
  };
  return new Blob([JSON.stringify(payload)], {
    type: "application/vnd.schoolflow.backup+json",
  });
}
async function downloadBackup(
  type: "download" | "safety" = "download",
  share = false,
) {
  const blob = await createBackupBlob();
  const filename = `schoolflow-backup-${todayISO()}.schoolerp`;
  const createdAt = new Date().toISOString();
  const backupFile = new File([blob], filename, { type: blob.type });
  if (
    share &&
    navigator.share &&
    navigator.canShare?.({ files: [backupFile] })
  ) {
    await navigator.share({
      files: [backupFile],
      title: "SchoolFlow backup",
      text: "Encrypted nahi hai — is school backup file ko private rakhein.",
    });
  } else {
    saveFile(blob, filename);
  }
  await saveSetting("lastBackup", createdAt);
  const keepCount = Math.min(
    100,
    Math.max(
      1,
      Math.trunc(Number(await setting<number>("keepBackupsCount", 12)) || 12),
    ),
  );
  const logs = readLocalBackupHistory();
  logs.unshift({ filename, size: blob.size, createdAt, type });
  try {
    localStorage.setItem("schoolflow-backup-log", JSON.stringify(logs));
  } catch {
    // Continue: the durable backup log is stored in IndexedDB.
  }
  await db.backupLogs.add({
    filename,
    size: blob.size,
    type,
    verified: true,
    createdAt,
  });
  await pruneBackupHistory(keepCount);
  return { filename, size: blob.size };
}

export function BackupPage() {
  const settings = useSettings();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [restorePreview, setRestorePreview] = useState<{
    tables: Record<string, unknown[]>;
    createdAt: string;
    counts: Record<string, number>;
  } | null>(null);
  const [storage, setStorage] = useState<{
    usage: number;
    quota: number;
  } | null>(null);
  const [history, setHistory] = useState<any[]>([]);
  useEffect(() => {
    setHistory(readLocalBackupHistory());
    navigator.storage
      ?.estimate()
      .then((x) => setStorage({ usage: x.usage || 0, quota: x.quota || 0 }))
      .catch(() => {});
  }, [settings.lastBackup, settings.keepBackupsCount]);
  const exportNow = async () => {
    setBusy(true);
    try {
      const result = await downloadBackup();
      setHistory(readLocalBackupHistory());
      toast(`${result.filename} downloaded. Keep it somewhere safe.`);
    } catch {
      toast("Backup could not be created. Please try again.", "error");
    } finally {
      setBusy(false);
    }
  };
  const shareNow = async () => {
    setBusy(true);
    try {
      const result = await downloadBackup("download", true);
      setHistory(readLocalBackupHistory());
      toast(`${result.filename} shared. Keep a private copy somewhere safe.`);
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") {
        toast("Backup sharing cancelled.", "info");
      } else {
        toast("Sharing failed. Use Download backup instead.", "error");
      }
    } finally {
      setBusy(false);
    }
  };
  const selectRestore = async (file?: File) => {
    if (!file) return;
    setRestoreFile(file);
    try {
      const raw = JSON.parse(await file.text());
      if (raw.app !== "SchoolFlow" || !raw.tables)
        throw new Error("This is not a SchoolFlow backup file.");
      const counts = Object.fromEntries(
        Object.entries(raw.tables as Record<string, unknown[]>).map(
          ([k, v]) => [k, Array.isArray(v) ? v.length : 0],
        ),
      );
      setRestorePreview({
        tables: raw.tables,
        createdAt: raw.createdAt || "",
        counts,
      });
    } catch (e) {
      setRestorePreview(null);
      toast(
        e instanceof Error ? e.message : "Backup file could not be read.",
        "error",
      );
    }
  };
  const restore = async () => {
    if (!restorePreview) return;
    setBusy(true);
    try {
      await downloadBackup("safety");
      await (db.transaction.bind(db) as any)(
        "rw",
        ...tablesForBackup.map((name) => db.table(name)),
        async () => {
          for (const name of tablesForBackup) await db.table(name).clear();
          for (const [name, rows] of Object.entries(restorePreview.tables)) {
            if (
              (tablesForBackup as readonly string[]).includes(name) &&
              Array.isArray(rows) &&
              rows.length
            )
              await db.table(name).bulkPut(rows as any[]);
          }
        },
      );
      await audit(
        currentUser(),
        "Restored backup",
        "Backup",
        restoreFile?.name,
      );
      toast("Backup restored. Reloading the workspace…");
      setTimeout(() => window.location.reload(), 800);
    } catch (e) {
      toast(
        e instanceof Error
          ? `Restore failed safely: ${e.message}`
          : "Restore failed safely.",
        "error",
      );
    } finally {
      setBusy(false);
      setRestorePreview(null);
      setRestoreFile(null);
    }
  };
  const usedPct = storage?.quota
    ? Math.min(100, Math.round((storage.usage / storage.quota) * 100))
    : 0;
  const prettySize = (n: number) =>
    n < 1024
      ? `${n} B`
      : n < 1024 * 1024
        ? `${(n / 1024).toFixed(1)} KB`
        : `${(n / 1024 / 1024).toFixed(1)} MB`;
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="DATA SAFETY"
        title="Backup & restore"
        subtitle="Your school’s database lives in this browser. A backup file is your portable safety net."
      />
      <div className="backup-alert">
        <span className="backup-alert-icon">
          <ShieldCheck size={20} />
        </span>
        <div>
          <b>App ka data is device ke browser storage (IndexedDB) me hai.</b>
          <p>
            Browser data clear ya phone change hone par records ja sakte hain.
            Backup file ko Drive, WhatsApp or a computer par safe rakhein.
          </p>
        </div>
      </div>
      <div className="backup-action-grid">
        <Card className="backup-action-card export-card">
          <div className="backup-action-art export-art">
            <Download size={23} />
            <span />
          </div>
          <span className="card-eyebrow">RECOMMENDED · REGULARLY</span>
          <h3>Create a local backup</h3>
          <p>
            Download one portable <b>.schoolerp</b> file with your school
            records, settings and student photos.
          </p>
          <div className="backup-action-meta">
            <span>Last backup</span>
            <b>
              {settings.lastBackup
                ? displayDate(String(settings.lastBackup).slice(0, 10))
                : "Not yet"}
            </b>
          </div>
          <div className="backup-share-actions">
            <Button size="lg" onClick={() => void exportNow()} disabled={busy}>
              {busy ? (
                "Preparing file…"
              ) : (
                <>
                  <Download size={17} /> Download backup
                </>
              )}
            </Button>
            <Button
              variant="secondary"
              size="lg"
              onClick={() => void shareNow()}
              disabled={busy}
            >
              <Share2 size={16} /> Share file
            </Button>
          </div>
        </Card>
        <Card className="backup-action-card restore-card">
          <div className="backup-action-art restore-art">
            <ShieldCheck size={23} />
            <span />
          </div>
          <span className="card-eyebrow">MOVE TO THIS DEVICE</span>
          <h3>Restore a backup</h3>
          <p>
            Choose a valid SchoolFlow backup. You’ll see a preview before this
            device’s data is replaced.
          </p>
          <label className="file-drop">
            <input
              type="file"
              accept=".schoolerp,.json,application/json"
              onChange={(e) => void selectRestore(e.target.files?.[0])}
            />
            <span className="file-drop-icon">
              <Plus size={18} />
            </span>
            <b>Choose a .schoolerp file</b>
            <small>Tap to browse this device</small>
          </label>
        </Card>
        <Card className="storage-card">
          <div className="card-head">
            <div>
              <span className="card-eyebrow">DEVICE STORAGE</span>
              <h3>Local database</h3>
            </div>
            <span className="storage-icon">
              <Layers3 size={16} />
            </span>
          </div>
          <div className="storage-value">
            <b>{storage ? prettySize(storage.usage) : "—"}</b>
            <span>used by this browser</span>
          </div>
          <div className="storage-track">
            <i style={{ width: `${usedPct}%` }} />
          </div>
          <div className="storage-foot">
            <span>Usage estimate</span>
            <b>
              {storage && storage.quota
                ? prettySize(storage.quota)
                : "Browser limit varies"}
            </b>
          </div>
          <p>
            Keep backups on a separate device. Clearing Chrome data can remove
            local records.
          </p>
        </Card>
      </div>
      <Card className="list-card">
        <div className="card-list-head">
          <div>
            <h3>Backup history</h3>
            <p>This history is a reminder list saved in this browser.</p>
          </div>
          <span className="row-count">{history.length} files</span>
        </div>
        {history.length ? (
          <div className="backup-history-list">
            {history.map((h: any, i: number) => (
              <div key={`${h.filename}-${i}`}>
                <span className="history-file-icon">
                  <FileCheck2 size={16} />
                </span>
                <span>
                  <b>{h.filename}</b>
                  <small>
                    {displayDate(h.createdAt.slice(0, 10))} ·{" "}
                    {prettySize(h.size)}
                  </small>
                </span>
                <Badge tone="green">Downloaded</Badge>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            title="No backups created yet"
            text="Your first backup will show up here after you download it."
            icon={<ShieldCheck size={22} />}
          />
        )}
      </Card>
      <div className="restore-instructions">
        <b>Moving data to a new phone?</b>
        <span>
          Create a backup here → send the .schoolerp file to your new device →
          open SchoolFlow → choose “Restore a backup”.
        </span>
      </div>
      <Modal
        open={!!restorePreview}
        onClose={() => {
          setRestorePreview(null);
          setRestoreFile(null);
        }}
        title="Review backup restore"
        subtitle="Restore replaces current local records. A safety copy will download first."
        size="lg"
      >
        {restorePreview && (
          <>
            <div className="restore-file-header">
              <span className="restore-file-icon">
                <FileCheck2 size={20} />
              </span>
              <span>
                <b>{restoreFile?.name}</b>
                <small>
                  Created {displayDate(restorePreview.createdAt.slice(0, 10))}
                </small>
              </span>
              <Badge tone="green">Verified structure</Badge>
            </div>
            <div className="restore-record-grid">
              {Object.entries(restorePreview.counts)
                .filter(([, c]) => c > 0)
                .map(([name, count]) => (
                  <div key={name}>
                    <span>{name.replace(/([A-Z])/g, " $1")}</span>
                    <b>{count}</b>
                  </div>
                ))}
            </div>
            <div className="restore-warning">
              <CircleAlert size={16} />
              <span>
                Current records will be replaced. First, an emergency backup
                will download to your device.
              </span>
            </div>
            <div className="modal-actions">
              <Button
                variant="secondary"
                onClick={() => {
                  setRestorePreview(null);
                  setRestoreFile(null);
                }}
              >
                Cancel
              </Button>
              <Button
                variant="danger"
                disabled={busy}
                onClick={() => void restore()}
              >
                {busy ? "Restoring…" : "Back up current data & restore"}
                <ArrowRight size={16} />
              </Button>
            </div>
          </>
        )}
      </Modal>
    </div>
  );
}

export function IntegrityPage() {
  const students =
    useLiveQuery(
      () => db.students.filter((s) => !s.deletedAt).toArray(),
      [],
      [],
    ) || [];
  const classes = useLiveQuery(() => db.classes.toArray(), [], []) || [];
  const dues = useLiveQuery(() => db.feeDues.toArray(), [], []) || [];
  const feeStructures =
    useLiveQuery(() => db.feeStructures.toArray(), [], []) || [];
  const payments = useLiveQuery(() => db.feePayments.toArray(), [], []) || [];
  const attendance = useLiveQuery(() => db.attendance.toArray(), [], []) || [];
  const results = useLiveQuery(() => db.examResults.toArray(), [], []) || [];
  const { toast } = useToast();
  const [running, setRunning] = useState(false);
  const [expandedCheck, setExpandedCheck] = useState<string | null>(null);
  const duplicateAdm = students.filter(
    (s, i, a) =>
      a.findIndex(
        (x) => x.normalizedAdmissionNo === s.normalizedAdmissionNo,
      ) !== i,
  );
  const rollKeys = new Map<string, Student[]>();
  students
    .filter((s) => s.status === "Active")
    .forEach((s) => {
      const key = `${s.classId}|${s.section}|${s.session}|${s.roll}`;
      rollKeys.set(key, [...(rollKeys.get(key) || []), s]);
    });
  const duplicateRoll = [...rollKeys.values()]
    .filter((a) => a.length > 1)
    .flat();
  const missingClass = students.filter(
    (s) => !classes.some((c) => c.id === s.classId),
  );
  const badMobile = students.filter((s) => !validMobile(s.mobile));
  const invalidAadhaar = students.filter(
    (s) => s.aadhaar && !validAadhaar(s.aadhaar),
  );
  const mismatched = dues.filter(
    (d) =>
      roundMoney(
        d.tuition +
          d.transport +
          d.exam +
          d.admission +
          d.library +
          d.other -
          d.discount +
          d.fine,
      ) !== d.total,
  );
  const invalidResults = results.filter(
    (r) => r.marks > r.maxMarks || r.marks < 0,
  );
  const invalidReceipts = payments.filter(
    (p) => !p.voidedAt && (!Number.isFinite(p.amount) || p.amount <= 0),
  );
  const missingFeeStructures = students.filter(
    (s) =>
      s.status === "Active" &&
      !feeStructures.some(
        (f) =>
          f.classId === s.classId &&
          f.section === s.section &&
          f.session === s.session,
      ),
  );
  const attendanceGroups = new Map<string, typeof attendance>();
  attendance.forEach((row) => {
    const key = `${row.studentId}|${row.date}`;
    attendanceGroups.set(key, [...(attendanceGroups.get(key) || []), row]);
  });
  const duplicateAttendance = [...attendanceGroups.values()]
    .filter((group) => group.length > 1)
    .flat();
  const mobileFixable = badMobile.filter((s) => {
    const digits = s.mobile.replace(/\D/g, "");
    return validMobile(
      digits.length === 12 && digits.startsWith("91")
        ? digits.slice(2)
        : digits,
    );
  });
  const aadhaarFixable = invalidAadhaar.filter(
    (s) => s.aadhaar && /^\d{12}$/.test(s.aadhaar.replace(/\D/g, "")),
  );
  const issuesById: Record<
    string,
    { label: string; detail: string; studentId?: number }[]
  > = {
    admission: duplicateAdm.map((s) => ({
      label: s.name,
      detail: `${s.admissionNo} · ${s.normalizedAdmissionNo}`,
      studentId: s.id,
    })),
    roll: duplicateRoll.map((s) => ({
      label: s.name,
      detail: `${s.classId}-${s.section} · roll ${s.roll}`,
      studentId: s.id,
    })),
    class: missingClass.map((s) => ({
      label: s.name,
      detail: `Admission ${s.admissionNo} · class ID ${s.classId}`,
      studentId: s.id,
    })),
    mobile: badMobile.map((s) => ({
      label: s.name,
      detail: `Stored mobile: ${s.mobile || "blank"}`,
      studentId: s.id,
    })),
    aadhaar: invalidAadhaar.map((s) => ({
      label: s.name,
      detail: `Aadhaar: ${s.aadhaar || "blank"}`,
      studentId: s.id,
    })),
    fees: mismatched.map((d) => ({
      label:
        students.find((s) => s.id === d.studentId)?.name ||
        `Student ${d.studentId}`,
      detail: `${d.month} · stored ${money(d.total)} · balance ${money(d.balance)}`,
      studentId: d.studentId,
    })),
    receipts: invalidReceipts.map((p) => ({
      label: p.receiptNo,
      detail: `Amount ${money(p.amount)} · ${p.mode}`,
    })),
    marks: invalidResults.map((r) => ({
      label:
        students.find((s) => s.id === r.studentId)?.name ||
        `Student ${r.studentId}`,
      detail: `${r.subject} · ${r.marks}/${r.maxMarks}`,
      studentId: r.studentId,
    })),
    attendance: duplicateAttendance.map((a) => ({
      label:
        students.find((s) => s.id === a.studentId)?.name ||
        `Student ${a.studentId}`,
      detail: `${a.date} · ${a.status}`,
      studentId: a.studentId,
    })),
    structure: missingFeeStructures.map((s) => ({
      label: s.name,
      detail: `Class ${s.classId}-${s.section} · session ${s.session}`,
      studentId: s.id,
    })),
  };
  const checks = [
    {
      id: "admission",
      label: "Duplicate admission numbers",
      count: duplicateAdm.length,
      canFix: false,
      icon: <Users size={17} />,
      tone: "rose",
    },
    {
      id: "roll",
      label: "Duplicate rolls in a class",
      count: duplicateRoll.length,
      canFix: true,
      icon: <Layers3 size={17} />,
      tone: "amber",
    },
    {
      id: "class",
      label: "Students without a class",
      count: missingClass.length,
      canFix: false,
      icon: <BookOpenCheck size={17} />,
      tone: "amber",
    },
    {
      id: "mobile",
      label: "Invalid mobile numbers",
      count: badMobile.length,
      canFix: mobileFixable.length > 0,
      icon: <CircleAlert size={17} />,
      tone: "amber",
    },
    {
      id: "aadhaar",
      label: "Invalid Aadhaar numbers",
      count: invalidAadhaar.length,
      canFix: aadhaarFixable.length > 0,
      icon: <ShieldCheck size={17} />,
      tone: "amber",
    },
    {
      id: "fees",
      label: "Fee total mismatches",
      count: mismatched.length,
      canFix: true,
      icon: <WalletCards size={17} />,
      tone: "rose",
    },
    {
      id: "structure",
      label: "Missing fee structures",
      count: missingFeeStructures.length,
      canFix: false,
      icon: <WalletCards size={17} />,
      tone: "amber",
    },
    {
      id: "receipts",
      label: "Zero or negative fee receipts",
      count: invalidReceipts.length,
      canFix: invalidReceipts.length > 0,
      icon: <CircleAlert size={17} />,
      tone: "rose",
    },
    {
      id: "marks",
      label: "Marks outside maximum",
      count: invalidResults.length,
      canFix: invalidResults.length > 0,
      icon: <Award size={17} />,
      tone: "rose",
    },
    {
      id: "attendance",
      label: "Duplicate attendance records",
      count: duplicateAttendance.length,
      canFix: duplicateAttendance.length > 0,
      icon: <CalendarDays size={17} />,
      tone: duplicateAttendance.length ? "rose" : "green",
    },
  ];
  const run = async () => {
    setRunning(true);
    await new Promise((r) => setTimeout(r, 250));
    setRunning(false);
    toast("Integrity checks are up to date.");
  };
  const fix = async (id: string) => {
    if (id === "roll") {
      const active = students.filter((s) => s.status === "Active");
      const groups = new Map<string, Student[]>();
      active.forEach((s) => {
        const key = `${s.classId}|${s.section}|${s.session}`;
        groups.set(key, [...(groups.get(key) || []), s]);
      });
      await db.transaction("rw", db.students, async () => {
        for (const list of groups.values()) {
          list.sort((a, b) => a.roll - b.roll || a.name.localeCompare(b.name));
          const used = new Set<number>();
          let next = 1;
          for (const s of list) {
            let roll = s.roll;
            if (used.has(roll) || !roll) {
              while (used.has(next)) next++;
              roll = next;
            }
            used.add(roll);
            await db.students.update(s.id!, {
              roll,
              updatedAt: new Date().toISOString(),
            });
          }
        }
      });
      await audit(
        currentUser(),
        "Fixed duplicate rolls",
        "Data integrity",
        undefined,
        `${duplicateRoll.length} records`,
      );
      toast("Duplicate roll numbers renumbered by class.");
    }
    if (id === "mobile") {
      const now = new Date().toISOString();
      await db.transaction("rw", db.students, async () => {
        for (const s of mobileFixable) {
          const digits = s.mobile.replace(/\D/g, "");
          const mobile =
            digits.length === 12 && digits.startsWith("91")
              ? digits.slice(2)
              : digits;
          await db.students.update(s.id!, { mobile, updatedAt: now });
        }
      });
      await audit(
        currentUser(),
        "Normalized student mobile numbers",
        "Data integrity",
        undefined,
        `${mobileFixable.length} records`,
      );
      toast(
        `${mobileFixable.length} phone numbers normalized. Review any remaining invalid records manually.`,
      );
    }
    if (id === "aadhaar") {
      const now = new Date().toISOString();
      await db.transaction("rw", db.students, async () => {
        for (const s of aadhaarFixable)
          await db.students.update(s.id!, {
            aadhaar: s.aadhaar!.replace(/\D/g, ""),
            updatedAt: now,
          });
      });
      await audit(
        currentUser(),
        "Normalized Aadhaar digits",
        "Data integrity",
        undefined,
        `${aadhaarFixable.length} records`,
      );
      toast(
        `${aadhaarFixable.length} Aadhaar values normalized. Review any remaining invalid records manually.`,
      );
    }
    if (id === "marks") {
      const now = new Date().toISOString();
      await db.transaction("rw", db.examResults, async () => {
        for (const result of invalidResults) {
          const marks = Math.min(
            Math.max(0, result.marks),
            Math.max(0, result.maxMarks),
          );
          const percent =
            result.maxMarks > 0 ? (marks / result.maxMarks) * 100 : 0;
          await db.examResults.update(result.id!, {
            marks,
            grade: gradeFor(percent),
            result: percent >= 33 ? "Pass" : "Fail",
            updatedAt: now,
          } as any);
        }
      });
      await audit(
        currentUser(),
        "Capped invalid exam marks",
        "Data integrity",
        undefined,
        `${invalidResults.length} records`,
      );
      toast(
        "Invalid marks were clamped to the allowed range. Review the affected results.",
      );
    }
    if (id === "receipts") {
      const now = new Date().toISOString();
      await db.transaction("rw", db.feePayments, db.feeDues, async () => {
        const dueIds = new Set(invalidReceipts.map((payment) => payment.dueId));
        for (const payment of invalidReceipts)
          await db.feePayments.update(payment.id!, {
            voidedAt: now,
            voidReason:
              "Data integrity: receipt amount was zero, negative or invalid.",
          });
        for (const dueId of dueIds) {
          const due = await db.feeDues.get(dueId);
          if (!due) continue;
          const activePayments = await db.feePayments
            .where("dueId")
            .equals(dueId)
            .toArray();
          const paid = roundMoney(
            activePayments
              .filter(
                (payment) =>
                  !payment.voidedAt &&
                  Number.isFinite(payment.amount) &&
                  payment.amount > 0,
              )
              .reduce((sum, payment) => sum + payment.amount, 0),
          );
          const total = roundMoney(
            due.tuition +
              due.transport +
              due.exam +
              due.admission +
              due.library +
              due.other -
              due.discount +
              due.fine,
          );
          const balance = roundMoney(Math.max(0, total - paid));
          await db.feeDues.update(dueId, {
            total,
            paid,
            balance,
            status: balance === 0 ? "Paid" : paid ? "Partial" : "Pending",
            updatedAt: now,
          });
        }
      });
      await audit(
        currentUser(),
        "Voided invalid fee receipts",
        "Data integrity",
        undefined,
        `${invalidReceipts.length} records`,
      );
      toast("Invalid receipts were voided and affected balances recalculated.");
    }
    if (id === "attendance") {
      const groups = new Map<string, typeof attendance>();
      attendance.forEach((row) => {
        const key = `${row.studentId}|${row.date}`;
        groups.set(key, [...(groups.get(key) || []), row]);
      });
      const duplicates = [...groups.values()].filter(
        (group) => group.length > 1,
      );
      await db.transaction("rw", db.attendance, async () => {
        for (const group of duplicates) {
          const keep = group
            .slice()
            .sort((a, b) =>
              (b.updatedAt || "").localeCompare(a.updatedAt || ""),
            )[0];
          for (const row of group)
            if (row.id !== keep.id) await db.attendance.delete(row.id!);
        }
      });
      await audit(
        currentUser(),
        "Removed duplicate attendance records",
        "Data integrity",
        undefined,
        `${duplicateAttendance.length} records`,
      );
      toast(
        "Duplicate attendance entries removed; the latest saved row was kept.",
      );
    }
    if (id === "fees") {
      await db.transaction("rw", db.feeDues, async () => {
        for (const d of mismatched) {
          const total = roundMoney(
            d.tuition +
              d.transport +
              d.exam +
              d.admission +
              d.library +
              d.other -
              d.discount +
              d.fine,
          );
          const balance = roundMoney(Math.max(0, total - d.paid));
          await db.feeDues.update(d.id!, {
            total,
            balance,
            status: balance === 0 ? "Paid" : d.paid ? "Partial" : "Pending",
            updatedAt: new Date().toISOString(),
          });
        }
      });
      await audit(
        currentUser(),
        "Recalculated fee totals",
        "Data integrity",
        undefined,
        `${mismatched.length} records`,
      );
      toast("Fee totals recalculated.");
    }
  };
  const issueCount = checks.filter((c) => c.count > 0).length;
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="DATA QUALITY"
        title="Data integrity"
        subtitle="A small health check for your local records — identify issues before they become confusing."
        action={
          <Button onClick={() => void run()} disabled={running}>
            <ShieldCheck size={16} />
            {running ? "Checking…" : "Run checks"}
          </Button>
        }
      />
      <div className={`integrity-hero ${issueCount ? "has-issues" : ""}`}>
        <div className="integrity-ring">
          <div>
            <b>{issueCount ? issueCount : "✓"}</b>
            <small>{issueCount ? "issues" : "all clear"}</small>
          </div>
        </div>
        <div>
          <span className="card-eyebrow">LOCAL DATA HEALTH</span>
          <h2>
            {issueCount
              ? "A few things need your attention."
              : "Your records look healthy."}
          </h2>
          <p>
            {issueCount
              ? "Review the checks below. Fixes are logged and can be checked again."
              : "No data issues found in the checks currently supported by this workspace."}
          </p>
        </div>
        <div className="integrity-pattern">✦</div>
      </div>
      <Card className="integrity-card">
        <div className="card-list-head">
          <div>
            <h3>Integrity checks</h3>
            <p>
              {students.length} students · {dues.length} fee entries ·{" "}
              {attendance.length} attendance records
            </p>
          </div>
          <span className="row-count">{checks.length} checks</span>
        </div>
        <div className="integrity-list">
          {checks.map((c) => {
            const records = issuesById[c.id] || [];
            return (
              <div className="integrity-wrap" key={c.id}>
                <div className="integrity-item">
                  <span
                    className={`integrity-check-icon ${c.count ? "issue" : ""}`}
                  >
                    {c.icon}
                  </span>
                  <span className="integrity-check-copy">
                    <b>{c.label}</b>
                    <small>
                      {c.id === "roll"
                        ? "Unique within class, section and session."
                        : c.id === "fees"
                          ? "Head totals match discounts, fines and due amount."
                          : c.id === "marks"
                            ? "Every result should be between zero and maximum marks."
                            : c.id === "structure"
                              ? "Every active student should match a class, section and session fee plan."
                              : c.id === "receipts"
                                ? "Receipts must have a positive amount."
                                : c.id === "attendance"
                                  ? "Only one attendance record per student per date."
                                  : "Based on records stored locally."}
                    </small>
                  </span>
                  {c.count > 0 ? (
                    <Badge tone={c.tone}>{c.count} found</Badge>
                  ) : (
                    <Badge tone="green">Clear</Badge>
                  )}
                  {c.count > 0 && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        setExpandedCheck(expandedCheck === c.id ? null : c.id)
                      }
                    >
                      {expandedCheck === c.id ? "Hide" : "View records"}
                    </Button>
                  )}
                  {c.canFix && c.count > 0 && (
                    <Button
                      size="sm"
                      variant="soft"
                      onClick={() => void fix(c.id)}
                    >
                      Fix now
                    </Button>
                  )}
                </div>
                {expandedCheck === c.id && (
                  <div className="integrity-record-list">
                    {records.length ? (
                      records.slice(0, 50).map((record, index) => (
                        <div
                          key={`${c.id}-${record.studentId || record.label}-${index}`}
                        >
                          <span>
                            <b>{record.label}</b>
                            <small>{record.detail}</small>
                          </span>
                          {record.studentId && (
                            <Link to="/students" className="text-link">
                              Open students <ArrowUpRight size={13} />
                            </Link>
                          )}
                        </div>
                      ))
                    ) : (
                      <p>No individual records to show for this check.</p>
                    )}
                    {records.length > 50 && (
                      <small>
                        Showing first 50 of {records.length} records.
                      </small>
                    )}
                    {!c.canFix && c.count > 0 && (
                      <p className="form-helper">
                        No safe automatic correction is available. Review these
                        records and edit the source data manually.
                      </p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>
      <div className="integrity-footnote">
        <ShieldCheck size={15} /> Every applied fix writes a local audit entry.
        Keep a backup before large data changes.
      </div>
    </div>
  );
}

export function ExcelToolsPage() {
  const students =
    useLiveQuery(
      () => db.students.filter((s) => !s.deletedAt).toArray(),
      [],
      [],
    ) || [];
  const classes = useClasses();
  const teachers = useLiveQuery(() => db.teachers.toArray(), [], []) || [];
  const dues = useLiveQuery(() => db.feeDues.toArray(), [], []) || [];
  const attendance = useLiveQuery(() => db.attendance.toArray(), [], []) || [];
  const routes = useLiveQuery(() => db.transportRoutes.toArray(), [], []) || [];
  const payroll = useLiveQuery(() => db.payroll.toArray(), [], []) || [];
  const results = useLiveQuery(() => db.examResults.toArray(), [], []) || [];
  const { toast } = useToast();
  const [dataset, setDataset] = useState("Students");
  const [preview, setPreview] = useState<{
    rows: any[];
    valid: any[];
    errors: number;
    file: string;
  } | null>(null);
  const [busy, setBusy] = useState(false);
  const datasetRows: Record<string, any[]> = {
    Students: students.map((s) => ({
      admissionNo: s.admissionNo,
      name: s.name,
      father: s.father,
      mother: s.mother,
      class: classes.find((c) => c.id === s.classId)?.name || "",
      section: s.section,
      roll: s.roll,
      dob: s.dob,
      gender: s.gender,
      mobile: s.mobile,
      address: s.address,
      session: s.session,
      status: s.status,
      admissionDate: s.admissionDate,
    })),
    Fees: dues.map((d) => ({
      studentId: d.studentId,
      month: d.month,
      session: d.session,
      total: d.total,
      paid: d.paid,
      balance: d.balance,
      status: d.status,
    })),
    Attendance: attendance.map((a) => ({
      studentId: a.studentId,
      classId: a.classId,
      section: a.section,
      date: a.date,
      status: a.status,
      session: a.session,
    })),
    Teachers: teachers.map((t) => ({
      teacherId: t.teacherId,
      name: t.name,
      subject: t.subject,
      mobile: t.mobile,
      salary: t.salary,
      status: t.status,
    })),
    Transport: routes.map((r) => ({
      route: r.name,
      vehicle: r.vehicle,
      driver: r.driver,
      phone: r.phone,
      monthlyFee: r.monthlyFee,
    })),
    Payroll: payroll.map((p) => ({
      name: p.name,
      role: p.role,
      month: p.month,
      basic: p.basic,
      allowance: p.allowance,
      deduction: p.deduction,
      net: p.net,
      status: p.status,
    })),
    Results: results.map((r) => ({
      examId: r.examId,
      studentId: r.studentId,
      subject: r.subject,
      maxMarks: r.maxMarks,
      marks: r.marks,
      grade: r.grade,
      result: r.result,
    })),
  };
  const exportData = async (kind: "csv" | "xlsx") => {
    if (kind === "csv") {
      const rows = datasetRows[dataset] || [];
      if (!rows.length) {
        toast("There are no records to export yet.", "info");
        return;
      }
      saveFile(
        new Blob([csvString(rows)], { type: "text/csv;charset=utf-8" }),
        `${dataset.toLowerCase()}-${todayISO()}.csv`,
      );
      toast(`${dataset} CSV downloaded.`);
      return;
    }
    setBusy(true);
    try {
      const loaded: any = await import("@e965/xlsx/dist/xlsx.mini.min.js");
      const XLSX = loaded.default || loaded;
      const workbook = XLSX.utils.book_new();
      const sheet = XLSX.utils.json_to_sheet(datasetRows[dataset] || []);
      XLSX.utils.book_append_sheet(workbook, sheet, dataset.slice(0, 31));
      XLSX.writeFile(workbook, `${dataset.toLowerCase()}-${todayISO()}.xlsx`);
      toast(`${dataset} Excel file downloaded.`);
    } catch {
      toast("Excel export could not finish.", "error");
    } finally {
      setBusy(false);
    }
  };
  const template = () => {
    const headers = [
      {
        admissionNo: "ADM-001",
        name: "Student full name",
        father: "Parent name",
        mother: "Parent name",
        class: "Class 1",
        section: "A",
        roll: "",
        dob: "2018-04-16",
        gender: "Female",
        mobile: "9876543210",
        address: "",
        session: "2026-27",
        admissionDate: todayISO(),
      },
    ];
    saveFile(
      new Blob([csvString(headers)], { type: "text/csv;charset=utf-8" }),
      "schoolflow-student-import-template.csv",
    );
  };
  const importFile = async (file?: File) => {
    if (!file) return;
    setBusy(true);
    try {
      const loaded: any = await import("@e965/xlsx/dist/xlsx.mini.min.js");
      const XLSX = loaded.default || loaded;
      const buf = await file.arrayBuffer();
      const workbook = XLSX.read(buf, { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const raw: Record<string, unknown>[] = XLSX.utils.sheet_to_json(sheet, {
        defval: "",
      });
      const normalized = raw.map((row) =>
        Object.fromEntries(
          Object.entries(row).map(([k, v]) => [
            k.toLowerCase().replace(/[^a-z0-9]/g, ""),
            String(v).trim(),
          ]),
        ),
      );
      const used = new Set(students.map((s) => s.normalizedAdmissionNo));
      const rows = normalized.map((r: any, i: number) => {
        const adm = r.admissionno || r.admissionnumber || r.admno || "";
        const norm = normalizeAdmission(adm);
        const cls = classes.find(
          (c) =>
            c.name.toLowerCase() ===
              String(r.class || r.classname || "").toLowerCase() &&
            c.section.toLowerCase() === String(r.section || "").toLowerCase(),
        );
        const errors: string[] = [];
        if (!adm) errors.push("Admission number required");
        if (!r.name && !r.studentname) errors.push("Student name required");
        if (!cls) errors.push("Class / section not found");
        const mobile = r.mobile || r.mobilenumber || r.phone || "";
        if (!validMobile(mobile)) errors.push("Invalid mobile");
        if (used.has(norm)) errors.push("Duplicate admission number");
        if (r.dob && !validPastOrToday(r.dob)) errors.push("DOB in future");
        if (!norm) errors.push("Admission number invalid");
        used.add(norm);
        return {
          rowNo: i + 2,
          admissionNo: adm,
          name: r.name || r.studentname || "",
          father: r.father || r.fathername || "",
          mother: r.mother || r.mothername || "",
          classId: cls?.id,
          section: cls?.section || r.section || "A",
          roll: Number(r.roll) || 0,
          dob: r.dob || "",
          gender: r.gender || "Other",
          mobile,
          address: r.address || "",
          session: r.session || cls?.session || "2026-27",
          admissionDate: r.admissiondate || todayISO(),
          errors,
        };
      });
      setPreview({
        rows,
        valid: rows.filter((r) => !r.errors.length),
        errors: rows.filter((r) => r.errors.length).length,
        file: file.name,
      });
      if (!rows.length) toast("File has no student rows.", "error");
    } catch (e) {
      toast(
        e instanceof Error
          ? `Could not read file: ${e.message}`
          : "Could not read this Excel/CSV file.",
        "error",
      );
    } finally {
      setBusy(false);
    }
  };
  const importValid = async () => {
    if (!preview?.valid.length) return;
    setBusy(true);
    try {
      const now = new Date().toISOString();
      await db.transaction("rw", db.students, async () => {
        for (const r of preview.valid) {
          const used = await db.students
            .where("normalizedAdmissionNo")
            .equals(normalizeAdmission(r.admissionNo))
            .first();
          if (used) continue;
          const classRows = await db.students
            .filter(
              (s) =>
                s.classId === r.classId &&
                s.section === r.section &&
                s.session === r.session &&
                s.status === "Active",
            )
            .toArray();
          const roll =
            r.roll || Math.max(0, ...classRows.map((s) => s.roll)) + 1;
          await db.students.add({
            admissionNo: r.admissionNo,
            normalizedAdmissionNo: normalizeAdmission(r.admissionNo),
            name: r.name,
            father: r.father,
            mother: r.mother,
            classId: r.classId,
            section: r.section,
            roll,
            dob: r.dob,
            gender: r.gender,
            mobile: r.mobile,
            address: r.address,
            session: r.session,
            status: "Active",
            admissionDate: r.admissionDate,
            createdAt: now,
            updatedAt: now,
          });
        }
      });
      await audit(
        currentUser(),
        "Imported students",
        "Excel import",
        undefined,
        `${preview.valid.length} valid rows`,
      );
      toast(`${preview.valid.length} student records imported.`);
      setPreview(null);
    } catch (e) {
      toast(
        e instanceof Error ? e.message : "Import could not finish.",
        "error",
      );
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="SPREADSHEET TOOLS"
        title="Excel & CSV"
        subtitle="Bring clean data in, or take a portable spreadsheet out."
      />
      <div className="excel-overview">
        <div className="excel-file-art">
          <FileSpreadsheet size={25} />
          <span> XLSX</span>
          <i />
          <i />
          <i />
        </div>
        <div>
          <span className="card-eyebrow">LOCAL FILES · NO CLOUD UPLOAD</span>
          <h2>Your spreadsheet stays yours.</h2>
          <p>
            Import student lists with a validation preview. Export the registers
            your team needs in CSV or Excel format.
          </p>
        </div>
      </div>
      <div className="excel-tools-grid">
        <Card className="excel-tool-card">
          <div className="excel-tool-head">
            <span className="excel-tool-icon green">
              <FileSpreadsheet size={18} />
            </span>
            <div>
              <span className="card-eyebrow">EXPORT RECORDS</span>
              <h3>Choose a register</h3>
            </div>
          </div>
          <Select
            label="Data to export"
            value={dataset}
            onChange={(e) => setDataset(e.target.value)}
          >
            {Object.keys(datasetRows).map((d) => (
              <option key={d}>{d}</option>
            ))}
          </Select>
          <div className="export-record-count">
            <span>
              {numberIN(datasetRows[dataset]?.length || 0)} rows available
            </span>
            <Badge tone="green">On this device</Badge>
          </div>
          <div className="excel-button-row">
            <Button
              variant="secondary"
              onClick={() => void exportData("csv")}
              disabled={!datasetRows[dataset]?.length}
            >
              <Download size={15} /> CSV
            </Button>
            <Button
              onClick={() => void exportData("xlsx")}
              disabled={busy || !datasetRows[dataset]?.length}
            >
              <FileSpreadsheet size={15} />{" "}
              {busy ? "Preparing…" : "Excel .xlsx"}
            </Button>
          </div>
        </Card>
        <Card className="excel-tool-card import-tool">
          <div className="excel-tool-head">
            <span className="excel-tool-icon violet">
              <UserPlus size={18} />
            </span>
            <div>
              <span className="card-eyebrow">IMPORT STUDENTS</span>
              <h3>Start with a clean sheet</h3>
            </div>
          </div>
          <p>
            Upload a CSV or Excel file. We’ll check admission numbers, class,
            mobile and required fields before importing valid rows only.
          </p>
          <label className="file-drop import-drop">
            <input
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={(e) => void importFile(e.target.files?.[0])}
            />
            <span className="file-drop-icon">
              <Plus size={18} />
            </span>
            <b>{busy ? "Reading your file…" : "Choose CSV or Excel file"}</b>
            <small>No file is uploaded to a server</small>
          </label>
          <button className="template-download" onClick={template}>
            <Download size={14} /> Download blank CSV template
          </button>
        </Card>
      </div>
      <div className="import-rules">
        <span>
          <ShieldCheck size={16} />
          <b>Validation before import</b>
        </span>
        <div>
          <Badge tone="green">Required fields</Badge>
          <Badge tone="violet">Unique admission no.</Badge>
          <Badge tone="amber">Valid class + section</Badge>
          <Badge tone="blue">10-digit mobile</Badge>
        </div>
      </div>
      <Modal
        open={!!preview}
        onClose={() => setPreview(null)}
        title="Student import preview"
        subtitle={`${preview?.file || ""} · No records are imported until you confirm.`}
        size="lg"
      >
        {preview && (
          <>
            <div className="import-summary">
              <div>
                <b>{preview.valid.length}</b>
                <small>rows ready</small>
              </div>
              <div>
                <b className={preview.errors ? "text-rose" : ""}>
                  {preview.errors}
                </b>
                <small>rows with errors</small>
              </div>
              <div>
                <b>{preview.rows.length}</b>
                <small>total rows</small>
              </div>
            </div>
            <div className="import-preview-table">
              <div className="import-preview-head">
                <span>ROW</span>
                <span>STUDENT</span>
                <span>ADMISSION NO.</span>
                <span>VALIDATION</span>
              </div>
              {preview.rows.slice(0, 30).map((r) => (
                <div className="import-preview-row" key={r.rowNo}>
                  <span>#{r.rowNo}</span>
                  <b>{r.name || "—"}</b>
                  <span className="mono">{r.admissionNo || "—"}</span>
                  <span>
                    {r.errors.length ? (
                      <span className="error-list">{r.errors.join(" · ")}</span>
                    ) : (
                      <Badge tone="green">Ready</Badge>
                    )}
                  </span>
                </div>
              ))}
            </div>
            <p className="form-helper">
              Only valid rows are imported. Download the error report by
              correcting the source sheet and previewing it again.
            </p>
            <div className="modal-actions">
              <Button variant="secondary" onClick={() => setPreview(null)}>
                Cancel
              </Button>
              <Button
                onClick={() => void importValid()}
                disabled={busy || !preview.valid.length}
              >
                {busy
                  ? "Importing…"
                  : `Import ${preview.valid.length} valid rows`}
                <ArrowRight size={16} />
              </Button>
            </div>
          </>
        )}
      </Modal>
    </div>
  );
}

export function SettingsPage() {
  const settings = useSettings();
  const { toast } = useToast();
  const [draft, setDraft] = useState<Record<string, any>>({});
  const [logo, setLogo] = useState("");
  const [storageStatus, setStorageStatus] = useState({ used: 0, quota: 0 });
  useEffect(() => {
    if (!navigator.storage?.estimate) return;
    void navigator.storage
      .estimate()
      .then((estimate) => {
        setStorageStatus({
          used: estimate.usage || 0,
          quota: estimate.quota || 0,
        });
      })
      .catch(() => undefined);
  }, []);
  const storagePercent = storageStatus.quota
    ? Math.min(
        100,
        Math.round((storageStatus.used / storageStatus.quota) * 100),
      )
    : 0;
  useEffect(() => {
    setDraft({ ...settings });
    setLogo(String(settings.logo || ""));
  }, [JSON.stringify(settings)]);
  const save = async (e: FormEvent) => {
    e.preventDefault();
    const keepCount = Math.min(
      100,
      Math.max(1, Math.trunc(Number(draft.keepBackupsCount) || 12)),
    );
    const normalizedDraft = { ...draft, keepBackupsCount: keepCount };
    for (const [key, value] of Object.entries(normalizedDraft))
      await saveSetting(key, value);
    await pruneBackupHistory(keepCount);
    await saveSetting("logo", logo);
    localStorage.setItem(
      "schoolflow-text-scale",
      String(draft.textSize || 100),
    );
    document.documentElement.style.setProperty(
      "--text-scale",
      `${Number(draft.textSize || 100)}%`,
    );
    await audit(
      currentUser(),
      "Updated school settings",
      "Settings",
      undefined,
      "School profile / display preferences",
    );
    toast("School settings saved.");
  };
  const logoHandler = async (file?: File) => {
    if (!file) return;
    try {
      setLogo(await resizeImage(file, 600, true));
      toast(
        "Logo ready. PNG transparency is preserved; re-upload the original PNG to replace any older copy.",
      );
    } catch {
      toast("Logo could not be loaded.", "error");
    }
  };
  const removeLogo = () => {
    setLogo("");
    void saveSetting("logo", "");
  };
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="PREFERENCES & SCHOOL PROFILE"
        title="Settings"
        subtitle="Make SchoolFlow fit the everyday way your school works."
      />
      <form className="settings-form" onSubmit={save}>
        <Card className="settings-card">
          <div className="settings-section-head">
            <span className="settings-icon lavender">
              <BookOpenCheck size={18} />
            </span>
            <div>
              <h3>School profile</h3>
              <p>Shown on receipts, reports and student documents.</p>
            </div>
          </div>
          <div className="settings-fields">
            <Input
              label="School name"
              value={draft.schoolName || ""}
              onChange={(e) =>
                setDraft({ ...draft, schoolName: e.target.value })
              }
              required
            />
            <Input
              label="Principal name"
              value={draft.principalName || ""}
              onChange={(e) =>
                setDraft({ ...draft, principalName: e.target.value })
              }
            />
            <Input
              label="School phone"
              type="tel"
              value={draft.phone || ""}
              onChange={(e) => setDraft({ ...draft, phone: e.target.value })}
            />
            <Input
              label="Email address"
              type="email"
              value={draft.email || ""}
              onChange={(e) => setDraft({ ...draft, email: e.target.value })}
            />
            <Input
              label="Website"
              value={draft.website || ""}
              onChange={(e) => setDraft({ ...draft, website: e.target.value })}
            />
            <Input
              label="Academic session"
              value={draft.academicSession || ""}
              onChange={(e) =>
                setDraft({ ...draft, academicSession: e.target.value })
              }
            />
            <Textarea
              label="School address"
              className="full-span"
              rows={2}
              value={draft.address || ""}
              onChange={(e) => setDraft({ ...draft, address: e.target.value })}
            />
            <div className="logo-setting full-span">
              <span className="logo-preview">
                {logo ? (
                  <img src={logo} alt="School logo" />
                ) : (
                  <span>{(draft.schoolName || "S")[0]}</span>
                )}
              </span>
              <div>
                <b>School logo</b>
                <small>
                  Optional · JPEG supported · PNG transparency preserved ·
                  stored locally
                </small>
                <label className="upload-link">
                  {logo ? "Change logo" : "Upload logo"}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => void logoHandler(e.target.files?.[0])}
                  />
                </label>
              </div>
              {logo && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={removeLogo}
                >
                  Remove
                </Button>
              )}
            </div>
          </div>
        </Card>
        <Card className="settings-card">
          <div className="settings-section-head">
            <span className="settings-icon peach">
              <WalletCards size={18} />
            </span>
            <div>
              <h3>Fees & print</h3>
              <p>Defaults for your fee desk and printed documents.</p>
            </div>
          </div>
          <div className="settings-fields">
            <Input
              label="Default fee month"
              type="month"
              value={draft.defaultFeeMonth || monthISO()}
              onChange={(e) =>
                setDraft({ ...draft, defaultFeeMonth: e.target.value })
              }
            />
            <Input
              label="Default fee due day"
              type="number"
              min="1"
              max="31"
              value={draft.defaultFeeDay || 10}
              onChange={(e) =>
                setDraft({ ...draft, defaultFeeDay: Number(e.target.value) })
              }
            />
            <Select
              label="Result template"
              value={draft.resultTemplate || "premium"}
              onChange={(e) =>
                setDraft({ ...draft, resultTemplate: e.target.value })
              }
            >
              <option value="premium">Premium</option>
              <option value="classic">Classic</option>
              <option value="compact">Compact</option>
            </Select>
            <Input
              label="Receipt footer note"
              value={draft.receiptFooter || ""}
              onChange={(e) =>
                setDraft({ ...draft, receiptFooter: e.target.value })
              }
              placeholder="e.g. Thank you for your timely payment"
            />
            <Textarea
              label="Demand bill payment details"
              value={draft.paymentDetails || ""}
              onChange={(e) =>
                setDraft({ ...draft, paymentDetails: e.target.value })
              }
              rows={2}
              placeholder="Office hours, UPI ID or bank payment instructions"
            />
            <Input
              label="Print footer note"
              className="full-span"
              value={draft.printFooter || ""}
              onChange={(e) =>
                setDraft({ ...draft, printFooter: e.target.value })
              }
              placeholder="Short note on printed reports"
            />
          </div>
        </Card>
        <Card className="settings-card">
          <div className="settings-section-head">
            <span className="settings-icon blue">
              <Settings size={18} />
            </span>
            <div>
              <h3>Display & backup</h3>
              <p>Personalise the app for this device.</p>
            </div>
          </div>
          <div className="settings-option-row">
            <span>
              <b>Appearance</b>
              <small>Choose light, dark or follow your device</small>
            </span>
            <div className="segmented-control setting-theme">
              <button
                type="button"
                onClick={() => setDraft({ ...draft, theme: "light" })}
                className={draft.theme === "light" ? "active" : ""}
              >
                <Sun size={14} /> Light
              </button>
              <button
                type="button"
                onClick={() => setDraft({ ...draft, theme: "dark" })}
                className={draft.theme === "dark" ? "active" : ""}
              >
                <Moon size={14} /> Dark
              </button>
              <button
                type="button"
                onClick={() => setDraft({ ...draft, theme: "system" })}
                className={draft.theme === "system" ? "active" : ""}
              >
                <Settings size={14} /> System
              </button>
            </div>
          </div>
          <Divider />
          <div className="settings-option-row">
            <span>
              <b>Text size</b>
              <small>Helps keep touch targets comfortable</small>
            </span>
            <div className="text-size-options">
              {[100, 115, 130].map((size) => (
                <button
                  key={size}
                  type="button"
                  className={
                    Number(draft.textSize || 100) === size ? "active" : ""
                  }
                  onClick={() => setDraft({ ...draft, textSize: size })}
                >
                  {size}%
                </button>
              ))}
            </div>
          </div>
          <Divider />
          <div className="settings-option-row">
            <span>
              <b>Auto-lock session</b>
              <small>
                Ask for your password after inactivity. 0 disables the lock.
              </small>
            </span>
            <Select
              aria-label="Auto-lock session timeout"
              value={Number(draft.autoLockMinutes ?? 15)}
              onChange={(e) =>
                setDraft({ ...draft, autoLockMinutes: Number(e.target.value) })
              }
            >
              <option value="1">1 minute</option>
              <option value="5">5 minutes</option>
              <option value="10">10 minutes</option>
              <option value="15">15 minutes</option>
              <option value="30">30 minutes</option>
              <option value="60">60 minutes</option>
              <option value="0">Off</option>
            </Select>
          </div>
          <Divider />
          <div className="settings-option-row">
            <span>
              <b>Auto-backup reminder</b>
              <small>Reminder only — this device does not upload data</small>
            </span>
            <Select
              aria-label="Auto backup reminder"
              value={draft.autoBackupFrequency || draft.autoBackup || "weekly"}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  autoBackup: e.target.value,
                  autoBackupFrequency: e.target.value,
                })
              }
            >
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
              <option value="off">Off</option>
            </Select>
          </div>
          <Divider />
          <div className="settings-option-row">
            <span>
              <b>Keep backup history</b>
              <small>Local reminder log retention count</small>
            </span>
            <Input
              aria-label="Keep backup history count"
              type="number"
              min="1"
              max="100"
              value={draft.keepBackupsCount || 12}
              onChange={(e) =>
                setDraft({
                  ...draft,
                  keepBackupsCount: Number(e.target.value || 1),
                })
              }
            />
          </div>
          <Divider />
          <div className="settings-option-row">
            <span>
              <b>Language</b>
              <small>English labels with simple Hinglish help text</small>
            </span>
            <Badge tone="violet">English · Hinglish</Badge>
          </div>
        </Card>
        <Card className="settings-card storage-card">
          <div className="settings-section-head">
            <span className="settings-icon blue">
              <ShieldCheck size={18} />
            </span>
            <div>
              <h3>Device storage</h3>
              <p>Records, photos and documents stay in this browser profile.</p>
            </div>
          </div>
          <div className="storage-summary">
            <b>{formatBytes(storageStatus.used)}</b>
            <span>
              used{" "}
              {storageStatus.quota
                ? `of ${formatBytes(storageStatus.quota)}`
                : "on this device"}
            </span>
            <strong>{storagePercent}%</strong>
          </div>
          <div className="storage-progress">
            <i style={{ width: `${storagePercent}%` }} />
          </div>
          {storagePercent >= 80 && (
            <div className="restore-warning">
              <CircleAlert size={16} />
              <span>
                Storage is above 80%. Download a backup and remove unneeded
                large documents or photos.
              </span>
            </div>
          )}
          <small className="storage-note">
            Browser storage can be removed by clearing site data. Keep a
            separate .schoolerp backup.
          </small>
        </Card>
        <Card className="settings-card settings-about-card">
          <span className="about-brand-mark">S</span>
          <span>
            <b>SchoolFlow · School ERP</b>
            <small>Developed by Sanjaydat Kumar · Version 1.0.0</small>
          </span>
          <Link to="/about">
            About <ArrowRight size={14} />
          </Link>
        </Card>
        <div className="settings-save-bar">
          <span>
            <ShieldCheck size={15} /> Changes save locally on this device.
          </span>
          <Button size="lg" type="submit">
            Save settings <Check size={16} />
          </Button>
        </div>
      </form>
    </div>
  );
}

export function UsersPage() {
  const users = useLiveQuery(() => db.users.toArray(), [], []) || [];
  const teachers =
    useLiveQuery(
      () =>
        db.teachers
          .filter(
            (teacher) => !teacher.deletedAt && teacher.status === "Active",
          )
          .toArray(),
      [],
      [],
    ) || [];
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<AppUser | null>(null);
  const [q, setQ] = useState("");
  const [resetTarget, setResetTarget] = useState<AppUser | null>(null);
  const [temporaryPassword, setTemporaryPassword] = useState("");
  const [resetBusy, setResetBusy] = useState(false);
  const [draft, setDraft] = useState({
    username: "",
    fullName: "",
    role: "Teacher" as Role,
    teacherId: "",
    password: "ChangeMe123!",
    status: "Active" as const,
  });
  const show = (u?: AppUser) => {
    setEditing(u || null);
    setDraft(
      u
        ? {
            username: u.username,
            fullName: u.fullName,
            role: u.role,
            teacherId: String(u.teacherId || ""),
            password: "",
            status: u.status as "Active",
          }
        : {
            username: "",
            fullName: "",
            role: "Teacher",
            teacherId: "",
            password: "ChangeMe123!",
            status: "Active",
          },
    );
    setOpen(true);
  };
  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!draft.username.trim() || !draft.fullName.trim()) {
      toast("Username and full name are required.", "error");
      return;
    }
    if (!editing && draft.password.length < 8) {
      toast("Set a temporary password with at least 8 characters.", "error");
      return;
    }
    if (draft.role === "Teacher" && !draft.teacherId) {
      toast("Assign this account to an active teacher record.", "error");
      return;
    }
    try {
      if (editing) {
        await db.users.update(editing.id!, {
          username: draft.username.trim().toLowerCase(),
          fullName: draft.fullName.trim(),
          role: draft.role,
          teacherId:
            draft.role === "Teacher" ? Number(draft.teacherId) : undefined,
          status: draft.status,
        });
      } else {
        const salt = crypto.randomUUID();
        const { hashPassword } = await import("./lib");
        await db.users.add({
          username: draft.username.trim().toLowerCase(),
          fullName: draft.fullName.trim(),
          role: draft.role,
          teacherId:
            draft.role === "Teacher" ? Number(draft.teacherId) : undefined,
          status: "Active",
          salt,
          passwordHash: await hashPassword(draft.password, salt),
          mustChange: true,
        });
      }
      await audit(
        currentUser(),
        editing ? "Updated user" : "Created user",
        "User",
        editing?.id,
        draft.username,
      );
      setOpen(false);
      toast(
        editing
          ? "User updated."
          : "User created. They will change the temporary password on sign-in.",
      );
    } catch {
      toast("Username already exists. Choose a unique username.", "error");
    }
  };
  const resetPassword = async (event: FormEvent) => {
    event.preventDefault();
    if (!resetTarget || temporaryPassword.length < 8) {
      toast("Temporary password must be at least 8 characters.", "error");
      return;
    }
    setResetBusy(true);
    try {
      const salt = crypto.randomUUID();
      const { hashPassword } = await import("./lib");
      await db.users.update(resetTarget.id!, {
        salt,
        passwordHash: await hashPassword(temporaryPassword, salt),
        mustChange: true,
      });
      await audit(
        currentUser(),
        "Reset user password",
        "User",
        resetTarget.id,
        resetTarget.username,
      );
      toast(
        `${resetTarget.username}'s password was reset. They must change it at next sign-in.`,
      );
      setResetTarget(null);
      setTemporaryPassword("");
    } catch {
      toast("Password could not be reset. Please try again.", "error");
    } finally {
      setResetBusy(false);
    }
  };
  const toggle = async (u: AppUser) => {
    if (u.username === "admin" && u.status === "Active") {
      toast("The primary admin account cannot be deactivated.", "error");
      return;
    }
    await db.users.update(u.id!, {
      status: u.status === "Active" ? "Inactive" : "Active",
    });
    await audit(currentUser(), "Changed user status", "User", u.id, u.username);
    toast(
      `${u.username} is now ${u.status === "Active" ? "inactive" : "active"}.`,
    );
  };
  const visible = users.filter((u) =>
    [u.username, u.fullName, u.role].some((x) =>
      x.toLowerCase().includes(q.toLowerCase()),
    ),
  );
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="ACCESS & PERMISSIONS"
        title="Users & roles"
        subtitle="Give each team member the right tools for their school day."
        action={
          <Button onClick={() => show()}>
            <Plus size={17} /> Add user
          </Button>
        }
      />
      <div className="role-cards">
        {[
          {
            name: "Admin",
            desc: "All school modules",
            icon: <ShieldCheck size={17} />,
          },
          {
            name: "Principal",
            desc: "Reports, approvals, promotion",
            icon: <GraduationCap size={17} />,
          },
          {
            name: "Teacher",
            desc: "Assigned student & attendance",
            icon: <Users size={17} />,
          },
          {
            name: "Accountant",
            desc: "Fees, payroll, backup",
            icon: <WalletCards size={17} />,
          },
          {
            name: "Reception",
            desc: "Admissions & student records",
            icon: <UserPlus size={17} />,
          },
        ].map((r) => (
          <div className="role-card" key={r.name}>
            <span>{r.icon}</span>
            <b>{r.name}</b>
            <small>{r.desc}</small>
          </div>
        ))}
      </div>
      <div className="security-note">
        <ShieldCheck size={16} />
        <span>
          <b>Local sign-in</b> · Passwords are SHA-256 hashed with a unique salt
          in this device’s IndexedDB. There is no cloud login server.
        </span>
      </div>
      <Card className="list-card">
        <div className="list-toolbar">
          <SearchBox
            value={q}
            onChange={setQ}
            placeholder="Search users or roles…"
          />
          <span className="row-count">{visible.length} users</span>
        </div>
        {visible.length ? (
          <TableWrap>
            <table className="data-table">
              <thead>
                <tr>
                  <th>USER</th>
                  <th>ROLE</th>
                  <th>LAST SIGN-IN</th>
                  <th>STATUS</th>
                  <th>ACTIONS</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((u) => (
                  <tr key={u.id}>
                    <td>
                      <div className="student-cell">
                        <Avatar name={u.fullName} />
                        <span>
                          <b>{u.fullName}</b>
                          <small>
                            @{u.username}
                            {u.teacherId
                              ? ` · ${teachers.find((teacher) => teacher.id === u.teacherId)?.name || "Teacher assigned"}`
                              : ""}
                          </small>
                        </span>
                      </div>
                    </td>
                    <td>
                      <Badge tone={u.role === "Admin" ? "violet" : "blue"}>
                        {u.role}
                      </Badge>
                    </td>
                    <td>
                      {u.lastLoginAt
                        ? displayDate(u.lastLoginAt.slice(0, 10))
                        : "Never"}
                    </td>
                    <td>
                      <Badge tone={makeTone(u.status)}>{u.status}</Badge>
                    </td>
                    <td>
                      <div className="table-actions">
                        <button className="row-action" onClick={() => show(u)}>
                          <Settings size={15} />
                          <span>Edit</span>
                        </button>
                        <button
                          className="row-action"
                          onClick={() => {
                            setResetTarget(u);
                            setTemporaryPassword("");
                          }}
                        >
                          <KeyRound size={15} />
                          <span>Reset password</span>
                        </button>
                        <button
                          className="row-action"
                          onClick={() => void toggle(u)}
                        >
                          <span>
                            {u.status === "Active" ? "Deactivate" : "Activate"}
                          </span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        ) : (
          <EmptyState
            title="No user accounts found"
            text="Add a team member account when you are ready to share this device."
            icon={<Users size={22} />}
          />
        )}
      </Card>
      <div className="role-warning">
        <CircleAlert size={15} />
        <span>
          Mode A stores data on one device. User roles control this browser’s UI
          only — they do not create cloud accounts or multi-device sync.
        </span>
      </div>
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? "Edit user access" : "Add a team member"}
        subtitle="New accounts start with a temporary password and must change it at first login."
      >
        <form className="form-grid" onSubmit={save}>
          <Input
            label="Full name"
            value={draft.fullName}
            onChange={(e) => setDraft({ ...draft, fullName: e.target.value })}
            required
          />
          <Input
            label="Username"
            value={draft.username}
            onChange={(e) => setDraft({ ...draft, username: e.target.value })}
            required
            placeholder="lowercase username"
          />
          <Select
            label="Role"
            value={draft.role}
            onChange={(e) =>
              setDraft({
                ...draft,
                role: e.target.value as Role,
                teacherId: e.target.value === "Teacher" ? draft.teacherId : "",
              })
            }
          >
            <option>Principal</option>
            <option>Teacher</option>
            <option>Accountant</option>
            <option>Reception</option>
            <option>Admin</option>
          </Select>
          {draft.role === "Teacher" && (
            <Select
              label="Assigned teacher record"
              value={draft.teacherId}
              onChange={(e) => {
                const selectedTeacher = teachers.find(
                  (teacher) => teacher.id === Number(e.target.value),
                );
                setDraft((previous) => ({
                  ...previous,
                  teacherId: e.target.value,
                  fullName:
                    !previous.fullName.trim() && selectedTeacher
                      ? selectedTeacher.name
                      : previous.fullName,
                }));
              }}
              required
            >
              <option value="">Choose teacher</option>
              {teachers.map((teacher) => (
                <option key={teacher.id} value={teacher.id}>
                  {teacher.name} · {teacher.subject || "Teacher"}
                </option>
              ))}
            </Select>
          )}
          {draft.role === "Teacher" && !teachers.length && (
            <div className="inline-alert full-span">
              <CircleAlert size={16} />
              <span>Add a teacher record before creating a teacher login.</span>
              <Link to="/teachers">
                Open teachers <ArrowRight size={14} />
              </Link>
            </div>
          )}
          {!editing && (
            <Input
              label="Temporary password"
              type="password"
              minLength={8}
              value={draft.password}
              onChange={(e) => setDraft({ ...draft, password: e.target.value })}
              required
              hint="At least 8 characters · user must change it on first login"
            />
          )}
          <div className="role-permission-preview full-span">
            <ShieldCheck size={15} />
            <span>
              <b>{draft.role}</b> access includes role-based module visibility
              in this workspace.
            </span>
          </div>
          <div className="modal-actions full-span">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
            <Button type="submit">
              {editing ? "Save user" : "Create user"}
              <ArrowRight size={16} />
            </Button>
          </div>
        </form>
      </Modal>
      <Modal
        open={!!resetTarget}
        onClose={() => {
          setResetTarget(null);
          setTemporaryPassword("");
        }}
        title="Reset user password"
        subtitle={
          resetTarget
            ? `Set a temporary password for @${resetTarget.username}. They will be asked to change it at next sign-in.`
            : ""
        }
        size="sm"
      >
        <form className="form-grid" onSubmit={resetPassword}>
          <Input
            label="Temporary password"
            type="password"
            minLength={8}
            autoComplete="new-password"
            value={temporaryPassword}
            onChange={(event) => setTemporaryPassword(event.target.value)}
            required
            hint="At least 8 characters. Share it privately with the user."
          />
          <div className="restore-warning full-span">
            <ShieldCheck size={16} />
            <span>
              The new password is stored as a salted hash. The user’s next login
              must update it.
            </span>
          </div>
          <div className="modal-actions full-span">
            <Button
              type="button"
              variant="secondary"
              onClick={() => {
                setResetTarget(null);
                setTemporaryPassword("");
              }}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={resetBusy || temporaryPassword.length < 8}
            >
              {resetBusy ? "Resetting…" : "Reset password"}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

export function ChangePasswordPage() {
  const user = useAuth((s) => s.user);
  const settings = useSettings();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const strength =
    next.length >= 12 ? 3 : next.length >= 8 ? 2 : next.length >= 5 ? 1 : 0;
  const save = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (next.length < 8) {
      toast("New password should be at least 8 characters.", "error");
      return;
    }
    if (next !== confirm) {
      toast("New password and confirmation do not match.", "error");
      return;
    }
    setBusy(true);
    try {
      await changePasswordLocal(user.id, current, next);
      await audit(user.username, "Changed password", "User", user.id);
      toast("Password updated securely.");
      setCurrent("");
      setNext("");
      setConfirm("");
      navigate(settings.setupComplete ? "/home" : "/setup", { replace: true });
    } catch (e) {
      toast(
        e instanceof Error ? e.message : "Password update failed.",
        "error",
      );
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="page-stack narrow-page">
      <PageTitle
        eyebrow="ACCOUNT SECURITY"
        title="Change password"
        subtitle="A strong password helps keep this device’s school records private."
      />
      <Card className="password-card">
        <div className="password-card-icon">
          <ShieldCheck size={21} />
        </div>
        <h3>Choose a password you’ll remember.</h3>
        <p>
          Use at least 8 characters. Your password is hashed locally and never
          sent to a server.
        </p>
        <form className="password-form" onSubmit={save}>
          <Input
            label="Current password"
            type="password"
            value={current}
            onChange={(e) => setCurrent(e.target.value)}
            required
            autoComplete="current-password"
          />
          <Input
            label="New password"
            type="password"
            value={next}
            onChange={(e) => setNext(e.target.value)}
            required
            autoComplete="new-password"
            minLength={8}
          />
          <div className="password-strength">
            <span>Password strength</span>
            <div>
              {[1, 2, 3].map((i) => (
                <i
                  key={i}
                  className={strength >= i ? `strength-${strength}` : ""}
                />
              ))}
            </div>
            <b>
              {strength === 0
                ? "Enter a password"
                : strength === 1
                  ? "Getting there"
                  : strength === 2
                    ? "Good"
                    : "Strong"}
            </b>
          </div>
          <Input
            label="Confirm new password"
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            required
            autoComplete="new-password"
          />
          <Button
            type="submit"
            size="lg"
            className="full-width"
            disabled={busy}
          >
            {busy ? "Updating…" : "Update password"}
            <ArrowRight size={16} />
          </Button>
        </form>
        <div className="password-tip">
          <CircleAlert size={15} />
          <span>
            If you forget it, there is no online recovery for Mode A. Ask your
            admin to reset it on this device.
          </span>
        </div>
      </Card>
    </div>
  );
}

export function SetupPage() {
  const settings = useSettings();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<Record<string, any>>({
    schoolName: "",
    address: "",
    phone: "",
    email: "",
    website: "",
    principalName: "",
    academicSession: "2026-27",
    defaultFeeMonth: monthISO(),
    resultTemplate: "premium",
    theme: "light",
  });
  useEffect(() => {
    setDraft((prev) => ({
      ...prev,
      ...settings,
      schoolName: settings.schoolName || "",
      address: settings.address || "",
      phone: settings.phone || "",
      email: settings.email || "",
      website: settings.website || "",
      principalName: settings.principalName || "",
      academicSession: settings.academicSession || "2026-27",
      defaultFeeMonth: settings.defaultFeeMonth || monthISO(),
    }));
  }, [JSON.stringify(settings)]);
  const logoHandler = async (file?: File) => {
    if (!file) return;
    try {
      const logo = await resizeImage(file, 600, true);
      setDraft((prev) => ({ ...prev, logo }));
      toast(
        "Logo ready. PNG transparency is preserved; re-upload the original PNG to replace any older copy.",
      );
    } catch {
      toast("Logo could not be loaded.", "error");
    }
  };
  const complete = async (skip = false) => {
    setBusy(true);
    try {
      if (!skip && !draft.schoolName.trim()) {
        toast("Please enter your school name to continue.", "error");
        setBusy(false);
        return;
      }
      for (const [key, value] of Object.entries(draft))
        await saveSetting(key, value);
      await saveSetting("setupComplete", true);
      await audit(
        currentUser(),
        skip ? "Skipped setup" : "Completed setup",
        "Settings",
        undefined,
        draft.schoolName,
      );
      toast(
        skip
          ? "Setup skipped. You can update this later in Settings."
          : "School workspace is ready.",
      );
      navigate("/home", { replace: true });
    } catch {
      toast("Could not save school setup.", "error");
    } finally {
      setBusy(false);
    }
  };
  const next = () => {
    if (step === 1 && !draft.schoolName.trim()) {
      toast("School name is required.", "error");
      return;
    }
    setStep((s) => Math.min(3, s + 1));
  };
  return (
    <div className="setup-screen">
      <div className="setup-top">
        <Link to="/home" className="brand-lockup">
          <div className="brand-mark">S</div>
          <div>
            <strong>schoolflow</strong>
            <span>school ERP</span>
          </div>
        </Link>
        <button className="setup-skip" onClick={() => void complete(true)}>
          Skip for now <ArrowRight size={14} />
        </button>
      </div>
      <div className="setup-wrap">
        <div className="setup-aside">
          <span className="setup-kicker">FIRST-RUN SETUP</span>
          <h1>
            A good school day
            <br />
            starts with a <em>good setup.</em>
          </h1>
          <p>
            Just the essentials today. Everything can be edited later in
            Settings.
          </p>
          <div className="setup-step-list">
            {[
              { i: 1, t: "School profile", s: "Let us know your school" },
              { i: 2, t: "Academic year", s: "Choose the session" },
              { i: 3, t: "Make it yours", s: "A few last preferences" },
            ].map((x) => (
              <div
                key={x.i}
                className={
                  step === x.i ? "active" : step > x.i ? "complete" : ""
                }
              >
                <span>{step > x.i ? <Check size={14} /> : `0${x.i}`}</span>
                <div>
                  <b>{x.t}</b>
                  <small>{x.s}</small>
                </div>
              </div>
            ))}
          </div>
          <div className="setup-aside-note">
            <ShieldCheck size={15} />
            Your setup stays on this device.
          </div>
        </div>
        <Card className="setup-form-card">
          <div className="setup-progress">
            <span>
              STEP 0{step} <i>/ 03</i>
            </span>
            <div>
              <b style={{ width: `${(step / 3) * 100}%` }} />
            </div>
          </div>
          {step === 1 ? (
            <>
              <span className="card-eyebrow">A FEW SCHOOL DETAILS</span>
              <h2>Let’s start with the basics.</h2>
              <p className="setup-form-sub">
                These details appear on reports and fee receipts.
              </p>
              <div className="setup-fields">
                <Input
                  label="School name"
                  value={draft.schoolName}
                  onChange={(e) =>
                    setDraft({ ...draft, schoolName: e.target.value })
                  }
                  placeholder="e.g. Sunrise Public School"
                  required
                />
                <Input
                  label="Principal name"
                  value={draft.principalName || ""}
                  onChange={(e) =>
                    setDraft({ ...draft, principalName: e.target.value })
                  }
                  placeholder="Full name"
                />
                <Input
                  label="Phone number"
                  type="tel"
                  value={draft.phone || ""}
                  onChange={(e) =>
                    setDraft({ ...draft, phone: e.target.value })
                  }
                  placeholder="+91"
                />
                <Input
                  label="Email address"
                  type="email"
                  value={draft.email || ""}
                  onChange={(e) =>
                    setDraft({ ...draft, email: e.target.value })
                  }
                  placeholder="office@school.in"
                />
                <Input
                  label="Website"
                  value={draft.website || ""}
                  onChange={(e) =>
                    setDraft({ ...draft, website: e.target.value })
                  }
                  placeholder="Optional"
                />
                <Textarea
                  label="School address"
                  className="full-span"
                  value={draft.address || ""}
                  onChange={(e) =>
                    setDraft({ ...draft, address: e.target.value })
                  }
                  rows={2}
                  placeholder="Street, area, city, PIN"
                />
                <div className="logo-setting full-span">
                  <span className="logo-preview">
                    {draft.logo ? (
                      <img src={String(draft.logo)} alt="School logo" />
                    ) : (
                      <span>{(draft.schoolName || "S")[0]}</span>
                    )}
                  </span>
                  <div>
                    <b>School logo</b>
                    <small>
                      Optional · choose from camera or gallery · PNG
                      transparency is preserved
                    </small>
                    <label className="upload-link">
                      {draft.logo ? "Change logo" : "Upload logo"}
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          void logoHandler(e.target.files?.[0]);
                          e.currentTarget.value = "";
                        }}
                      />
                    </label>
                  </div>
                  {draft.logo && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setDraft({ ...draft, logo: "" })}
                    >
                      Remove
                    </Button>
                  )}
                </div>
              </div>
            </>
          ) : step === 2 ? (
            <>
              <span className="card-eyebrow">ACADEMIC CALENDAR</span>
              <h2>Set your school’s year.</h2>
              <p className="setup-form-sub">
                This is used as the default session for new records.
              </p>
              <div className="session-visual">
                <div className="session-visual-icon">
                  <CalendarDays size={22} />
                </div>
                <div>
                  <small>ACADEMIC SESSION</small>
                  <Input
                    value={draft.academicSession || ""}
                    onChange={(e) =>
                      setDraft({ ...draft, academicSession: e.target.value })
                    }
                    placeholder="2026-27"
                  />
                </div>
              </div>
              <div className="setup-hint">
                <Sparkles size={15} />
                <span>
                  For example, use <b>2026-27</b> for the school year starting
                  in 2026.
                </span>
              </div>
              <Input
                label="Default fee month"
                type="month"
                value={draft.defaultFeeMonth || monthISO()}
                onChange={(e) =>
                  setDraft({ ...draft, defaultFeeMonth: e.target.value })
                }
              />
            </>
          ) : (
            <>
              <span className="card-eyebrow">PREFERENCES</span>
              <h2>Make it feel like yours.</h2>
              <p className="setup-form-sub">
                Choose a starting point. You can switch later in Settings.
              </p>
              <div className="theme-choice-grid">
                <button
                  type="button"
                  className={draft.theme === "light" ? "selected" : ""}
                  onClick={() => setDraft({ ...draft, theme: "light" })}
                >
                  <span className="theme-preview light-preview">
                    <i />
                    <i />
                    <i />
                  </span>
                  <b>
                    <Sun size={15} /> Light
                  </b>
                  <small>Clean and bright</small>
                </button>
                <button
                  type="button"
                  className={draft.theme === "dark" ? "selected" : ""}
                  onClick={() => setDraft({ ...draft, theme: "dark" })}
                >
                  <span className="theme-preview dark-preview">
                    <i />
                    <i />
                    <i />
                  </span>
                  <b>
                    <Moon size={15} /> Dark
                  </b>
                  <small>Easy on the eyes</small>
                </button>
                <button
                  type="button"
                  className={draft.theme === "system" ? "selected" : ""}
                  onClick={() => setDraft({ ...draft, theme: "system" })}
                >
                  <span className="theme-preview system-preview">
                    <i />
                    <i />
                    <i />
                  </span>
                  <b>
                    <Settings size={15} /> System
                  </b>
                  <small>Follow this device</small>
                </button>
              </div>
              <Select
                label="Result template"
                value={draft.resultTemplate || "premium"}
                onChange={(e) =>
                  setDraft({ ...draft, resultTemplate: e.target.value })
                }
              >
                <option value="premium">Premium · colourful cards</option>
                <option value="classic">Classic · formal layout</option>
                <option value="compact">Compact · print-friendly</option>
              </Select>
              <div className="setup-hint">
                <ShieldCheck size={15} />
                <span>
                  No sample students or fee data will be created. Your register
                  begins clean.
                </span>
              </div>
            </>
          )}
          <div className="setup-controls">
            {step > 1 && (
              <Button variant="secondary" onClick={() => setStep((s) => s - 1)}>
                Back
              </Button>
            )}
            {step < 3 ? (
              <Button onClick={next}>
                Continue <ArrowRight size={16} />
              </Button>
            ) : (
              <Button onClick={() => void complete()} disabled={busy}>
                {busy ? "Saving…" : "Finish setup"}
                <Check size={16} />
              </Button>
            )}
          </div>
        </Card>
      </div>
      <div className="setup-footer">
        Developed by Sanjaydat Kumar <span>·</span> Offline-first by design
      </div>
    </div>
  );
}

export function FreshStartPage() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"clear" | "reset">("clear");
  const [typed, setTyped] = useState("");
  const [safety, setSafety] = useState(false);
  const [busy, setBusy] = useState(false);
  const students = useLiveQuery(() => db.students.count(), [], 0) || 0;
  const classes = useLiveQuery(() => db.classes.count(), [], 0) || 0;
  const teachers = useLiveQuery(() => db.teachers.count(), [], 0) || 0;
  const { setUser } = useAuth.getState();
  const backup = async () => {
    setBusy(true);
    try {
      const r = await downloadBackup("safety");
      setSafety(true);
      toast(`Safety copy downloaded: ${r.filename}.`);
    } catch {
      toast(
        "Safety backup could not be created. No data was removed.",
        "error",
      );
    } finally {
      setBusy(false);
    }
  };
  const clear = async () => {
    if (typed !== "RESET") {
      toast("Type RESET exactly to confirm.", "error");
      return;
    }
    if (!safety) {
      toast("Create the safety backup before clearing data.", "error");
      return;
    }
    setBusy(true);
    const before = { students, classes, teachers };
    try {
      const clearNames =
        mode === "clear"
          ? [
              "students",
              "attendance",
              "feeDues",
              "feePayments",
              "exams",
              "examResults",
              "payroll",
              "notifications",
              "auditLogs",
              "promotions",
              "familyBills",
            ]
          : (tablesForBackup as unknown as string[]);
      await (db.transaction.bind(db) as any)(
        "rw",
        ...clearNames.map((n) => db.table(n)),
        async () => {
          for (const n of clearNames) await db.table(n).clear();
        },
      );
      if (mode === "reset") {
        localStorage.removeItem("schoolflow-session");
        localStorage.removeItem("schoolflow-text-scale");
        sessionStorage.clear();
        setUser(null);
        await import("./db").then((m) => m.ensureSeed());
        toast("Factory reset complete. Sign in with admin / admin123.");
        navigate("/", { replace: true });
      } else {
        await audit(
          currentUser(),
          "Cleared school data",
          "Fresh start",
          undefined,
          `Before: ${JSON.stringify(before)}`,
        );
        toast(
          "School data cleared. Settings, users, classes and fee plans were kept.",
        );
        navigate("/home", { replace: true });
      }
      setTyped("");
      setSafety(false);
    } catch (e) {
      toast(
        e instanceof Error
          ? `Could not finish safely: ${e.message}`
          : "Could not finish fresh start.",
        "error",
      );
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="RESET & RECOVERY"
        title="Fresh start"
        subtitle="Clear records carefully. Read what changes, make a safety copy, then confirm."
      />
      <div className="fresh-warning">
        <span>
          <CircleAlert size={21} />
        </span>
        <div>
          <b>This action cannot be undone from the app.</b>
          <p>
            A safety backup file is required before any records are removed.
            Keep it somewhere other than this browser.
          </p>
        </div>
      </div>
      <div className="reset-mode-grid">
        <button
          type="button"
          className={`reset-option ${mode === "clear" ? "selected" : ""}`}
          onClick={() => {
            setMode("clear");
            setTyped("");
            setSafety(false);
          }}
        >
          <span className="reset-option-icon amber">
            <Trash2 size={18} />
          </span>
          <span>
            <b>Data clear</b>
            <small>
              Remove student records, attendance, fees, bills, exams, payroll,
              notifications and promotion logs.
            </small>
            <i>
              Keeps classes, teachers, fee plans, transport, settings, logo and
              user accounts.
            </i>
          </span>
          <span className="radio-dot" />
        </button>
        <button
          type="button"
          className={`reset-option ${mode === "reset" ? "selected" : ""}`}
          onClick={() => {
            setMode("reset");
            setTyped("");
            setSafety(false);
          }}
        >
          <span className="reset-option-icon rose">
            <X size={18} />
          </span>
          <span>
            <b>Full factory reset</b>
            <small>
              Remove all school records, classes, teachers, transport, fee
              plans, settings and logo.
            </small>
            <i>
              Only admin / admin123 will remain. Setup starts again from the
              beginning.
            </i>
          </span>
          <span className="radio-dot" />
        </button>
      </div>
      <Card className="fresh-safety-card">
        <div className="fresh-card-head">
          <span className={`fresh-safety-icon ${safety ? "safe" : ""}`}>
            {safety ? <Check size={18} /> : <ShieldCheck size={18} />}
          </span>
          <div>
            <span className="card-eyebrow">STEP 1 · REQUIRED SAFETY COPY</span>
            <h3>
              {safety
                ? "Safety backup created"
                : "Protect your school records first"}
            </h3>
            <p>
              {safety
                ? "A backup file has been downloaded. Confirm that it is saved somewhere safe."
                : "Download a complete .schoolerp backup before removing local records."}
            </p>
          </div>
          {!safety && (
            <Button onClick={() => void backup()} disabled={busy}>
              {busy ? (
                "Preparing…"
              ) : (
                <>
                  <Download size={15} /> Create safety backup
                </>
              )}
            </Button>
          )}
        </div>
        <div className="fresh-counts">
          <div>
            <small>STUDENTS NOW</small>
            <b>{students}</b>
          </div>
          <div>
            <small>CLASSES NOW</small>
            <b>{classes}</b>
          </div>
          <div>
            <small>TEACHERS NOW</small>
            <b>{teachers}</b>
          </div>
          <div>
            <small>SELECTED MODE</small>
            <b>{mode === "clear" ? "Data clear" : "Factory reset"}</b>
          </div>
        </div>
      </Card>
      <Card className="fresh-confirm-card">
        <div className="fresh-confirm-copy">
          <span className="card-eyebrow">STEP 2 · TYPE TO CONFIRM</span>
          <h3>Are you absolutely sure?</h3>
          <p>
            {mode === "clear"
              ? "Only student-linked school records will be cleared. Classes, staff, routes, fee plans, settings and login accounts remain."
              : "All local school data and preferences will be erased. The app restarts with its default admin account."}
          </p>
        </div>
        <div className="fresh-confirm-controls">
          <Input
            label="Type RESET to continue"
            value={typed}
            onChange={(e) => setTyped(e.target.value)}
            placeholder="RESET"
            autoComplete="off"
          />
          <Button
            variant="danger"
            size="lg"
            disabled={!safety || typed !== "RESET" || busy}
            onClick={() => void clear()}
          >
            {busy
              ? "Working…"
              : mode === "clear"
                ? "Clear selected data"
                : "Factory reset this app"}
            <ArrowRight size={16} />
          </Button>
        </div>
      </Card>
      <div className="privacy-note danger-note">
        <ShieldCheck size={15} />
        <span>
          App ka data is device ke browser storage (IndexedDB) me hai. Browser
          storage clear karna bhi data hata sakta hai.
        </span>
        <Link to="/backup">
          Back up records <ArrowRight size={13} />
        </Link>
      </div>
    </div>
  );
}

export function AboutPage() {
  const settings = useSettings();
  return (
    <div className="page-stack">
      <PageTitle
        eyebrow="A QUIETER WAY TO RUN A SCHOOL"
        title="About SchoolFlow"
        subtitle="Built for the people who keep a school moving, every single day."
      />
      <Card className="about-hero">
        <div className="about-logo-large">S</div>
        <span className="about-kicker">SCHOOL MANAGEMENT · OFFLINE-FIRST</span>
        <h2>
          A little more clarity.
          <br />
          <em>A little less busywork.</em>
        </h2>
        <p>
          SchoolFlow brings everyday school records into one thoughtful,
          phone-first workspace — admissions, attendance, fees, exams and the
          moments in between.
        </p>
        <div className="about-pills">
          <span>
            <WifiOff size={14} /> Offline-ready
          </span>
          <span>
            <ShieldCheck size={14} /> Local by design
          </span>
          <span>
            <Sparkles size={14} /> Made for small screens
          </span>
        </div>
        <div className="about-doodle">
          <span>✦</span>
          <span>◌</span>
          <span>✧</span>
        </div>
      </Card>
      <div className="about-feature-grid">
        <Card>
          <span className="about-feature-icon lavender">
            <Layers3 size={18} />
          </span>
          <b>One local workspace</b>
          <p>
            Student, staff and school data stays in this browser’s IndexedDB.
            There is no server sync in Mode A.
          </p>
        </Card>
        <Card>
          <span className="about-feature-icon mint">
            <ShieldCheck size={18} />
          </span>
          <b>Private by design</b>
          <p>
            No analytics, tracking pixels or third-party school data services
            are included in this build.
          </p>
        </Card>
        <Card>
          <span className="about-feature-icon peach">
            <Download size={18} />
          </span>
          <b>Portable backup</b>
          <p>
            Export a .schoolerp file and restore it on another device when you
            need to move your records.
          </p>
        </Card>
      </div>
      <Card className="credit-card">
        <span className="credit-stamp">✦</span>
        <span>
          <small>DEVELOPED BY</small>
          <b>Sanjaydat Kumar</b>
          <i>Developer credit is part of this school workspace.</i>
        </span>
        <span className="version-pill">VERSION 1.0.0</span>
      </Card>
      <div className="about-bottom-links">
        <Link to="/settings">
          School settings <ArrowRight size={14} />
        </Link>
        <Link to="/backup">
          Backup guide <ArrowRight size={14} />
        </Link>
        <Link to="/reports">
          Browse reports <ArrowRight size={14} />
        </Link>
      </div>
    </div>
  );
}

export function ExitPage() {
  const navigate = useNavigate();
  const user = useAuth((s) => s.user);
  const { toast } = useToast();
  const logout = () => {
    localStorage.removeItem("schoolflow-session");
    useAuth.getState().setUser(null);
    toast("You are signed out.", "info");
    navigate("/", { replace: true });
  };
  return (
    <div className="page-stack exit-screen">
      <div className="exit-art">
        <div className="exit-door">
          <div className="door-window" />
          <div className="door-knob" />
        </div>
        <span className="exit-star star-a">✦</span>
        <span className="exit-star star-b">✧</span>
        <span className="exit-plant">✿</span>
      </div>
      <span className="card-eyebrow">BEFORE YOU GO</span>
      <h1>
        That’s a wrap
        <br />
        for today.
      </h1>
      <p>
        SchoolFlow saves each change as you go. If you’re switching devices or
        clearing browser data, take a backup first.
      </p>
      <div className="exit-actions">
        <Link to="/backup" className="btn btn-secondary">
          <Download size={16} /> Take a backup
        </Link>
        <Button onClick={logout}>
          <LogOut size={16} /> Sign out {user?.fullName.split(" ")[0]}
        </Button>
      </div>
      <small className="exit-credit">
        See you next time · Developed by Sanjaydat Kumar
      </small>
    </div>
  );
}
