export type Role =
  | "Admin"
  | "Principal"
  | "Teacher"
  | "Accountant"
  | "Reception";
export type StudentStatus =
  | "Active"
  | "Left"
  | "TC Issued"
  | "Passed Out"
  | "Inactive";
export type AttendanceStatus = "Present" | "Absent" | "Late";

export interface Student {
  id?: number;
  admissionNo: string;
  normalizedAdmissionNo: string;
  name: string;
  father: string;
  mother: string;
  classId: number;
  section: string;
  roll: number;
  dob: string;
  gender: string;
  religion?: string;
  aadhaar?: string;
  mobile: string;
  address?: string;
  photo?: string;
  routeId?: number;
  travelMode?: "None" | "School route" | "Private vehicle";
  session: string;
  status: StudentStatus;
  leavingDate?: string;
  leavingReason?: string;
  tcNumber?: string;
  tcIssueDate?: string;
  bloodGroup?: string;
  vehicleNumber?: string;
  lastClass?: string;
  conduct?: string;
  duesCleared?: boolean;
  admissionDate: string;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
}
export interface SchoolClass {
  id?: number;
  name: string;
  section: string;
  session: string;
  room?: string;
  teacherId?: number;
  status: "Active" | "Inactive";
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
}
export interface Teacher {
  id?: number;
  teacherId: string;
  name: string;
  gender: string;
  subject: string;
  qualification?: string;
  mobile: string;
  address?: string;
  joiningDate?: string;
  salary: number;
  status: "Active" | "Inactive";
  deletedAt?: string;
}
export interface Attendance {
  id?: number;
  studentId: number;
  classId: number;
  section: string;
  session: string;
  date: string;
  status: AttendanceStatus;
  remarks?: string;
  updatedAt: string;
}
export interface FeeStructure {
  id?: number;
  classId: number;
  section: string;
  session: string;
  tuition: number;
  transport: number;
  exam: number;
  admission: number;
  library: number;
  other: number;
  total: number;
  status: "Active" | "Inactive";
}
export interface FeeDue {
  id?: number;
  studentId: number;
  session: string;
  month: string;
  tuition: number;
  transport: number;
  exam: number;
  admission: number;
  library: number;
  other: number;
  discount: number;
  fine: number;
  total: number;
  paid: number;
  balance: number;
  status: "Paid" | "Pending" | "Partial";
  createdAt: string;
  updatedAt: string;
}
export interface FeePayment {
  id?: number;
  receiptNo: string;
  dueId: number;
  studentId: number;
  amount: number;
  mode: string;
  paidAt: string;
  remarks?: string;
  voidedAt?: string;
  voidReason?: string;
  familyBillNo?: string;
}
export interface Exam {
  id?: number;
  name: string;
  classId: number;
  section: string;
  session: string;
  date: string;
  subjects: string[];
  subjectMaxMarks?: Record<string, number>;
  maxMarks: number;
  status: "Planned" | "Completed";
}
export interface ExamResult {
  id?: number;
  examId: number;
  studentId: number;
  subject: string;
  maxMarks: number;
  marks: number;
  grade: string;
  result: "Pass" | "Fail";
}
export interface TransportRoute {
  id?: number;
  name: string;
  vehicle: string;
  driver: string;
  phone: string;
  monthlyFee: number;
  capacity: number;
  remarks?: string;
  status: "Active" | "Inactive";
}
export interface Payroll {
  id?: number;
  name: string;
  role: string;
  month: string;
  basic: number;
  allowance: number;
  deduction: number;
  net: number;
  status: "Paid" | "Unpaid";
  paymentDate?: string;
  updatedAt: string;
}
export interface AppUser {
  id?: number;
  username: string;
  passwordHash: string;
  salt: string;
  fullName: string;
  role: Role;
  teacherId?: number;
  status: "Active" | "Inactive";
  mustChange?: boolean;
  lastLoginAt?: string;
}
export interface Setting {
  key: string;
  value: unknown;
}
export interface AuditLog {
  id?: number;
  username: string;
  action: string;
  entity: string;
  entityId?: string | number;
  details?: string;
  beforeJson?: string;
  afterJson?: string;
  createdAt: string;
}
export interface Notification {
  id?: number;
  type: string;
  title: string;
  message: string;
  module: string;
  severity: "info" | "warning" | "danger";
  isRead: boolean;
  createdAt: string;
  fingerprint?: string;
  relatedId?: number | string;
}
export interface PromotionLog {
  id?: number;
  studentId: number;
  fromClass: string;
  toClass: string;
  fromSession: string;
  toSession: string;
  oldRoll: number;
  newRoll: number;
  type: "normal" | "rank" | "single";
  rankUsed?: number;
  remarks?: string;
  createdAt: string;
  username?: string;
}
export interface FamilyBill {
  id?: number;
  billNo: string;
  familyKey: string;
  parent: string;
  mobile: string;
  studentIds: number[];
  total: number;
  discount: number;
  fine: number;
  paid: number;
  createdAt: string;
  months?: string[];
  balance?: number;
  status?: "Paid" | "Partial" | "Pending";
  paymentMode?: string;
  updatedAt?: string;
  items?: FamilyBillItem[];
}

export interface FamilyBillItem {
  studentId: number;
  studentName: string;
  className: string;
  section: string;
  feeMonth: string;
  feeHead: string;
  amount: number;
  source: "Due" | "Discount" | "Fine" | "Payment";
}

export interface StudentDocument {
  id?: number;
  studentId: number;
  docType: string;
  fileName: string;
  mimeType: string;
  dataUrl: string;
  remarks?: string;
  createdAt: string;
  deletedAt?: string;
}

export interface StudentTimeline {
  id?: number;
  studentId: number;
  eventType: string;
  title: string;
  details?: string;
  createdAt: string;
  username?: string;
}

export interface DemandBatchRecord {
  id?: number;
  batchNo: string;
  session: string;
  month: string;
  months?: string[];
  classKey: string;
  count: number;
  total: number;
  skipped: number;
  includeBack: boolean;
  saveCurrentDues: boolean;
  payBy?: string;
  remarks?: string;
  students: {
    studentId: number;
    studentName: string;
    admissionNo: string;
    className: string;
    section: string;
    heads: Record<string, number>;
    backDues: number;
    total: number;
  }[];
  createdAt: string;
}

export interface BackupLog {
  id?: number;
  filename: string;
  size: number;
  type: "download" | "safety" | "restore";
  verified: boolean;
  createdAt: string;
}
