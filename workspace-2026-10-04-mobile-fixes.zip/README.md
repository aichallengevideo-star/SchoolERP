# SchoolFlow — School ERP (Mode A)

Phone-first, offline-first school management app. Is build ka data **isi device ke browser IndexedDB** me rehta hai; cloud/server sync is version me nahi hai. Developer credit: **Sanjaydat Kumar**.

## Jaldi start karein

### Computer par run karein

```bash
npm install
npm run dev
```

Terminal me Vite ka local URL kholein (usually `http://localhost:5173`). Production build verify karne ke liye:

```bash
npm run test
npm run build
npm run preview
```

`npm run preview` installable PWA / production service-worker flow test karne ke liye hai. Browser me `localhost` ya HTTPS origin use karein.

### Pehla login

1. Username: **admin**
2. Temporary password: **admin123**
3. First login par naya password set karein (minimum 8 characters).
4. School Setup wizard me school name, session aur display preferences bhar ke **Finish setup** karein.
5. App jaan-boojhkar **koi sample student, fee, ya teacher create nahi karta**. Testing ke liye apne test records manually add karein.

## Basic end-to-end test

1. **Classes → Add class**: `Class 1`, section `A`, session `2026-27` banayein.
2. Agar school vehicle use karna hai, **Transport → Add route** me route, vehicle number, driver aur monthly fee set karein.
3. **Students → New admission**: unique admission number, student name, valid 10-digit mobile, class/session choose karein; **School vehicle / route** me route assign karein (ya self-arranged travel select karein), phir save karein. Profile me route/vehicle check karein.
4. **Attendance**: Class 1-A choose karein, present/absent/late mark karein aur save karein. Saved absent marks ke baad **Bulk SMS** kholein: app guardians ko phone number ke hisaab se group karke professional draft banata hai; har draft SMS composer me check karein. SMS manually review karke Send karein.
5. **Fee structures**: Class 1-A ka monthly plan banayein.
6. **Fee structures → Generate monthly dues**: month select, preview, phir confirm.
7. **Fee collection**: student select karke partial payment save karein; receipt me number, amount aur balance check karein. Pending Fees me month/search filters apply karke **Review bulk SMS** se per-guardian fee summary banayein; message review karke SMS app me manually Send karein.
8. **Exams & results**: exam banayein, marks enter karein, rank list dekhein.
9. **Reports**: Active Students / Fee Ledger report kholkar CSV export aur print preview try karein. APK me print action Android print dialog kholta hai; **Save as PDF** chun sakte hain. Export button Android share sheet kholta hai—Files/Drive me save karein.
10. Home dashboard par **Backup** ya **Restore** shortcut, ya **More → Backup & restore** kholein. `.schoolerp` backup banayein; restore test se pehle safety copy bana lein—restore current device ka data replace karta hai.
11. Browser ko offline karke saved records open karein. Production build ko ek baar online load/install karne ke baad offline test karein.

## Phone par test / install (step-by-step)

Full walkthrough (Android, iPhone, deployment, feature tests and troubleshooting): [`PHONE_INSTALL_TEST_GUIDE.md`](PHONE_INSTALL_TEST_GUIDE.md).

1. **Production build banayein:** project folder me `npm ci`, `npm run test`, phir `npm run build` chalayein. PWA installation ke liye `npm run dev` nahi—dev mode me service worker intentionally off hai.
2. **Build ko HTTPS par host karein:** kisi static host (jaise Netlify, Vercel ya Cloudflare Pages) me build command `npm run build`, publish/output folder `dist` set karein. Host ka HTTPS URL deploy hone ke baad copy karein. Is app ko backend ki zaroorat nahi; data har device ke browser me local rehta hai.
3. Phone ko Wi-Fi ya mobile data se internet par rakhein; phone ke Chrome/Safari me wahi HTTPS URL kholein. `localhost` phone par computer ko nahi, phone ko refer karta hai. Local network ka `http://192.168...` link PWA installation/service worker test ke liye bharosemand nahi hai.
4. **Android:** Chrome me site ek baar poori load hone dein. Menu `⋮` → **Install app** ya **Add to Home screen** → **Install / Add**. Home screen par SchoolFlow icon aane ke baad use khol kar test karein.
5. **iPhone:** Safari me HTTPS URL kholein → **Share** → **Add to Home Screen** → **Add**. Phir Home Screen icon se launch karein.
6. Pehli baar `admin` / `admin123` se sign in karein, naya password set karein aur **test school** ke naam/session se setup karein. Sirf dummy student, guardian aur fee records banayein; asli student data use na karein.
7. Test karein: Settings me transparent PNG school logo upload karein; Students → student profile → **Print ID card** khol kar dono sides par logo watermark check karein. Absent mark karke attendance save karein, phir **Bulk SMS**; Pending Fees me **Review bulk SMS** kholkar amount/message verify karein. Har SMS composer me recipient/text check karke sirf test number ko manually bhejein. Student profile → Exams me per-exam summary/table dekhein; search result par tap karke sahi profile khulni chahiye. Export buttons Android share sheet kholenge—Files/Drive choose karke file save karein. Print me **Save as PDF** test karein. Promotion me dummy class/session par pehle preview, phir confirm karein.
8. **Offline test:** app ko internet ke saath ek baar launch aur load karein, phir airplane mode chala kar app dobara kholein. Local screens/data test karein; WhatsApp, SMS aur external links ko internet chahiye.
9. **Data note:** local data cloud me sync nahi hota. App ka data device/browser/origin ke saath juda hota hai; doosre phone ya URL par apne aap nahi aayega. Test ke baad Backup/Restore se backup lein, aur sensitive data ko public test URL par na rakhein.

Agar install option na dikhe: private/incognito tab ke bajay normal Chrome/Safari use karein, HTTPS lock icon confirm karein, production URL (dev server nahi) dobara load karein, phir browser band karke khol kar check karein.

## Backup aur restore

- Admin/Accountant ke Home dashboard par **Backup** aur **Restore** shortcuts hain. **More → Backup & restore** se bhi same screen khul sakti hai; **Download backup** ek `.schoolerp` JSON backup banata hai (student photos included).
- Is file ko WhatsApp/Drive/computer par apne school ke access rules ke mutabik rakhein. Is starter backup me encryption nahi hai — file ko public link par share na karein.
- Naye device par SchoolFlow kholein → Restore a backup → file preview check karein → restore confirm karein. Existing local database replace hota hai; restore se pehle current records ki safety copy download hoti hai.
- Browser storage clear karne se local data delete ho sakta hai. Backup alag jagah rakhein.

## Calling, messaging aur print preview

- Student list/profile me Call, WhatsApp aur SMS actions available hain; number copy karne ka option bhi hai. Indian numbers `+91` format me normalize hote hain. Phone/tablet par Call dialer aur SMS composer kholta hai; desktop browser me native phone app na ho to Call number copy karta hai, aur SMS number + message clipboard par copy karta hai.
- WhatsApp links same tab me khulte hain, taaki popup-blocked preview me action dead na ho. WhatsApp phir bhi manually review/send hota hai.
- **Pending Fees** me filters ke mutabik **Review bulk SMS** ek guardian ke liye ek professional draft banata hai; siblings/fees ke visible months ek message me combine hote hain. Per-row WhatsApp/SMS actions bhi hain. APK ka export Android share sheet kholta hai—Files/Drive ya supported app me file save karein.
- **Attendance** me absent marks pehle save karne honge. **Bulk SMS** valid numbers ko guardian ke hisaab se group karke drafts dikhata hai; har SMS composer me recipient/message review karke khud **Send** karein. App messages automatically nahi bhejta; auto-send ke liye alag online SMS provider/API aur explicit setup chahiye.
- Print preview ke baad APK me **Print / Save PDF** Android print dialog kholta hai; **Save as PDF** chun kar PDF save karein. Browser version apna print dialog use karta hai. Student ID card ke front/back par logo subtle watermark ki tarah dikhta hai.
- Settings / Setup me transparent PNG logo ka alpha preserve hota hai. Agar pehle upload ki hui PNG black background wali ho gayi thi, original PNG ko dobara upload karein; purana JPEG-converted copy transparency wapas nahi la sakta.
- Promotion me destination class/section ko template ke roop me chunein. Agar selected new session me destination class nahi hai, confirmation par us class/section ko copy karke banaya jayega; rank promotion same class ke sections ko use karta hai.

## Current scope / important notes

Ye supplied master prompt par based **single-device Mode A** build hai—cloud/server sync nahi. Isme local login + roles, dashboard, admissions, class/teacher/student records, attendance, fees, demand/family billing, exams/results, promotion, payroll, transport, reports, notifications, backup/restore, integrity checks, CSV/XLSX, settings, users aur Fresh Start flows shamil hain. Admission form me active transport route/vehicle choose kiya ja sakta hai; route aur vehicle student record me save hote hain. Admin/Accountant Home dashboard se Backup aur Restore screen khol sakte hain.

**Abhi verify/limit:** notifications app open hone par locally generate hote hain; background push reminders nahi hain. Backup file JSON-based hai aur encrypted nahi—use private jagah rakhein. Is workspace me `npm run test` ke 29 tests aur `npm run build` pass hue hain. Capacitor 8 native print/share integrations, mobile layout, search routing aur SMS review batches code/build me verified hain; real Android phone par print dialog, share/download destinations aur SMS composer ka end-to-end test abhi baaki hai. SMS/WhatsApp automatically send nahi hote. Har module ka manual acceptance run, Lighthouse scoring aur production-readiness audit complete/verified nahi hain. Student personal information local browser storage me hai; school ke access, device-sharing aur backup rules review karein.

## Commands

| Command           | Use                                 |
| ----------------- | ----------------------------------- |
| `npm install`     | Dependencies install                |
| `npm run dev`     | Local development server            |
| `npm run test`    | Utility/business-rule unit tests    |
| `npm run build`   | Type-check + production PWA build   |
| `npm run preview` | Production build ko locally preview |

Build me XLSX/CSV library lazy chunk me load hoti hai. Offline use ke liye pehli baar app ko online kholna zaroori hai.
